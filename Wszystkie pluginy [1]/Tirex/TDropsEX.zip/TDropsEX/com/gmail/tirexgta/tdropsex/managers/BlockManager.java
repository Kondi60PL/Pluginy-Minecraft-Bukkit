package com.gmail.tirexgta.tdropsex.managers;

import org.bukkit.entity.*;
import org.bukkit.block.*;
import org.bukkit.inventory.*;
import com.gmail.tirexgta.tdropsex.*;
import org.bukkit.enchantments.*;
import com.gmail.tirexgta.ttoolsex.database.*;
import org.apache.commons.lang.*;
import java.util.*;
import org.bukkit.*;

public class BlockManager
{
    List<Material> noDrops;
    public static List<String> cobble;
    private final Random rand;
    private List<Material> itemDurbility;
    
    static {
        BlockManager.cobble = new ArrayList<String>();
    }
    
    public BlockManager() {
        super();
        this.noDrops = new ArrayList<Material>();
        this.rand = new Random();
        this.itemDurbility = new ArrayList<Material>();
    }
    
    public void breakBlock(final Player p, final Block block) {
        if (this.itemDurbility.size() == 0) {
            this.itemDurbility.add(Material.DIAMOND_PICKAXE);
            this.itemDurbility.add(Material.GOLD_PICKAXE);
            this.itemDurbility.add(Material.WOOD_PICKAXE);
            this.itemDurbility.add(Material.STONE_PICKAXE);
            this.itemDurbility.add(Material.IRON_PICKAXE);
            this.itemDurbility.add(Material.DIAMOND_SWORD);
            this.itemDurbility.add(Material.GOLD_SWORD);
            this.itemDurbility.add(Material.WOOD_SWORD);
            this.itemDurbility.add(Material.STONE_SWORD);
            this.itemDurbility.add(Material.IRON_SWORD);
            this.itemDurbility.add(Material.DIAMOND_AXE);
            this.itemDurbility.add(Material.GOLD_AXE);
            this.itemDurbility.add(Material.WOOD_AXE);
            this.itemDurbility.add(Material.STONE_AXE);
            this.itemDurbility.add(Material.IRON_AXE);
            this.itemDurbility.add(Material.DIAMOND_SPADE);
            this.itemDurbility.add(Material.GOLD_SPADE);
            this.itemDurbility.add(Material.WOOD_SPADE);
            this.itemDurbility.add(Material.STONE_SPADE);
            this.itemDurbility.add(Material.IRON_SPADE);
            this.itemDurbility.add(Material.SHEARS);
        }
        if (this.noDrops.size() == 0) {
            this.noDrops.add(Material.DIAMOND_ORE);
            this.noDrops.add(Material.GOLD_ORE);
            this.noDrops.add(Material.EMERALD_ORE);
            this.noDrops.add(Material.IRON_ORE);
        }
        if (this.noDrops.contains(block.getType())) {
            block.setType(Material.AIR);
            return;
        }
        final ItemStack tool = p.getItemInHand();
        final List<ItemStack> drops = new ArrayList<ItemStack>();
        final int y = block.getY();
        int exp = 0;
        if (block.getType().equals((Object)Material.STONE)) {
            if (BlockManager.cobble.contains(p.getName().toLowerCase())) {
                block.setType(Material.AIR);
            }
            final double chanceXp = this.getRandDouble(1.0, 100.0);
            double chanceXpDrop = Main.getInstance().configManager.xpChance;
            if (p.hasPermission("tirex.vip")) {
                chanceXpDrop = Main.getInstance().configManager.xpChanceVip;
            }
            if (chanceXp <= chanceXpDrop) {
                int min = 0;
                int max = 0;
                final String[] sS = Main.getInstance().configManager.xpValue.split("\\-");
                if (sS.length >= 1) {
                    min = Integer.parseInt(sS[0]);
                }
                if (sS.length >= 2) {
                    max = Integer.parseInt(sS[1]);
                }
                exp += this.getRandInt(min, max);
                p.playSound(p.getLocation(), Sound.ORB_PICKUP, 0.5f, (float)(Math.random() * 20.0) / 10.0f);
            }
            final DataUser user = Datasource.getUserData(p);
            for (final DropManager drop : ConfigManager.drops) {
                final double chance = this.getRandDouble(0.0, 100.0);
                double chanceDrop = drop.getChance();
                if (p.hasPermission("tirex.vip")) {
                    chanceDrop = drop.getChanceVip();
                }
                if (chance <= chanceDrop && y <= drop.getY() && (drop.getTools() == null || drop.getTools().contains(tool.getType())) && (drop.getBioms() == null || drop.getBioms().contains(block.getBiome()))) {
                    final ItemStack item = drop.getMaterial();
                    final int min2 = drop.getMinValue();
                    final int max2 = drop.getMaxValue();
                    int amount = 1;
                    if (min2 != max2) {
                        amount = this.getRandInt(min2, max2);
                    }
                    else if (min2 == max2) {
                        amount = max2;
                    }
                    if (tool.containsEnchantment(Enchantment.LOOT_BONUS_BLOCKS)) {
                        amount = this.getAmountForFortune(amount, tool);
                    }
                    item.setAmount(amount);
                    exp += drop.getExp();
                    drops.add(item);
                    final int pkt = user.getPkt() + drop.getPkt() * amount;
                    user.setPkt(pkt);
                    this.pkt(user, p, 1);
                    if (amount > 1 && drop.getMessage() != null) {
                        String msg = drop.getMessage();
                        msg = msg.replace("%value%", Integer.toString(amount));
                        msg = msg.replace("%pkt%", Integer.toString(pkt));
                        msg = Main.fixMsg(msg);
                        p.sendMessage(msg);
                    }
                    else {
                        if (drop.getMessageMore() == null) {
                            continue;
                        }
                        String msg = drop.getMessageMore();
                        msg = msg.replace("%value%", Integer.toString(amount));
                        msg = msg.replace("%pkt%", Integer.toString(pkt));
                        msg = Main.fixMsg(msg);
                        p.sendMessage(msg);
                    }
                }
            }
        }
        final Iterator<ItemStack> it$1 = this.a(block, tool).iterator();
        while (it$1.hasNext()) {
            drops.add(it$1.next());
        }
        this.giveDropsToPlayer(drops, exp, p, block.getLocation());
        this.recalculateDurability(p);
        block.setType(Material.AIR);
    }
    
    public void giveDropsToPlayer(final List<ItemStack> drops, final int exp, final Player player, final Location location) {
        if (exp > 0) {
            player.giveExp(exp);
        }
        if (drops != null) {
            final ItemStack[] itemBoard = new ItemStack[drops.size()];
            for (int i = 0; i < drops.size(); ++i) {
                itemBoard[i] = drops.get(i);
            }
            final HashMap<Integer, ItemStack> notStored = (HashMap<Integer, ItemStack>)player.getInventory().addItem(itemBoard);
            for (final ItemStack it : notStored.values()) {
                if (it != null) {
                    location.getWorld().dropItemNaturally(location, it);
                }
            }
        }
    }
    
    public void dropToEq(final Player p, final ItemStack item, final Location loc) {
        if (p.getInventory().firstEmpty() >= 0) {
            p.getInventory().addItem(new ItemStack[] { item });
        }
        else {
            p.getWorld().dropItem(loc, item);
        }
    }
    
    public void recalculateDurability(final Player player) {
        final ItemStack item = player.getItemInHand();
        final int enchantLevel = item.getEnchantmentLevel(Enchantment.DURABILITY);
        final int random = this.getRandInt(1, 100);
        if (this.itemDurbility.contains(item.getType()) && (enchantLevel == 0 || random <= 100 / (enchantLevel + 1))) {
            if (item.getDurability() + 2 >= item.getType().getMaxDurability()) {
                player.getInventory().clear(player.getInventory().getHeldItemSlot());
                player.playSound(player.getLocation(), Sound.ITEM_BREAK, 1.0f, 1.0f);
            }
            else {
                item.setDurability((short)(item.getDurability() + 1));
            }
        }
    }
    
    public int getAmountForFortune(final int amount, final ItemStack tool) {
        final double fortuneRandom1 = Math.random() * 100.0;
        final double fortuneRandom2 = Math.random() * 100.0;
        final double fortuneRandom3 = Math.random() * 100.0;
        int a = amount;
        if (30.0 <= fortuneRandom1 && tool.getEnchantmentLevel(Enchantment.LOOT_BONUS_BLOCKS) >= 1) {
            ++a;
        }
        else if (20.0 <= fortuneRandom2 && tool.getEnchantmentLevel(Enchantment.LOOT_BONUS_BLOCKS) >= 2) {
            a += 2;
        }
        else if (10.0 <= fortuneRandom3 && tool.getEnchantmentLevel(Enchantment.LOOT_BONUS_BLOCKS) >= 3) {
            a += 3;
        }
        return a;
    }
    
    public int getRandInt(final int min, final int max) throws IllegalArgumentException {
        Validate.isTrue(max > min, "Max can't be smaller than min!");
        return this.rand.nextInt(max - min + 1) + min;
    }
    
    public Double getRandDouble(final double min, final double max) throws IllegalArgumentException {
        Validate.isTrue(max > min, "Max can't be smaller than min!");
        return this.rand.nextDouble() * (max - min) + min;
    }
    
    private Collection<ItemStack> a(final Block block, final ItemStack item) {
        final Collection<ItemStack> drops = new ArrayList<ItemStack>();
        if (item != null && item.getType().equals((Object)Material.SHEARS) && !item.containsEnchantment(Enchantment.SILK_TOUCH)) {
            if (block.getType().equals((Object)Material.LEAVES)) {
                if (block.getData() <= 3) {
                    drops.add(new ItemStack(block.getType(), 1, (short)block.getData()));
                }
                else if (block.getData() == 8 || block.getData() == 12) {
                    drops.add(new ItemStack(block.getType(), 1, (short)0));
                }
                else if (block.getData() == 13 || block.getData() == 9) {
                    drops.add(new ItemStack(block.getType(), 1, (short)1));
                }
                else if (block.getData() == 10 || block.getData() == 14) {
                    drops.add(new ItemStack(block.getType(), 1, (short)2));
                }
                else if (block.getData() == 15 || block.getData() == 11) {
                    drops.add(new ItemStack(block.getType(), 1, (short)3));
                }
                else {
                    drops.add(new ItemStack(block.getType(), 1, (short)0));
                }
            }
            else if (block.getType().equals((Object)Material.LEAVES_2)) {
                if (block.getData() <= 1) {
                    drops.add(new ItemStack(block.getType(), 1, (short)block.getData()));
                }
                else if (block.getData() == 4 || block.getData() == 5 || block.getData() == 8) {
                    drops.add(new ItemStack(block.getType(), 1, (short)0));
                }
                else if (block.getData() == 13 || block.getData() == 12 || block.getData() == 9) {
                    drops.add(new ItemStack(block.getType(), 1, (short)1));
                }
                else {
                    drops.add(new ItemStack(block.getType(), 1, (short)0));
                }
            }
            else if (block.getType().equals((Object)Material.LONG_GRASS) || block.getType().equals((Object)Material.CROPS) || block.getType().equals((Object)Material.RED_ROSE) || block.getType().equals((Object)Material.SAPLING)) {
                drops.add(new ItemStack(block.getType(), 1, (short)block.getData()));
            }
            else {
                final Iterator<ItemStack> it$1 = block.getDrops(item).iterator();
                while (it$1.hasNext()) {
                    drops.add(it$1.next());
                }
            }
        }
        else if (item != null && item.containsEnchantment(Enchantment.SILK_TOUCH)) {
            if (block.getType().equals((Object)Material.LONG_GRASS) || block.getType().equals((Object)Material.CROPS) || block.getType().equals((Object)Material.RED_ROSE) || block.getType().equals((Object)Material.SAPLING) || block.getType().equals((Object)Material.MONSTER_EGG) || block.getType().equals((Object)Material.MONSTER_EGGS) || block.getType().equals((Object)Material.ANVIL) || block.getType().equals((Object)Material.GLASS) || block.getType().equals((Object)Material.STAINED_GLASS) || block.getType().equals((Object)Material.STAINED_GLASS_PANE) || block.getType().equals((Object)Material.CARPET) || block.getType().equals((Object)Material.WOOL) || block.getType().equals((Object)Material.WOOD) || block.getType().equals((Object)Material.WOOD_DOUBLE_STEP)) {
                drops.add(new ItemStack(block.getType(), 1, (short)block.getData()));
            }
            else if (block.getType().equals((Object)Material.LOG)) {
                if (block.getData() <= 3) {
                    drops.add(new ItemStack(block.getType(), 1, (short)block.getData()));
                }
                else if (block.getData() == 8 || block.getData() == 3 || block.getData() == 12) {
                    drops.add(new ItemStack(block.getType(), 1, (short)0));
                }
                else if (block.getData() == 9 || block.getData() == 5 || block.getData() == 13) {
                    drops.add(new ItemStack(block.getType(), 1, (short)1));
                }
                else if (block.getData() == 10 || block.getData() == 6 || block.getData() == 14) {
                    drops.add(new ItemStack(block.getType(), 1, (short)2));
                }
                else if (block.getData() == 11 || block.getData() == 7 || block.getData() == 15) {
                    drops.add(new ItemStack(block.getType(), 1, (short)3));
                }
            }
            else if (block.getType().equals((Object)Material.LOG_2)) {
                if (block.getData() <= 1) {
                    drops.add(new ItemStack(block.getType(), 1, (short)block.getData()));
                }
                else if (block.getData() == 4 || block.getData() == 8 || block.getData() == 12) {
                    drops.add(new ItemStack(block.getType(), 1, (short)0));
                }
                else if (block.getData() == 5 || block.getData() == 9 || block.getData() == 13) {
                    drops.add(new ItemStack(block.getType(), 1, (short)1));
                }
            }
            else if (block.getType().equals((Object)Material.STEP)) {
                if (block.getData() <= 7) {
                    drops.add(new ItemStack(block.getType(), 1, (short)block.getData()));
                }
                else if (block.getData() == 8) {
                    drops.add(new ItemStack(block.getType(), 1, (short)0));
                }
                else if (block.getData() == 9) {
                    drops.add(new ItemStack(block.getType(), 1, (short)1));
                }
                else if (block.getData() == 10) {
                    drops.add(new ItemStack(block.getType(), 1, (short)2));
                }
                else if (block.getData() == 11) {
                    drops.add(new ItemStack(block.getType(), 1, (short)3));
                }
                else if (block.getData() == 12) {
                    drops.add(new ItemStack(block.getType(), 1, (short)4));
                }
                else if (block.getData() == 13) {
                    drops.add(new ItemStack(block.getType(), 1, (short)5));
                }
                else if (block.getData() == 14) {
                    drops.add(new ItemStack(block.getType(), 1, (short)6));
                }
                else if (block.getData() == 15) {
                    drops.add(new ItemStack(block.getType(), 1, (short)7));
                }
            }
            else if (block.getType().equals((Object)Material.DOUBLE_STEP)) {
                if (block.getData() <= 7) {
                    drops.add(new ItemStack(block.getType(), 2, (short)block.getData()));
                }
            }
            else if (block.getType().equals((Object)Material.WOOD_STEP)) {
                if (block.getData() <= 5) {
                    drops.add(new ItemStack(block.getType(), 1, (short)block.getData()));
                }
                else if (block.getData() == 8) {
                    drops.add(new ItemStack(block.getType(), 1, (short)0));
                }
                else if (block.getData() == 9) {
                    drops.add(new ItemStack(block.getType(), 1, (short)1));
                }
                else if (block.getData() == 10) {
                    drops.add(new ItemStack(block.getType(), 1, (short)2));
                }
                else if (block.getData() == 11) {
                    drops.add(new ItemStack(block.getType(), 1, (short)3));
                }
                else if (block.getData() == 12) {
                    drops.add(new ItemStack(block.getType(), 1, (short)4));
                }
                else if (block.getData() == 13) {
                    drops.add(new ItemStack(block.getType(), 1, (short)5));
                }
            }
            else if (block.getType().equals((Object)Material.WOOD_DOUBLE_STEP)) {
                if (block.getData() <= 5) {
                    drops.add(new ItemStack(block.getType(), 1, (short)block.getData()));
                }
            }
            else if (block.getType().equals((Object)Material.WOOD_STAIRS) || block.getType().equals((Object)Material.SPRUCE_WOOD_STAIRS) || block.getType().equals((Object)Material.BIRCH_WOOD_STAIRS) || block.getType().equals((Object)Material.JUNGLE_WOOD_STAIRS) || block.getType().equals((Object)Material.ACACIA_STAIRS) || block.getType().equals((Object)Material.DARK_OAK_STAIRS) || block.getType().equals((Object)Material.QUARTZ_STAIRS) || block.getType().equals((Object)Material.NETHER_BRICK_STAIRS) || block.getType().equals((Object)Material.SANDSTONE_STAIRS) || block.getType().equals((Object)Material.SMOOTH_STAIRS) || block.getType().equals((Object)Material.BRICK_STAIRS) || block.getType().equals((Object)Material.COBBLESTONE_STAIRS)) {
                if (block.getData() <= 7) {
                    drops.add(new ItemStack(block.getType(), 1, (short)0));
                }
            }
            else if (block.getType().equals((Object)Material.LEAVES)) {
                if (block.getData() <= 3) {
                    drops.add(new ItemStack(block.getType(), 1, (short)block.getData()));
                }
                else if (block.getData() == 8 || block.getData() == 12) {
                    drops.add(new ItemStack(block.getType(), 1, (short)0));
                }
                else if (block.getData() == 13 || block.getData() == 9) {
                    drops.add(new ItemStack(block.getType(), 1, (short)1));
                }
                else if (block.getData() == 10 || block.getData() == 14) {
                    drops.add(new ItemStack(block.getType(), 1, (short)2));
                }
                else if (block.getData() == 15 || block.getData() == 11) {
                    drops.add(new ItemStack(block.getType(), 1, (short)3));
                }
                else {
                    drops.add(new ItemStack(block.getType(), 1, (short)0));
                }
            }
            else if (block.getType().equals((Object)Material.LEAVES_2)) {
                if (block.getData() <= 1) {
                    drops.add(new ItemStack(block.getType(), 1, (short)block.getData()));
                }
                else if (block.getData() == 4 || block.getData() == 5 || block.getData() == 8) {
                    drops.add(new ItemStack(block.getType(), 1, (short)0));
                }
                else if (block.getData() == 13 || block.getData() == 12 || block.getData() == 9) {
                    drops.add(new ItemStack(block.getType(), 1, (short)1));
                }
                else {
                    drops.add(new ItemStack(block.getType(), 1, (short)0));
                }
            }
            else if (block.getType().equals((Object)Material.REDSTONE_WIRE)) {
                drops.add(new ItemStack(Material.REDSTONE, 1));
            }
            else if (block.getType().equals((Object)Material.IRON_DOOR_BLOCK)) {
                drops.add(new ItemStack(Material.IRON_DOOR, 1));
            }
            else if (block.getType().equals((Object)Material.REDSTONE_COMPARATOR_ON) || block.getType().equals((Object)Material.REDSTONE_COMPARATOR_OFF)) {
                drops.add(new ItemStack(Material.REDSTONE_COMPARATOR, 1));
            }
            else if (block.getType().equals((Object)Material.DIODE_BLOCK_OFF) || block.getType().equals((Object)Material.DIODE_BLOCK_ON)) {
                drops.add(new ItemStack(Material.DIODE, 1));
            }
            else if (block.getType().equals((Object)Material.REDSTONE_LAMP_OFF) || block.getType().equals((Object)Material.REDSTONE_LAMP_ON)) {
                drops.add(new ItemStack(Material.REDSTONE_LAMP_OFF, 1));
            }
            else if (block.getType().equals((Object)Material.REDSTONE_TORCH_OFF) || block.getType().equals((Object)Material.REDSTONE_TORCH_ON)) {
                drops.add(new ItemStack(Material.REDSTONE_TORCH_ON, 1));
            }
            else if (block.getType().equals((Object)Material.DOUBLE_PLANT)) {
                if (block.getData() >= 8 && block.getData() <= 11) {
                    final Iterator<ItemStack> it$1 = block.getDrops().iterator();
                    while (it$1.hasNext()) {
                        drops.add(it$1.next());
                    }
                }
                else {
                    drops.add(new ItemStack(block.getType(), 1, (short)block.getData()));
                }
            }
            else if (block.getType().equals((Object)Material.SOIL)) {
                drops.add(new ItemStack(Material.DIRT, 1));
            }
            else if (block.getType().equals((Object)Material.SKULL)) {
                for (final ItemStack drop : block.getDrops()) {
                    drops.add(drop);
                }
            }
            else if (block.getType().equals((Object)Material.FLOWER_POT)) {
                drops.add(new ItemStack(Material.FLOWER_POT_ITEM, 1));
            }
            else if (!block.getType().equals((Object)Material.SPONGE)) {
                drops.add(new ItemStack(block.getType(), 1));
            }
        }
        else if (block.getType().equals((Object)Material.NETHER_WARTS)) {
            drops.add(new ItemStack(Material.NETHER_STALK, this.getRandInt(2, 4)));
        }
        else if (block.getType().equals((Object)Material.COCOA)) {
            drops.add(new ItemStack(Material.INK_SACK, 3, (short)3));
        }
        else if (block.getType().equals((Object)Material.PUMPKIN_STEM)) {
            drops.add(new ItemStack(Material.PUMPKIN_SEEDS, 1));
        }
        else if (block.getType().equals((Object)Material.MELON_STEM)) {
            drops.add(new ItemStack(Material.MELON_SEEDS, 1));
        }
        else if (block.getType().equals((Object)Material.CARROT)) {
            drops.add(new ItemStack(Material.CARROT_ITEM, this.getRandInt(1, 4)));
        }
        else if (block.getType().equals((Object)Material.POTATO)) {
            drops.add(new ItemStack(Material.POTATO_ITEM, this.getRandInt(1, 4)));
        }
        else if (block.getType().equals((Object)Material.CROPS) && block.getData() == 7) {
            drops.add(new ItemStack(Material.SEEDS, this.getRandInt(1, 3)));
            drops.add(new ItemStack(Material.WHEAT, 1));
        }
        else {
            for (final ItemStack drop : block.getDrops(item)) {
                drops.add(drop);
            }
        }
        return drops;
    }
    
    public void pkt(final DataUser user, final Player p, final int i) {
        int pkt = user.getPkt();
        final double przelicznik = 20.0;
        int lvl = user.getLvl();
        final int pktPrzelicznik = (int)(lvl * 4.5 * lvl + (lvl * (przelicznik + 8.0) + 6.0)) * lvl / 3;
        int pktBrak = pktPrzelicznik - pkt;
        while (pkt >= pktPrzelicznik) {
            ++lvl;
            pkt -= pktPrzelicznik;
            if (lvl != user.getLvl()) {
                p.sendMessage(" �7�l� �aAwansowales na �3" + lvl + " �apoziom!");
                user.setLvl(lvl);
            }
            if (lvl >= 15 && lvl <= 100 && (lvl % 5 == 30 || lvl % 5 == 0)) {
                Bukkit.broadcastMessage(" �7�l� �3" + p.getName() + " �aawansowal na �3" + lvl + " �apoziom. Gratulacje!");
            }
        }
        if (i == 0) {
            pktBrak = pktPrzelicznik - user.getPkt();
            if (lvl == 100) {
                p.sendMessage(" �7�l� �aMasz punktow �3" + pkt + "�a.");
                p.sendMessage(" �7�l� �aMasz �3" + lvl + " �apoziom.");
            }
            else {
                p.sendMessage(" �7�l� �aMasz punktow �3" + pkt + " �ado nastepnego poziomu brakuje ci �3" + pktBrak);
                p.sendMessage(" �7�l� �aMasz �3" + lvl + " �apoziom.");
            }
        }
    }
}
