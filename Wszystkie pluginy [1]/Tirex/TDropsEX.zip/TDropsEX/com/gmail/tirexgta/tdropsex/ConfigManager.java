package com.gmail.tirexgta.tdropsex;

import com.gmail.tirexgta.tdropsex.managers.*;
import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.configuration.*;
import java.util.*;

public class ConfigManager
{
    Main plugin;
    public String xpValue;
    public double xpChance;
    public double xpChanceVip;
    public static List<DropManager> drops;
    
    static {
        ConfigManager.drops = new ArrayList<DropManager>();
    }
    
    public ConfigManager(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getConfig().options().copyDefaults(true);
        this.plugin.saveConfig();
        this.load();
    }
    
    public void load() {
        this.plugin.reloadConfig();
        this.xpValue = this.plugin.getConfig().getString("xp.value");
        this.xpChance = this.plugin.getConfig().getDouble("xp.chance");
        this.xpChanceVip = this.plugin.getConfig().getDouble("xp.chanceVip");
        if (this.plugin.getConfig().isConfigurationSection("config")) {
            ConfigManager.drops.clear();
            final ConfigurationSection section = this.plugin.getConfig().getConfigurationSection("config");
            for (final String drop : section.getKeys(false)) {
                final ConfigurationSection dropSection = section.getConfigurationSection(drop);
                final DropManager dropManager = new DropManager(dropSection, this.plugin);
                short data = 0;
                final String[] dropS = drop.split("\\:");
                if (dropS.length > 1) {
                    data = Short.parseShort(dropS[1]);
                }
                dropManager.setMaterial(Material.getMaterial(dropS[0]), 0, data);
                if (dropSection.isString("name")) {
                    dropManager.setName(dropSection.getString("name"));
                }
                if (dropSection.isDouble("chance")) {
                    dropManager.setChance(dropSection.getDouble("chance"));
                }
                if (dropSection.isDouble("chanceVip")) {
                    dropManager.setChanceVip(dropSection.getDouble("chanceVip"));
                }
                if (dropSection.isString("value")) {
                    dropManager.setValue(dropSection.getString("value"));
                }
                if (dropSection.isInt("y")) {
                    dropManager.setY(dropSection.getInt("y"));
                }
                if (dropSection.isInt("exp")) {
                    dropManager.setExp(dropSection.getInt("exp"));
                }
                if (dropSection.isList("tool")) {
                    dropManager.setTools(new ArrayList<Material>());
                    final List<String> tools = (List<String>)dropSection.getStringList("tool");
                    for (final String tool : tools) {
                        final String[] splitTool = tool.split("\\|");
                        if (splitTool.length > 1) {
                            dropManager.addTools(Material.getMaterial(splitTool[0]));
                            dropManager.getToolsName().put(Material.getMaterial(splitTool[0]), splitTool[1]);
                        }
                        else if (splitTool.length == 1) {
                            dropManager.addTools(Material.getMaterial(splitTool[0]));
                        }
                        else {
                            dropManager.addTools(Material.getMaterial(tool));
                        }
                    }
                }
                if (dropSection.isList("biome")) {
                    dropManager.setBioms(new ArrayList<Biome>());
                    final List<String> bioms = (List<String>)dropSection.getStringList("biome");
                    for (final String biom : bioms) {
                        final String[] splitBiom = biom.split("\\|");
                        if (splitBiom.length > 1) {
                            dropManager.addBioms(Biome.valueOf(splitBiom[0]));
                            dropManager.getBiomsName().put(Biome.valueOf(splitBiom[0]), splitBiom[1]);
                        }
                        else if (splitBiom.length == 1) {
                            dropManager.addTools(Material.getMaterial(splitBiom[0]));
                        }
                        else {
                            dropManager.addTools(Material.getMaterial(biom));
                        }
                    }
                }
                if (dropSection.isString("message")) {
                    dropManager.setMessage(dropSection.getString("message"));
                }
                if (dropSection.isString("messageMore")) {
                    dropManager.setMessageMore(dropSection.getString("messageMore"));
                }
                if (dropSection.isInt("pkt")) {
                    dropManager.setPkt(dropSection.getInt("pkt"));
                }
                dropManager.insert();
            }
        }
    }
    
    public void reload() {
        this.load();
    }
}
