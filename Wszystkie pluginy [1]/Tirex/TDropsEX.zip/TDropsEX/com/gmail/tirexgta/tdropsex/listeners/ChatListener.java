package com.gmail.tirexgta.tdropsex.listeners;

import com.gmail.tirexgta.tdropsex.*;
import org.bukkit.plugin.*;
import org.bukkit.event.player.*;
import org.bukkit.entity.*;
import com.gmail.tirexgta.ttoolsex.database.*;
import org.bukkit.event.*;

public class ChatListener implements Listener
{
    Main plugin;
    
    public ChatListener(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void chat(final AsyncPlayerChatEvent e) {
        final Player p = e.getPlayer();
        final DataUser user = Datasource.getUserData(p);
        if (user == null) {
            return;
        }
        String format = e.getFormat();
        format = format.replace("{PUNKTY_KOPANIA}", Integer.toString(user.getLvl()));
        e.setFormat(format);
        if (user.getLvl() >= 3 || p.hasPermission("tirex.chat.pkt")) {
            return;
        }
        p.sendMessage(" �7�l� �aAby pisac na czacie musisz miec �33 �apoziom!");
        e.setCancelled(true);
    }
}
