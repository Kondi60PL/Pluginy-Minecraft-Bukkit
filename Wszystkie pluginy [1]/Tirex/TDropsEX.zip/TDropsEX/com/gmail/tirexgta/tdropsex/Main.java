package com.gmail.tirexgta.tdropsex;

import org.bukkit.plugin.java.*;
import com.gmail.tirexgta.tdropsex.commands.*;
import com.gmail.tirexgta.tdropsex.listeners.*;
import com.gmail.tirexgta.tdropsex.managers.*;
import org.bukkit.*;

public class Main extends JavaPlugin
{
    static Main plugin;
    public ConfigManager configManager;
    StoneCommand stoneCommand;
    CobbleCommand cobbleCommand;
    PktCommand pktCommand;
    public BlockBreakListener blockBreakListener;
    public DropToEqListener dropToEqListener;
    ChatListener chatListener;
    InventoryListener inventoryListener;
    public BlockManager blockManager;
    
    public void onEnable() {
        Main.plugin = this;
        this.configManager = new ConfigManager(this);
        this.stoneCommand = new StoneCommand(this, "stone");
        this.cobbleCommand = new CobbleCommand(this, "cobble");
        this.pktCommand = new PktCommand(this, "pkt");
        this.dropToEqListener = new DropToEqListener(this);
        this.chatListener = new ChatListener(this);
        this.inventoryListener = new InventoryListener(this);
        this.blockManager = new BlockManager();
    }
    
    public void onDisable() {
    }
    
    public static Main getInstance() {
        return Main.plugin;
    }
    
    public static String fixMsg(final String s) {
        if (s != null) {
            return ChatColor.translateAlternateColorCodes('&', s);
        }
        return null;
    }
}
