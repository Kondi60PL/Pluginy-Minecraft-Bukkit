package com.gmail.tirexgta.tdropsex.commands;

import com.gmail.tirexgta.tdropsex.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.gmail.tirexgta.ttoolsex.database.*;

public class PktCommand implements CommandExecutor
{
    Main plugin;
    
    public PktCommand(final Main plugin, final String cmd) {
        super();
        this.plugin = plugin;
        this.plugin.getCommand(cmd).setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("STOP!");
                return true;
            }
            final Player p = (Player)sender;
            this.send(sender, p.getName());
        }
        else if (args.length > 0) {
            if (args.length != 1) {
                final Player p = (Player)sender;
                this.send(sender, p.getName());
                return true;
            }
            this.send(sender, args[0]);
        }
        return false;
    }
    
    void send(final CommandSender sender, final String p) {
        final DataUser user = Datasource.getUserByNick(p);
        if (user != null) {
            Main.getInstance().blockManager.pkt(user, (Player)sender, 0);
        }
        else {
            sender.sendMessage(" �7�l� �cNie ma takiego gracza!");
        }
    }
}
