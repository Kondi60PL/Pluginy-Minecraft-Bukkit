package com.gmail.tirexgta.tdropsex.listeners;

import com.gmail.tirexgta.tdropsex.*;
import org.bukkit.plugin.*;
import org.bukkit.event.block.*;
import org.bukkit.entity.*;
import org.bukkit.block.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.*;
import java.util.*;

public class DropToEqListener implements Listener
{
    Main plugin;
    
    public DropToEqListener(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void blockBreak(final BlockBreakEvent e) {
        final Player p = e.getPlayer();
        final Block b = e.getBlock();
        if (p.getGameMode().equals((Object)GameMode.SURVIVAL)) {
            Main.getInstance().blockManager.breakBlock(p, b);
        }
    }
    
    @EventHandler
    public void onTnt(final EntityExplodeEvent e) {
        final List<Block> blocks = (List<Block>)e.blockList();
        for (final Block block : blocks) {
            final Material type = block.getType();
            if (type.equals((Object)Material.DIAMOND_ORE)) {
                block.setType(Material.AIR);
            }
            else if (type.equals((Object)Material.GOLD_ORE)) {
                block.setType(Material.AIR);
            }
            else if (type.equals((Object)Material.IRON_ORE)) {
                block.setType(Material.AIR);
            }
            else if (type.equals((Object)Material.COAL_ORE)) {
                block.setType(Material.AIR);
            }
            else if (type.equals((Object)Material.REDSTONE_ORE)) {
                block.setType(Material.AIR);
            }
            else {
                if (!type.equals((Object)Material.EMERALD_ORE)) {
                    continue;
                }
                block.setType(Material.AIR);
            }
        }
    }
}
