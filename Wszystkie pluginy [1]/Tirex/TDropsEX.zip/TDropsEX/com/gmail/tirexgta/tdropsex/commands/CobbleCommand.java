package com.gmail.tirexgta.tdropsex.commands;

import com.gmail.tirexgta.tdropsex.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.gmail.tirexgta.tdropsex.managers.*;

public class CobbleCommand implements CommandExecutor
{
    Main plugin;
    
    public CobbleCommand(final Main plugin, final String cmd) {
        super();
        this.plugin = plugin;
        this.plugin.getCommand(cmd).setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("nie ladnie tak z konsoli!");
            return true;
        }
        if (BlockManager.cobble.contains(sender.getName().toLowerCase())) {
            BlockManager.cobble.remove(sender.getName().toLowerCase());
            sender.sendMessage("�aDrop cobble wlaczony!");
        }
        else {
            BlockManager.cobble.add(sender.getName().toLowerCase());
            sender.sendMessage("�aDrop cobble wylaczony!");
        }
        return false;
    }
}
