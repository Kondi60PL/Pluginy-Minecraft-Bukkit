package com.gmail.tirexgta.tdropsex.commands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.gmail.tirexgta.tdropsex.*;
import com.gmail.tirexgta.tdropsex.managers.*;
import org.bukkit.*;
import org.bukkit.block.*;
import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.inventory.meta.*;

public class StoneCommand implements CommandExecutor
{
    Main plugin;
    Inventory inv;
    Inventory invVip;
    
    public StoneCommand(final Main plugin, final String cmd) {
        super();
        this.plugin = plugin;
        this.plugin.getCommand(cmd).setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (args.length > 0) {
            if (args[0].equalsIgnoreCase("reload")) {
                if (sender.hasPermission("tirex.reload.stone")) {
                    this.plugin.configManager.reload();
                    this.inv = null;
                    this.invVip = null;
                    sender.sendMessage(Main.fixMsg("&aDone!"));
                }
                else {
                    if (!(sender instanceof Player)) {
                        this.info(sender, null, 0);
                        return false;
                    }
                    this.info(sender, (Player)sender, 0);
                }
            }
            else if (args[0].equalsIgnoreCase("vip")) {
                if (!(sender instanceof Player)) {
                    this.info(sender, null, 1);
                    return false;
                }
                this.info(sender, (Player)sender, 1);
            }
        }
        else {
            if (!(sender instanceof Player)) {
                this.info(sender, null, 0);
                return false;
            }
            this.info(sender, (Player)sender, 0);
        }
        return false;
    }
    
    void info(final CommandSender sender, final Player p, final int i) {
        if (i == 0 && this.inv == null && p != null) {
            int invsize = 0;
            for (int in = 0; in < 7; ++in) {
                if (in * 9 >= ConfigManager.drops.size()) {
                    invsize = in * 9;
                    in = 7;
                }
            }
            this.inv = Bukkit.createInventory((InventoryHolder)null, invsize, "�6Dropy ze Stone!");
            for (final DropManager drop : ConfigManager.drops) {
                final List<String> lore = new ArrayList<String>();
                final String itemName = Main.fixMsg("�a" + drop.getName() + ": �e" + drop.getChance() + "%");
                if (drop.getTools() != null) {
                    final StringBuilder sb = new StringBuilder();
                    int size = 1;
                    final List<String> msgs = new ArrayList<String>();
                    for (final Material tool : drop.getTools()) {
                        final String name = drop.getTools(tool);
                        if (name != null) {
                            msgs.add(name);
                        }
                    }
                    for (final String msg : msgs) {
                        if (msgs.size() == size) {
                            sb.append(msg);
                        }
                        else {
                            sb.append(msg).append(",").append(" ");
                        }
                        ++size;
                    }
                    if (size++ != 1) {
                        lore.add(" �7�l� Wykopac mozna: �e" + sb.toString());
                    }
                }
                if (drop.getBioms() != null) {
                    final StringBuilder sb = new StringBuilder();
                    int size = 1;
                    final List<String> msgs = new ArrayList<String>();
                    for (final Biome biom : drop.getBioms()) {
                        final String name = drop.getBioms(biom);
                        if (name != null) {
                            msgs.add(name);
                        }
                    }
                    for (final String msg : msgs) {
                        if (msgs.size() == size) {
                            sb.append(msg);
                        }
                        else {
                            sb.append(msg).append(",").append(" ");
                        }
                        ++size;
                    }
                    if (size != 1) {
                        lore.add(" �7�l� Na biomach: �e" + sb.toString());
                    }
                }
                if (drop.getY() != 0 && drop.getY() != 256) {
                    lore.add(" �7�l� Od poziomu: �eY: <" + drop.getY());
                }
                final ItemStack item = new ItemStack(drop.getMaterial().getType(), drop.getMaterial().getAmount(), (short)drop.getMaterial().getData().getData());
                item.setAmount(1);
                final ItemMeta meta = item.getItemMeta();
                meta.setDisplayName(itemName);
                meta.setLore((List)lore);
                item.setItemMeta(meta);
                this.inv.addItem(new ItemStack[] { item });
            }
            p.openInventory(this.inv);
        }
        else if (i == 1 && this.invVip == null && p != null) {
            int invsize = 0;
            for (int in = 0; in < 7; ++in) {
                if (in * 9 >= ConfigManager.drops.size()) {
                    invsize = in * 9;
                    in = 7;
                }
            }
            this.invVip = Bukkit.createInventory((InventoryHolder)null, invsize, "�6Dropy ze Stone!");
            for (final DropManager drop : ConfigManager.drops) {
                final List<String> lore = new ArrayList<String>();
                final String itemName = Main.fixMsg("�a" + drop.getName() + ": �e" + drop.getChanceVip() + "%");
                if (drop.getTools() != null) {
                    final StringBuilder sb = new StringBuilder();
                    int size = 1;
                    final List<String> msgs = new ArrayList<String>();
                    for (final Material tool : drop.getTools()) {
                        final String name = drop.getTools(tool);
                        if (name != null) {
                            msgs.add(name);
                        }
                    }
                    for (final String msg : msgs) {
                        if (msgs.size() == size) {
                            sb.append(msg);
                        }
                        else {
                            sb.append(msg).append(",").append(" ");
                        }
                        ++size;
                    }
                    if (size++ != 1) {
                        lore.add(" �7�l� Wykopac mozna: �e" + sb.toString());
                    }
                }
                if (drop.getBioms() != null) {
                    final StringBuilder sb = new StringBuilder();
                    int size = 1;
                    final List<String> msgs = new ArrayList<String>();
                    for (final Biome biom : drop.getBioms()) {
                        final String name = drop.getBioms(biom);
                        if (name != null) {
                            msgs.add(name);
                        }
                    }
                    for (final String msg : msgs) {
                        if (msgs.size() == size) {
                            sb.append(msg);
                        }
                        else {
                            sb.append(msg).append(",").append(" ");
                        }
                        ++size;
                    }
                    if (size != 1) {
                        lore.add(" �7�l� Na biomach: �e" + sb.toString());
                    }
                }
                if (drop.getY() != 0 && drop.getY() != 256) {
                    lore.add(" �7�l� Od poziomu: �eY: <" + drop.getY());
                }
                final ItemStack item = new ItemStack(drop.getMaterial().getType(), drop.getMaterial().getAmount(), (short)drop.getMaterial().getData().getData());
                item.setAmount(1);
                final ItemMeta meta = item.getItemMeta();
                meta.setDisplayName(itemName);
                meta.setLore((List)lore);
                item.setItemMeta(meta);
                this.invVip.addItem(new ItemStack[] { item });
            }
            p.openInventory(this.invVip);
        }
        else if (i == 0 && this.inv != null && p != null) {
            p.openInventory(this.inv);
        }
        else if (i == 1 && this.invVip != null && p != null) {
            p.openInventory(this.invVip);
        }
        else if (p == null && sender != null) {
            sender.sendMessage("");
            sender.sendMessage(" �e�l� �aSzansa na wykopanie surowcow ze �estone:");
            for (final DropManager drop2 : ConfigManager.drops) {
                if (i == 0) {
                    sender.sendMessage("  �e�l� �a" + Main.fixMsg(drop2.getName()) + ": �e" + drop2.getChance() + "%");
                }
                else {
                    sender.sendMessage("  �e�l� �a" + Main.fixMsg(drop2.getName()) + ": �e" + drop2.getChanceVip() + "%");
                }
                if (drop2.getTools() != null) {
                    final StringBuilder sb2 = new StringBuilder();
                    int size2 = 1;
                    final List<String> msgs2 = new ArrayList<String>();
                    for (final Material tool2 : drop2.getTools()) {
                        final String name2 = drop2.getTools(tool2);
                        if (name2 != null) {
                            msgs2.add(name2);
                        }
                    }
                    for (final String msg2 : msgs2) {
                        if (msgs2.size() == size2) {
                            sb2.append(msg2);
                        }
                        else {
                            sb2.append(msg2).append(",").append(" ");
                        }
                        ++size2;
                    }
                    if (size2++ != 1) {
                        sender.sendMessage("   �7�l� Wykopac mozna: �e" + sb2.toString());
                    }
                }
                if (drop2.getBioms() != null) {
                    final StringBuilder sb2 = new StringBuilder();
                    int size2 = 1;
                    final List<String> msgs2 = new ArrayList<String>();
                    for (final Biome biom2 : drop2.getBioms()) {
                        final String name2 = drop2.getBioms(biom2);
                        if (name2 != null) {
                            msgs2.add(name2);
                        }
                    }
                    for (final String msg2 : msgs2) {
                        if (msgs2.size() == size2) {
                            sb2.append(msg2);
                        }
                        else {
                            sb2.append(msg2).append(",").append(" ");
                        }
                        ++size2;
                    }
                    if (size2 != 1) {
                        sender.sendMessage("   �7�l� Na biomach: �e" + sb2.toString());
                    }
                }
                if (drop2.getY() != 0 && drop2.getY() != 256) {
                    sender.sendMessage("   �7�l� Od poziomu: �eY: <" + drop2.getY());
                }
            }
            sender.sendMessage("");
        }
    }
}
