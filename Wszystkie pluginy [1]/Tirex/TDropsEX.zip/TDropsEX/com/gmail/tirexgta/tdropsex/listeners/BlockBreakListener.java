package com.gmail.tirexgta.tdropsex.listeners;

import org.bukkit.event.entity.*;
import java.util.*;
import org.bukkit.event.block.*;
import com.gmail.tirexgta.tdropsex.*;
import com.gmail.tirexgta.tdropsex.managers.*;
import org.bukkit.entity.*;
import org.bukkit.block.*;
import org.bukkit.event.*;
import org.bukkit.enchantments.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;
import org.apache.commons.lang.*;
import com.gmail.tirexgta.ttoolsex.database.*;
import org.bukkit.*;
import org.bukkit.command.*;

public class BlockBreakListener implements Listener
{
    Main plugin;
    public static final Random random;
    
    static {
        random = new Random();
    }
    
    public BlockBreakListener(final Main plugin) {
        super();
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onTnt(final EntityExplodeEvent e) {
        final List<Block> blocks = (List<Block>)e.blockList();
        for (final Block block : blocks) {
            final Material type = block.getType();
            if (type.equals((Object)Material.DIAMOND_ORE)) {
                block.setType(Material.AIR);
            }
            else if (type.equals((Object)Material.GOLD_ORE)) {
                block.setType(Material.AIR);
            }
            else if (type.equals((Object)Material.IRON_ORE)) {
                block.setType(Material.AIR);
            }
            else if (type.equals((Object)Material.COAL_ORE)) {
                block.setType(Material.AIR);
            }
            else if (type.equals((Object)Material.REDSTONE_ORE)) {
                block.setType(Material.AIR);
            }
            else {
                if (!type.equals((Object)Material.EMERALD_ORE)) {
                    continue;
                }
                block.setType(Material.AIR);
            }
        }
    }
    
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(final BlockBreakEvent e) {
        final Player p = e.getPlayer();
        if (p.getGameMode().equals((Object)GameMode.CREATIVE)) {
            return;
        }
        final Block block = e.getBlock();
        if (block.getType().equals((Object)Material.DIAMOND_ORE)) {
            e.setCancelled(true);
            block.setType(Material.AIR);
        }
        else if (block.getType().equals((Object)Material.GOLD_ORE)) {
            e.setCancelled(true);
            block.setType(Material.AIR);
        }
        else if (block.getType().equals((Object)Material.IRON_ORE)) {
            e.setCancelled(true);
            block.setType(Material.AIR);
        }
        else if (block.getType().equals((Object)Material.COAL_ORE)) {
            e.setCancelled(true);
            block.setType(Material.AIR);
        }
        else if (block.getType().equals((Object)Material.REDSTONE_ORE)) {
            e.setCancelled(true);
            block.setType(Material.AIR);
        }
        else if (block.getType().equals((Object)Material.EMERALD_ORE)) {
            e.setCancelled(true);
            block.setType(Material.AIR);
        }
        else if (block.getType().equals((Object)Material.STONE)) {
            final Biome biom = block.getBiome();
            final boolean isDrop = false;
            for (final DropManager drop : ConfigManager.drops) {
                if (!isDrop && this.isY(p, drop.getY()) && this.isTool(p, drop.getTools()) && this.isBiome(drop.getBioms(), biom)) {
                    this.dropExp(p, this.plugin.configManager.xpChance, this.plugin.configManager.xpChanceVip, this.plugin.configManager.xpValue, e);
                }
            }
        }
    }
    
    void dropExp(final Player p, double chance, double chanceVip, final String value, final BlockBreakEvent e) {
        final String[] splitValue = value.split("\\-");
        final double ilosc = this.getRandomInteger(Integer.parseInt(splitValue[0]), Integer.parseInt(splitValue[1]));
        final ItemStack itemInHand = p.getItemInHand();
        if (p.hasPermission("tirex.vip")) {
            if (chanceVip == 0.0) {
                chanceVip = chance;
            }
            if (chanceVip != 0.0 && itemInHand != null) {
                final ItemMeta meta = itemInHand.getItemMeta();
                if (meta != null && meta.hasEnchant(Enchantment.LOOT_BONUS_BLOCKS)) {
                    chanceVip += meta.getEnchantLevel(Enchantment.LOOT_BONUS_BLOCKS) * 0.1 / chanceVip;
                }
            }
            if (this.getChance(chanceVip)) {
                p.giveExp((int)(ilosc * chanceVip));
            }
        }
        else {
            if (chanceVip != 0.0 && itemInHand != null) {
                final ItemMeta meta = itemInHand.getItemMeta();
                if (meta != null && meta.hasEnchant(Enchantment.LOOT_BONUS_BLOCKS)) {
                    chance += meta.getEnchantLevel(Enchantment.LOOT_BONUS_BLOCKS) * 0.1 / chance;
                }
            }
            if (this.getChance(chance)) {
                p.giveExp((int)(ilosc * chance));
            }
        }
    }
    
    boolean isY(final Player p, final int y) {
        return y == 0 || p.getLocation().getBlockY() <= y;
    }
    
    boolean isTool(final Player p, final List<Material> tools) {
        boolean returned = false;
        if (tools != null) {
            final ItemStack itemInHand = p.getItemInHand();
            if (itemInHand != null && tools.contains(itemInHand.getType())) {
                returned = true;
            }
            return returned;
        }
        return true;
    }
    
    boolean isBiome(final List<Biome> bioms, final Biome biom) {
        boolean returned = false;
        if (bioms != null) {
            if (bioms.contains(biom)) {
                returned = true;
            }
            return returned;
        }
        return true;
    }
    
    boolean drop(final Player p, final Block block, final Material item, double chance, double chanceVip, final String value, final String message, final String messageMore, final int pkt) {
        final ItemStack itemInHand = p.getItemInHand();
        if (p.hasPermission("tirex.vip")) {
            if (chanceVip == 0.0) {
                chanceVip = chance;
            }
            if (chanceVip != 0.0 && itemInHand != null) {
                final ItemMeta meta = itemInHand.getItemMeta();
                if (meta != null && meta.hasEnchant(Enchantment.LOOT_BONUS_BLOCKS)) {
                    chanceVip += meta.getEnchantLevel(Enchantment.LOOT_BONUS_BLOCKS) * 0.1 / chanceVip;
                }
            }
            if (this.getChance(chanceVip)) {
                final String[] split = value.split("-");
                final int ilosc = this.getRandomInteger(Integer.parseInt(split[0]), Integer.parseInt(split[1]));
                this.dropToEq(p, item, ilosc, (byte)0, chanceVip, block.getLocation(), message, messageMore, pkt);
                return true;
            }
        }
        else {
            if (chance != 0.0 && itemInHand != null) {
                final ItemMeta meta = itemInHand.getItemMeta();
                if (meta != null && meta.hasEnchant(Enchantment.LOOT_BONUS_BLOCKS)) {
                    chance += meta.getEnchantLevel(Enchantment.LOOT_BONUS_BLOCKS) * 0.1 / chance;
                }
            }
            if (this.getChance(chance)) {
                final String[] split = value.split("-");
                final int ilosc = this.getRandomInteger(Integer.parseInt(split[0]), Integer.parseInt(split[1]));
                this.dropToEq(p, item, ilosc, (byte)0, chance, block.getLocation(), message, messageMore, pkt);
                return true;
            }
        }
        return false;
    }
    
    public int getRandomInteger(final int min, final int max) throws IllegalArgumentException {
        Validate.isTrue(max > min, "Max can't be smaller than min!");
        return BlockBreakListener.random.nextInt(max - min + 1) + min;
    }
    
    public int getInteger(final int max) throws IllegalArgumentException {
        return BlockBreakListener.random.nextInt(max);
    }
    
    public double getRandpDouble(final double min, final double max) throws IllegalArgumentException {
        Validate.isTrue(max > min, "Max can't be smaller than min!");
        return BlockBreakListener.random.nextDouble() * (max - min) + min;
    }
    
    public boolean getChance(double chance) {
        if (chance > 100.0) {
            chance = 100.0;
        }
        return chance >= 100.0 || chance >= this.getRandpDouble(0.0, 100.0);
    }
    
    void dropToEq(final Player p, final Material item, final int amount, final byte data, final double chance, final Location loc, String message, String messageMore, final int pkt) {
        if (p.getInventory().firstEmpty() >= 0) {
            p.getInventory().addItem(new ItemStack[] { new ItemStack(item, amount, (short)data) });
        }
        else {
            p.getWorld().dropItem(loc, new ItemStack(item, amount, (short)data));
        }
        if (amount > 1) {
            if (messageMore != null) {
                messageMore = messageMore.replace("%pkt%", Integer.toString(amount * pkt));
                messageMore = messageMore.replace("%value%", Integer.toString(amount));
                p.sendMessage(Main.fixMsg(messageMore));
            }
        }
        else if (message != null) {
            message = message.replace("%pkt%", Integer.toString(amount * pkt));
            message = message.replace("%value%", Integer.toString(amount));
            p.sendMessage(Main.fixMsg(message));
        }
    }
    
    public static void pkt(final DataUser user, final Player p, final int i) {
        final int pkt = user.getPkt();
        final double przelicznik = 20.9;
        final String lvlS = getLvlAndPoints(pkt, przelicznik);
        if (lvlS == null) {
            return;
        }
        final String[] lvlSplit = lvlS.split("\\-");
        final int lvl = Integer.parseInt(lvlSplit[0]);
        final int pktLast = Integer.parseInt(lvlSplit[1]);
        final int pktBrak = (int)(lvl * przelicznik) - pktLast;
        if (i == 0) {
            if (lvl == 100) {
                p.sendMessage(" �7�l� �aMasz punktow �3" + pkt + "�a.");
                p.sendMessage(" �7�l� �aMasz �3" + lvl + " �apoziom.");
            }
            else {
                p.sendMessage(" �7�l� �aMasz punktow �3" + pkt + " �ado nastepnego poziomu brakuje ci �3" + pktBrak);
                p.sendMessage(" �7�l� �aMasz �3" + lvl + " �apoziom.");
            }
        }
        else if (i == 1) {
            p.sendMessage(" �7�l� �aAwansowales na �3" + lvl + " �apoziom.");
            if (lvl == 10) {
                Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), "is give " + lvl + " " + p.getName());
            }
            else if (lvl == 20) {
                Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), "is give " + lvl + " " + p.getName());
                Bukkit.broadcastMessage(" �7�l� �aGracz �3" + p.getName() + " �aawansowal na �3" + lvl + " �apoziom.");
            }
            else if (lvl == 30) {
                Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), "is give " + lvl + " " + p.getName());
                Bukkit.broadcastMessage(" �7�l� �aGracz �3" + p.getName() + " �aawansowal na �3" + lvl + " �apoziom.");
            }
            else if (lvl == 40) {
                Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), "is give " + lvl + " " + p.getName());
                Bukkit.broadcastMessage(" �7�l� �aGracz �3" + p.getName() + " �aawansowal na �3" + lvl + " �apoziom.");
            }
            else if (lvl == 50) {
                Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), "is give " + lvl + " " + p.getName());
                Bukkit.broadcastMessage(" �7�l� �aGracz �3" + p.getName() + " �aawansowal na �3" + lvl + " �apoziom.");
            }
            else if (lvl == 60) {
                Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), "is give " + lvl + " " + p.getName());
                Bukkit.broadcastMessage(" �7�l� �aGracz �3" + p.getName() + " �aawansowal na �3" + lvl + " �apoziom.");
            }
            else if (lvl == 70) {
                Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), "is give " + lvl + " " + p.getName());
                Bukkit.broadcastMessage(" �7�l� �aGracz �3" + p.getName() + " �aawansowal na �3" + lvl + " �apoziom.");
            }
            else if (lvl == 80) {
                Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), "is give " + lvl + " " + p.getName());
                Bukkit.broadcastMessage(" �7�l� �aGracz �3" + p.getName() + " �aawansowal na �3" + lvl + " �apoziom.");
            }
            else if (lvl == 90) {
                Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), "is give " + lvl + " " + p.getName());
                Bukkit.broadcastMessage(" �7�l� �aGracz �3" + p.getName() + " �aawansowal na �3" + lvl + " �apoziom.");
            }
            else if (lvl == 100) {
                Bukkit.dispatchCommand((CommandSender)Bukkit.getConsoleSender(), "is give " + lvl + " " + p.getName());
                Bukkit.broadcastMessage(" �7�l� �aGracz �3" + p.getName() + " �aawansowal na �3" + lvl + " �apoziom.");
            }
        }
    }
    
    static String getLvlAndPoints(int pkt, final double przelicznik) {
        int lvl;
        for (lvl = 1; pkt <= 0; pkt = -(int)(pkt - lvl * przelicznik), lvl = 1) {
            if (lvl == 100) {
                return String.valueOf(lvl) + "-" + pkt;
            }
            if (pkt < lvl * 1.9) {
                return String.valueOf(lvl) + "-" + pkt;
            }
        }
        return String.valueOf(lvl) + "-" + pkt;
    }
}
