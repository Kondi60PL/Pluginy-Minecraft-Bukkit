package com.gmail.tirexgta.tdropsex.listeners;

import com.gmail.tirexgta.tdropsex.*;
import org.bukkit.plugin.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.event.*;

public class InventoryListener implements Listener
{
    Main plugin;
    
    public InventoryListener(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
    }
    
    @EventHandler
    public void invinteract(final InventoryClickEvent e) {
        final Inventory inv = e.getInventory();
        if (inv == null) {
            return;
        }
        if (!inv.getTitle().equals("�6Dropy ze Stone!")) {
            return;
        }
        e.setCancelled(true);
        e.setResult(Event.Result.DENY);
        e.getWhoClicked().openInventory(inv);
    }
}
