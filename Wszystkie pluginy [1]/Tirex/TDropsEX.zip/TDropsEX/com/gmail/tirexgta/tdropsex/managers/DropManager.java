package com.gmail.tirexgta.tdropsex.managers;

import org.bukkit.configuration.*;
import org.bukkit.inventory.*;
import org.bukkit.*;
import java.util.*;
import org.bukkit.block.*;
import com.gmail.tirexgta.tdropsex.*;

public class DropManager
{
    Main plugin;
    ConfigurationSection section;
    ItemStack drop;
    String name;
    double chance;
    double chanceVip;
    String value;
    int minValue;
    int maxValue;
    int y;
    List<Material> tools;
    HashMap<Material, String> toolsName;
    List<Biome> bioms;
    HashMap<Biome, String> biomsName;
    String message;
    String messageMore;
    int exp;
    int pkt;
    
    public DropManager(final ConfigurationSection section, final Main plugin) {
        super();
        this.chance = 0.0;
        this.chanceVip = 0.0;
        this.value = "0-0";
        this.minValue = 0;
        this.maxValue = 0;
        this.y = 256;
        this.toolsName = new HashMap<Material, String>();
        this.biomsName = new HashMap<Biome, String>();
        this.exp = 0;
        this.pkt = 0;
        this.plugin = plugin;
        this.section = section;
    }
    
    public void setMaterial(final Material m, final int amount, final short data) {
        this.drop = new ItemStack(m, 0, data);
    }
    
    public void setName(final String s) {
        this.name = s;
    }
    
    public void setChance(final double d) {
        this.chance = d;
    }
    
    public void setChanceVip(final double d) {
        this.chanceVip = d;
    }
    
    public void setValue(final String s) {
        this.value = s;
        if (this.value == null) {
            return;
        }
        final String[] sS = this.value.split("\\-");
        if (sS.length >= 1) {
            this.minValue = Integer.parseInt(sS[0]);
        }
        if (sS.length >= 2) {
            this.maxValue = Integer.parseInt(sS[1]);
        }
    }
    
    public void setY(final int i) {
        this.y = i;
    }
    
    public void setTools(final List<Material> l) {
        this.tools = l;
    }
    
    public void setBioms(final List<Biome> l) {
        this.bioms = l;
    }
    
    public void setMessage(final String s) {
        this.message = s;
    }
    
    public void setMessageMore(final String s) {
        this.messageMore = s;
    }
    
    public void setPkt(final int v) {
        this.pkt = v;
    }
    
    public void setExp(final int v) {
        this.exp = v;
    }
    
    public ItemStack getMaterial() {
        return this.drop;
    }
    
    public String getName() {
        return this.name;
    }
    
    public double getChance() {
        return this.chance;
    }
    
    public double getChanceVip() {
        return this.chanceVip;
    }
    
    public String getValue() {
        return this.value;
    }
    
    public int getY() {
        return this.y;
    }
    
    public List<Material> getTools() {
        return this.tools;
    }
    
    public List<Biome> getBioms() {
        return this.bioms;
    }
    
    public String getMessage() {
        return this.message;
    }
    
    public String getMessageMore() {
        return this.messageMore;
    }
    
    public int getPkt() {
        return this.pkt;
    }
    
    public int getMinValue() {
        return this.minValue;
    }
    
    public int getMaxValue() {
        return this.maxValue;
    }
    
    public int getExp() {
        return this.exp;
    }
    
    public HashMap<Material, String> getToolsName() {
        return this.toolsName;
    }
    
    public HashMap<Biome, String> getBiomsName() {
        return this.biomsName;
    }
    
    public String getTools(final Material v) {
        if (this.toolsName.containsKey(v)) {
            return this.toolsName.get(v);
        }
        return null;
    }
    
    public String getBioms(final Biome v) {
        if (this.biomsName.containsKey(v)) {
            return this.biomsName.get(v);
        }
        return null;
    }
    
    public void addTools(final Material v) {
        if (!this.tools.contains(v)) {
            this.tools.add(v);
        }
    }
    
    public void addBioms(final Biome v) {
        if (!this.bioms.contains(v)) {
            this.bioms.add(v);
        }
    }
    
    public void insert() {
        if (!ConfigManager.drops.contains(this)) {
            ConfigManager.drops.add(this);
        }
    }
    
    public void remove() {
        if (ConfigManager.drops.contains(this)) {
            ConfigManager.drops.remove(this);
        }
    }
    
    void value() {
        if (this.value != null) {
            final String[] splitValue = this.value.split("\\-");
            this.minValue = Integer.parseInt(splitValue[0]);
            this.maxValue = Integer.parseInt(splitValue[1]);
        }
    }
}
