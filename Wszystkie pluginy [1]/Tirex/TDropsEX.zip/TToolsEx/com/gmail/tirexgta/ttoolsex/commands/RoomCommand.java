package com.gmail.tirexgta.ttoolsex.commands;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.*;

public class RoomCommand implements CommandExecutor
{
    Main plugin;
    
    public RoomCommand(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getCommand("warp").setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (args.length == 0) {
            sender.sendMessage("Nie ma takiego warpu!");
            return false;
        }
        if (args[0].equalsIgnoreCase("set")) {
            if (!sender.hasPermission("tirex.warp.set")) {
                sender.sendMessage("Nie masz uprawnien!");
                return false;
            }
            if (!(sender instanceof Player)) {
                return false;
            }
            if (args.length != 2) {
                return false;
            }
            final Player p = (Player)sender;
            this.plugin.config.warps.put(args[1].toLowerCase(), new WarpManager(args[1], p.getLocation()));
            this.plugin.config.save();
        }
        else if (args[0].equalsIgnoreCase("remove")) {
            if (!sender.hasPermission("tirex.warp.remove")) {
                sender.sendMessage("Nie masz uprawnien!");
                return false;
            }
            if (args.length != 2) {
                return false;
            }
            if (!this.plugin.config.warps.containsKey(args[1].toLowerCase())) {
                sender.sendMessage("Nie ma takiego warpa!");
                return false;
            }
            this.plugin.config.warps.remove(args[1].toLowerCase());
            this.plugin.config.save();
        }
        else {
            if (args.length < 1 || !this.plugin.config.warps.containsKey(args[0].toLowerCase())) {
                sender.sendMessage("Nie ma takiego warpu!");
                return false;
            }
            if (!(sender instanceof Player)) {
                return false;
            }
            if (!sender.hasPermission("tirex.warps." + args[0].toLowerCase())) {
                sender.sendMessage("Nie masz uprawnien!");
                return false;
            }
            final Player p = (Player)sender;
            if (sender.hasPermission("tirex.warp.nodelay")) {
                final Location loc = this.plugin.config.warps.get(args[0].toLowerCase()).getLoc();
                p.teleport(loc);
                loc.getWorld().refreshChunk(loc.getBlockX(), loc.getBlockZ());
                sender.sendMessage("�6Zostales teleportowany!");
            }
            else {
                if (this.plugin.teleportCancelListener.teleport.contains(p)) {
                    sender.sendMessage("Musisz poczekac!");
                    return false;
                }
                final Location loc = this.plugin.config.warps.get(args[0].toLowerCase()).getLoc();
                sender.sendMessage("�6Poczekaj 5 sekund...");
                Main.teleportPlayerWithDelay(p, 5, loc, "�6Zostales teleportowany!", null);
            }
        }
        return true;
    }
}
