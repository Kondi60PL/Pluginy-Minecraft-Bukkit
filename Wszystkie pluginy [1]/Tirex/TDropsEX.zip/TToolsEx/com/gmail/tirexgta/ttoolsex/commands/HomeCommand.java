package com.gmail.tirexgta.ttoolsex.commands;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.apache.commons.lang.*;
import com.gmail.tirexgta.ttoolsex.database.*;
import java.util.*;
import org.bukkit.*;

public class HomeCommand implements CommandExecutor
{
    Main plugin;
    
    public HomeCommand(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getCommand("home").setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("�cTej komendy nie mozna uzywac z poziomu konsoli!");
            return true;
        }
        final Player player = (Player)sender;
        final DataUser user = Datasource.getUserData(player);
        if (this.plugin.teleportCancelListener.teleport.contains(player)) {
            player.sendMessage(" �7�l� �cPoczekaj, az sie steleportujesz!");
            return true;
        }
        if (!user.isHome(1)) {
            player.sendMessage(" �7�l� �cNie ustawiles domu!");
            return true;
        }
        if (args.length == 0) {
            this.teleportHome(player, sender, user, 0, args);
        }
        else if (args[0].equalsIgnoreCase("list")) {
            if (!user.isHome(1)) {
                player.sendMessage(" �7�l� �cNie ustawiles zadnego domu!");
                return false;
            }
            final Set<String> list = new HashSet<String>();
            final Iterator<String> homes$1 = user.getHomes().iterator();
            while (homes$1.hasNext()) {
                list.add(homes$1.next());
            }
            sender.sendMessage(" �7�l� �cTwoja lista domow: �6" + StringUtils.join((Collection)list, ", "));
        }
        else {
            this.teleportHome(player, sender, user, 1, args);
        }
        return false;
    }
    
    boolean teleportHome(final Player p, final CommandSender sender, final DataUser user, final int argsLength, final String[] args) {
        if (argsLength == 0) {
            Location loc = null;
            if (user.isHome("home")) {
                loc = user.getHome("home");
            }
            else {
                loc = user.getHome(1);
            }
            if (loc == null) {
                sender.sendMessage(" �7�l� �cNie ustawiles domu!");
                return false;
            }
            if (!sender.hasPermission("tirex.home.teleport")) {
                sender.sendMessage(" �7�l� �6Twoj kompas wskazuje teraz na dom.");
                sender.sendMessage(" �7�l� �6Ranga ViP wymaga do teleportacji do domu!");
                p.setCompassTarget(loc);
                return false;
            }
            if (p.hasPermission("tirex.home.nodelay")) {
                sender.sendMessage("�6Przeteleportowano do domu!");
                p.teleport(loc);
                return true;
            }
            Main.teleportPlayerWithDelay(p, this.plugin.config.teleportDelay, loc, " �7�l� �6Przeteleportowano do domu!", null);
            sender.sendMessage("�6Teleport rozgrzewa sie...");
        }
        else if (argsLength == 1) {
            Location loc = null;
            if (user.isHome(args[0])) {
                loc = user.getHome(args[0]);
            }
            if (loc == null) {
                sender.sendMessage(" �7�l� �cNie ustawiles domu o tej nazwie!");
                sender.sendMessage(" �7�l� �cLista twoich domow pod komenda /home list!");
                return false;
            }
            if (!sender.hasPermission("tirex.home.teleport")) {
                sender.sendMessage(" �7�l� �6Twoj kompas wskazuje teraz na dom.");
                sender.sendMessage(" �7�l� �6Ranga ViP wymaga do teleportacji do domu!");
                p.setCompassTarget(loc);
                return false;
            }
            if (p.hasPermission("tirex.home.nodelay")) {
                sender.sendMessage("�6Przeteleportowano do domu!");
                p.teleport(loc);
                return true;
            }
            Main.teleportPlayerWithDelay(p, this.plugin.config.teleportDelay, loc, " �7�l� �6Przeteleportowano do domu!", null);
            sender.sendMessage("�6Teleport rozgrzewa sie...");
        }
        return true;
    }
}
