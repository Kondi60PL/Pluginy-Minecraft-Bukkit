package com.gmail.tirexgta.ttoolsex;

import org.bukkit.*;

public class WarpManager
{
    private String name;
    private Location loc;
    
    public WarpManager(final String name, final Location loc) {
        super();
        this.name = name;
        this.loc = loc;
    }
    
    public String getName() {
        return this.name;
    }
    
    public Location getLoc() {
        return this.loc;
    }
}
