package com.gmail.tirexgta.ttoolsex.commands;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.gmail.tirexgta.ttoolsex.database.*;

public class DelhomeCommand implements CommandExecutor
{
    Main plugin;
    
    public DelhomeCommand(final Main plugin) {
        super();
        this.plugin = plugin;
        plugin.getCommand("delhome").setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (args.length == 1) {
            final DataUser user = Datasource.getUserData((Player)sender);
            if (!user.isHome(args[0])) {
                sender.sendMessage(" �7�l� �cNie masz takiego domu!");
                return true;
            }
            user.delHome(args[0]);
            sender.sendMessage(" �7�l� �aUsunales dom!");
        }
        else {
            final DataUser user = Datasource.getUserData((Player)sender);
            if (!user.isHome("home")) {
                sender.sendMessage(" �7�l� �cNie masz takiego domu!");
                return true;
            }
            user.delHome("home");
            sender.sendMessage(" �7�l� �aUsunales dom!");
        }
        return false;
    }
}
