package com.gmail.tirexgta.ttoolsex.database;

import org.bukkit.inventory.*;
import com.gmail.tirexgta.ttoolsex.*;
import java.sql.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.apache.commons.lang.*;
import java.util.*;

public class DataUser extends Entry
{
    private boolean cX;
    private boolean cY;
    private boolean cZ;
    private boolean cHomes;
    private boolean cNick;
    private boolean cWorld;
    private boolean cMute;
    private boolean cHomeWorld;
    private boolean cFly;
    private boolean cGod;
    private boolean cMuteTime;
    private boolean cGamemode;
    private boolean cPlecak;
    private boolean cItemShop;
    private boolean cPkt;
    private boolean cLvl;
    private int userID;
    private int x;
    private int y;
    private int z;
    private Set<String> homes;
    private HashMap<String, Location> homeByName;
    private String nick;
    private String world;
    private String mute;
    private String homeWorld;
    private byte fly;
    private byte god;
    private long muteTime;
    private GameMode gamemode;
    private String oldNick;
    private ItemStack[] plecak;
    private ItemStack[] itemshop;
    private int pkt;
    private int lvl;
    
    public DataUser(final Datasource db) {
        super(db);
        this.homes = new HashSet<String>();
        this.homeByName = new HashMap<String, Location>();
        this.pkt = 0;
        this.lvl = 0;
    }
    
    public DataUser(final Datasource db, final ResultSet rs) throws SQLException {
        super(db);
        this.homes = new HashSet<String>();
        this.homeByName = new HashMap<String, Location>();
        this.pkt = 0;
        this.lvl = 0;
        this.userID = rs.getInt("userID");
        this.x = rs.getInt("x");
        this.y = rs.getInt("y");
        this.z = rs.getInt("z");
        this.createHome(rs.getString("home"));
        this.nick = rs.getString("nick");
        this.world = rs.getString("world");
        this.mute = rs.getString("mute");
        this.fly = rs.getByte("fly");
        this.god = rs.getByte("god");
        this.muteTime = rs.getLong("muteTime");
        this.gamemode = GameMode.getByValue((int)rs.getByte("gamemode"));
        this.plecak = Main.deserializeItemStacks(rs.getString("plecak"));
        this.itemshop = Main.deserializeItemStacks(rs.getString("itemshop"));
        this.pkt = rs.getInt("pkt");
        this.lvl = rs.getInt("lvl");
    }
    
    @Override
    protected void setPrimary(final int id) {
        this.userID = id;
    }
    
    @Override
    public int getPrimary() {
        return this.userID;
    }
    
    public int getX() {
        return this.x;
    }
    
    public int getY() {
        return this.y;
    }
    
    public int getZ() {
        return this.z;
    }
    
    public String getNick() {
        return this.nick;
    }
    
    public String getWorld() {
        return this.world;
    }
    
    public String getMute() {
        return this.mute;
    }
    
    public boolean getFly() {
        return this.fly > 0;
    }
    
    public boolean getGod() {
        return this.god > 0;
    }
    
    public long getMuteTime() {
        return this.muteTime;
    }
    
    public GameMode getGamemode() {
        return this.gamemode;
    }
    
    public ItemStack[] getPlecak() {
        return this.plecak;
    }
    
    public ItemStack[] getItemShop() {
        return this.itemshop;
    }
    
    public int getPkt() {
        return this.pkt;
    }
    
    public int getLvl() {
        return this.lvl;
    }
    
    public void setX(final int v) {
        this.x = v;
        this.cX = true;
    }
    
    public void setY(final int v) {
        this.y = v;
        this.cY = true;
    }
    
    public void setZ(final int v) {
        this.z = v;
        this.cZ = true;
    }
    
    public void setNick(final String v) {
        this.nick = v;
        this.cNick = true;
    }
    
    public void setWorld(final String v) {
        this.world = v;
        this.cWorld = true;
    }
    
    public void setMute(final String v) {
        this.mute = v;
        this.cMute = true;
    }
    
    public void setHomeWorld(final String v) {
        this.homeWorld = v;
        this.cHomeWorld = true;
    }
    
    public void setFly(final boolean v) {
        this.fly = (byte)(v ? 1 : 0);
        this.cFly = true;
    }
    
    public void setGod(final boolean v) {
        this.god = (byte)(v ? 1 : 0);
        this.cGod = true;
    }
    
    public void setMuteTime(final long v) {
        this.muteTime = v;
        this.cMuteTime = true;
    }
    
    public void setGamemode(final GameMode v) {
        this.gamemode = v;
        this.cGamemode = true;
    }
    
    public void setPlecak(final ItemStack[] v) {
        this.plecak = v;
        this.cPlecak = true;
    }
    
    public void setItemShop(final ItemStack[] v) {
        this.itemshop = v;
        this.cItemShop = true;
    }
    
    public void setPkt(final int v) {
        this.pkt = v;
        this.cPkt = true;
    }
    
    public void setLvl(final int v) {
        this.lvl = v;
        this.cLvl = true;
    }
    
    public Set<String> getHomes() {
        return this.homes;
    }
    
    public boolean isHome(final int size) {
        return this.homes.size() >= size;
    }
    
    public boolean isHome(final String name) {
        return this.homeByName.containsKey(name.toLowerCase());
    }
    
    public boolean setHome(final String name, final Location loc) {
        boolean returned = false;
        if (returned = this.isHome(name)) {
            this.homes.remove(name.toLowerCase());
            this.homeByName.remove(name.toLowerCase());
            returned = true;
        }
        this.homes.add(name.toLowerCase());
        this.homeByName.put(name.toLowerCase(), loc);
        this.cHomes = true;
        return returned;
    }
    
    public boolean delHome(final String name) {
        if (this.isHome(name)) {
            this.homes.remove(name.toLowerCase());
            this.homeByName.remove(name.toLowerCase());
            return this.cHomes = true;
        }
        return false;
    }
    
    public Location getHome(final String name) {
        if (this.isHome(name)) {
            return this.homeByName.get(name.toLowerCase());
        }
        return null;
    }
    
    public Location getHome(final int i) {
        if (this.isHome(i)) {
            return this.homeByName.get(i);
        }
        return null;
    }
    
    @Override
    public UpdateSet prepareUpdate(final Boolean vals, final Boolean where) {
        String v = "";
        String w = "";
        final ArrayList args = new ArrayList();
        final ArrayList types = new ArrayList();
        if (vals) {
            String comma = "";
            if (this.cX) {
                this.cX = false;
                v = String.valueOf(v) + comma + "x=?";
                args.add(this.x);
                types.add(4);
                comma = ", ";
            }
            if (this.cY) {
                this.cY = false;
                v = String.valueOf(v) + comma + "y=?";
                args.add(this.y);
                types.add(4);
                comma = ", ";
            }
            if (this.cZ) {
                this.cZ = false;
                v = String.valueOf(v) + comma + "z=?";
                args.add(this.z);
                types.add(4);
                comma = ", ";
            }
            if (this.cHomes) {
                this.cHomes = false;
                v = String.valueOf(v) + comma + "home=?";
                args.add(this.setHome());
                types.add(12);
                comma = ", ";
            }
            if (this.cNick) {
                this.cNick = false;
                v = String.valueOf(v) + comma + "nick=?";
                args.add(this.nick);
                types.add(12);
                comma = ", ";
            }
            if (this.cWorld) {
                this.cWorld = false;
                v = String.valueOf(v) + comma + "world=?";
                args.add(this.world);
                types.add(12);
                comma = ", ";
            }
            if (this.cMute) {
                this.cMute = false;
                v = String.valueOf(v) + comma + "mute=?";
                args.add(this.mute);
                types.add(12);
                comma = ", ";
            }
            if (this.cHomeWorld) {
                this.cHomeWorld = false;
                v = String.valueOf(v) + comma + "homeWorld=?";
                args.add(this.homeWorld);
                types.add(12);
                comma = ", ";
            }
            if (this.cFly) {
                this.cFly = false;
                v = String.valueOf(v) + comma + "fly=?";
                args.add(this.fly);
                types.add(-6);
                comma = ", ";
            }
            if (this.cGod) {
                this.cGod = false;
                v = String.valueOf(v) + comma + "god=?";
                args.add(this.god);
                types.add(-6);
                comma = ", ";
            }
            if (this.cMuteTime) {
                this.cMuteTime = false;
                v = String.valueOf(v) + comma + "muteTime=?";
                args.add(this.muteTime);
                types.add(-5);
                comma = ", ";
            }
            if (this.cGamemode) {
                this.cGamemode = false;
                v = String.valueOf(v) + comma + "gamemode=?";
                args.add((byte)this.gamemode.getValue());
                types.add(-6);
            }
            if (this.cPlecak) {
                this.cPlecak = false;
                v = String.valueOf(v) + comma + "plecak=?";
                args.add(Main.serializeItemStacks(this.plecak));
                types.add(12);
                comma = ", ";
            }
            if (this.cItemShop) {
                this.cItemShop = false;
                v = String.valueOf(v) + comma + "itemshop=?";
                args.add(Main.serializeItemStacks(this.itemshop));
                types.add(12);
                comma = ", ";
            }
            if (this.cPkt) {
                this.cPkt = false;
                v = String.valueOf(v) + comma + "pkt=?";
                args.add(this.pkt);
                types.add(4);
                comma = ", ";
            }
            if (this.cLvl) {
                this.cLvl = false;
                v = String.valueOf(v) + comma + "lvl=?";
                args.add(this.lvl);
                types.add(4);
                comma = ", ";
            }
        }
        if (where) {
            w = "userID=?";
            args.add(this);
            types.add(4);
        }
        return new UpdateSet("users", v, w, args, types, this);
    }
    
    public Player getPlayer() {
        return Bukkit.getPlayer(this.getNick());
    }
    
    public OfflinePlayer getOfflinePlayer() {
        return Bukkit.getOfflinePlayer(this.getNick());
    }
    
    @Override
    public void insert() {
        super.insert();
        this.db.users.add(this);
        Datasource.usersByNick.put(this.nick.toLowerCase(), this);
        this.oldNick = this.nick;
    }
    
    @Override
    public void update() {
        super.update();
        if (this.cNick) {
            Datasource.usersByNick.remove(this.oldNick.toLowerCase());
            Datasource.usersByNick.put(this.nick.toLowerCase(), this);
            this.oldNick = this.nick;
        }
    }
    
    @Override
    public void delete() {
        super.delete();
        this.db.users.remove(this);
        Datasource.usersByNick.remove(this.oldNick.toLowerCase());
    }
    
    void createHome(final String s) {
        if (s == null) {
            return;
        }
        if (s.equals("")) {
            return;
        }
        String[] split;
        for (int length = (split = s.split("\\:")).length, i = 0; i < length; ++i) {
            final String homeS = split[i];
            final String[] homeSplit = homeS.split("\\=");
            if (homeSplit.length > 4) {
                final String name = homeSplit[0];
                final World world = Bukkit.getWorld(homeSplit[1]);
                final int x = homeSplit[2].equals("") ? 0 : Integer.parseInt(homeSplit[2]);
                final int y = homeSplit[3].equals("") ? 0 : Integer.parseInt(homeSplit[3]);
                final int z = homeSplit[4].equals("") ? 0 : Integer.parseInt(homeSplit[4]);
                this.homes.add(name.toLowerCase());
                this.homeByName.put(name.toLowerCase(), new Location(world, x + 0.5, (double)y, z + 0.5));
            }
        }
    }
    
    String setHome() {
        final Set<String> list = new HashSet<String>();
        final Iterator<String> it$1 = this.homes.iterator();
        while (it$1.hasNext()) {
            final List<String> listHome = new ArrayList<String>();
            final String name = it$1.next();
            final Location home = this.homeByName.get(name.toLowerCase());
            listHome.add(name);
            listHome.add(String.valueOf(home.getWorld().getName()));
            listHome.add(Integer.toString(home.getBlockX()));
            listHome.add(Integer.toString(home.getBlockY()));
            listHome.add(Integer.toString(home.getBlockZ()));
            list.add(StringUtils.join((Collection)listHome, "="));
        }
        return StringUtils.join((Collection)list, ":");
    }
}
