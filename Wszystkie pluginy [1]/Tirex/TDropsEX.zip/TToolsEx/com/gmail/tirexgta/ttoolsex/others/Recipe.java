package com.gmail.tirexgta.ttoolsex.others;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.enchantments.*;
import org.bukkit.material.*;

public class Recipe
{
    Main plugin;
    
    public Recipe(final Main plugin) {
        super();
        this.plugin = plugin;
        registerSuperChest();
        registerSuperStoniarka();
        registerCiastkoVip();
        registerPowerrade();
        registerPrzywolywaczKrow();
    }
    
    public static void registerSuperChest() {
        final ItemStack superchest = itemSuperChest();
        final ShapedRecipe recipe = new ShapedRecipe(new ItemStack(superchest)).shape(new String[] { "OOO", "DCD", "OOO" }).setIngredient('O', Material.OBSIDIAN).setIngredient('D', Material.DIAMOND).setIngredient('C', Material.CHEST);
        Bukkit.getServer().addRecipe((org.bukkit.inventory.Recipe)recipe);
    }
    
    public static void registerPokeBall() {
        final ItemStack pokeball = itemPokeBall();
        final ShapedRecipe recipe = new ShapedRecipe(new ItemStack(pokeball)).shape(new String[] { "OGO", "RSR", "OFO" }).setIngredient('O', Material.OBSIDIAN).setIngredient('G', Material.GLASS).setIngredient('R', Material.REDSTONE_BLOCK).setIngredient('S', Material.getMaterial(175)).setIngredient('F', Material.FLOWER_POT_ITEM);
        Bukkit.getServer().addRecipe((org.bukkit.inventory.Recipe)recipe);
    }
    
    public static void registerSuperStoniarka() {
        final ItemStack superchest = itemSuperStoniarka();
        final ShapedRecipe recipe = new ShapedRecipe(new ItemStack(superchest)).shape(new String[] { "RPR", "DGD", "RPR" }).setIngredient('R', Material.REDSTONE_BLOCK).setIngredient('D', Material.DIAMOND).setIngredient('G', Material.GLASS).setIngredient('P', Material.FLOWER_POT_ITEM);
        Bukkit.getServer().addRecipe((org.bukkit.inventory.Recipe)recipe);
    }
    
    public static void registerCiastkoVip() {
        final ItemStack superchest = itemCiastkoVip();
        final ShapedRecipe recipe = new ShapedRecipe(new ItemStack(superchest)).shape(new String[] { "CAC", "WJW", "CAC" }).setIngredient('C', Material.COOKIE).setIngredient('A', Material.MELON).setIngredient('W', Material.WHEAT).setIngredient('J', Material.GOLDEN_APPLE);
        Bukkit.getServer().addRecipe((org.bukkit.inventory.Recipe)recipe);
    }
    
    public static void registerPowerrade() {
        final ItemStack superchest = itemPowerRade();
        final ShapedRecipe recipe = new ShapedRecipe(new ItemStack(superchest)).shape(new String[] { "SDS", "JPJ", "WDW" }).setIngredient('S', Material.SUGAR).setIngredient('D', Material.DIAMOND).setIngredient('P', Material.POTION).setIngredient('J', Material.GOLDEN_APPLE).setIngredient('W', Material.WHEAT);
        Bukkit.getServer().addRecipe((org.bukkit.inventory.Recipe)recipe);
    }
    
    public static void registerPrzywolywaczKrow() {
        final ItemStack superchest = itemPrzywolywaczKrow();
        final ShapedRecipe recipe = new ShapedRecipe(new ItemStack(superchest)).shape(new String[] { "EDE", "EGE", "EPE" }).setIngredient('E', Material.EMERALD).setIngredient('G', Material.GOLD_BLOCK).setIngredient('D', Material.DIAMOND_BLOCK).setIngredient('P', Material.STICK);
        Bukkit.getServer().addRecipe((org.bukkit.inventory.Recipe)recipe);
    }
    
    public static ItemStack itemSuperChest() {
        final ItemStack superchest = new ItemStack(Material.TRAPPED_CHEST);
        final ItemMeta meta = superchest.getItemMeta();
        meta.setDisplayName("�6�lSuper�f�lChest!");
        final List<String> opis = new ArrayList<String>();
        opis.add("�bMoc Tirexa X");
        opis.add(" �f�l� �cWcisnij Prawy Przycisk Myszy,");
        opis.add("      �caby otworzyc Plecak!");
        meta.setLore((List)opis);
        superchest.setItemMeta(meta);
        return superchest;
    }
    
    public static ItemStack itemPokeBall() {
        final ItemStack pokeball = new ItemStack(Material.getMaterial(175));
        final ItemMeta meta = pokeball.getItemMeta();
        meta.setDisplayName("�6Pok\u00e8ball!");
        final List<String> opis = new ArrayList<String>();
        opis.add("�bMoc Tirexa X");
        opis.add(" �f�l� �cNacisnij Prawym Przyciskiem Myszy");
        opis.add("      �cna Potwora, ktorego chcesz zlapac!");
        meta.setLore((List)opis);
        pokeball.setItemMeta(meta);
        return pokeball;
    }
    
    public static ItemStack itemSuperStoniarka() {
        final ItemStack stoniarka = new ItemStack(Material.ENDER_STONE);
        final ItemMeta meta = stoniarka.getItemMeta();
        meta.setDisplayName("�b�lStone�6�lArka!");
        final List<String> opis = new ArrayList<String>();
        opis.add("�bMoc Tirexa X");
        opis.add(" �f�l� �cPoloz ten blok na ziemi, aby zaczal");
        opis.add("      �csie generowac stone!");
        meta.setLore((List)opis);
        stoniarka.setItemMeta(meta);
        return stoniarka;
    }
    
    public static ItemStack itemVip() {
        final ItemStack stoniarka = new ItemStack(Material.EMERALD);
        final ItemMeta meta = stoniarka.getItemMeta();
        meta.addEnchant(Enchantment.ARROW_FIRE, 5, true);
        meta.setDisplayName(" �b�l\u2605 �a�lViP | �6�l30 dni");
        final List<String> opis = new ArrayList<String>();
        opis.add(" �c�l� �fViP na 30 dni!");
        opis.add(" �c�l� �fUzywajac tego przedmiotu,");
        opis.add("     �fotrzymasz ViPa na 30 dni!");
        meta.setLore((List)opis);
        stoniarka.setItemMeta(meta);
        return stoniarka;
    }
    
    public static ItemStack itemCiastkoVip() {
        final ItemStack stoniarka = new ItemStack(Material.COOKIE);
        final ItemMeta meta = stoniarka.getItemMeta();
        meta.addEnchant(Enchantment.ARROW_INFINITE, 1, true);
        meta.setDisplayName(" �7�l\u2605 �6Ciastko ViPa");
        final List<String> opis = new ArrayList<String>();
        opis.add(" �c�l� �fNieskonczone ciastko!");
        meta.setLore((List)opis);
        stoniarka.setItemMeta(meta);
        return stoniarka;
    }
    
    public static ItemStack itemPowerRade() {
        final ItemStack stoniarka = new ItemStack(Material.POTION);
        final MaterialData data = stoniarka.getData();
        data.setData((byte)1);
        stoniarka.setData(data);
        final ItemMeta meta = stoniarka.getItemMeta();
        meta.setDisplayName(" �7�l\u2605 �6Powerrade");
        final List<String> opis = new ArrayList<String>();
        opis.add(" �c�l� �fWypij i jedziesz dalej!");
        meta.setLore((List)opis);
        stoniarka.setItemMeta(meta);
        return stoniarka;
    }
    
    public static ItemStack itemPrzywolywaczKrow() {
        final ItemStack stoniarka = new ItemStack(Material.TRIPWIRE_HOOK);
        final ItemMeta meta = stoniarka.getItemMeta();
        meta.setDisplayName(" �7�l\u2605 �6Przywolywacz Krow!");
        final List<String> opis = new ArrayList<String>();
        opis.add(" �c�l� �fPrzywoluje 2 krowy!");
        meta.setLore((List)opis);
        stoniarka.setItemMeta(meta);
        return stoniarka;
    }
}
