package com.gmail.tirexgta.ttoolsex.commands;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;

public class HeadCommand implements CommandExecutor
{
    Main plugin;
    
    public HeadCommand(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getCommand("head").setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("�cTej komendy nie mozna uzywac z poziomu konsoli!");
                return true;
            }
            final Player player = (Player)sender;
            final ItemStack skull = new ItemStack(397, 1, (short)3);
            final SkullMeta meta = (SkullMeta)skull.getItemMeta();
            meta.setDisplayName(player.getName());
            meta.setOwner(player.getName());
            skull.setItemMeta((ItemMeta)meta);
            player.getInventory().addItem(new ItemStack[] { skull });
            player.sendMessage("�6Glowa gracza �c" + player.getName() + " �6zostala dodana do twojego ekwipunku!");
        }
        else if (args.length == 1) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("�cTej komendy nie mozna uzywac z poziomu konsoli!");
                return true;
            }
            final Player player = (Player)sender;
            final String otherName = args[0];
            final ItemStack skull2 = new ItemStack(397, 1, (short)3);
            final SkullMeta meta2 = (SkullMeta)skull2.getItemMeta();
            meta2.setDisplayName(otherName);
            meta2.setOwner(otherName);
            skull2.setItemMeta((ItemMeta)meta2);
            player.getInventory().addItem(new ItemStack[] { skull2 });
            player.sendMessage("�6Glowa gracza �c" + otherName + " �6zostala dodana do twojego ekwipunku!");
        }
        else {
            sender.sendMessage("�cPoprawne uzycie: �6/head [gracz]");
        }
        return false;
    }
}
