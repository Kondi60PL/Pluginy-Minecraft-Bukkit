package com.gmail.tirexgta.ttoolsex.listeners;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.plugin.*;
import org.bukkit.event.inventory.*;
import com.gmail.tirexgta.ttoolsex.others.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.potion.*;

public class CiastkoVipListener implements Listener
{
    Main plugin;
    
    public CiastkoVipListener(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
    }
    
    @EventHandler
    public void onCraft(final CraftItemEvent e) {
        final Inventory inv = (Inventory)e.getInventory();
        if (inv == null) {
            return;
        }
        final ItemStack result = e.getRecipe().getResult();
        if (result != null && result.getItemMeta() != null && result.getItemMeta().equals(Recipe.itemCiastkoVip().getItemMeta())) {
            final Player p = (Player)e.getWhoClicked();
            if (!p.hasPermission("tirex.vip")) {
                e.setCancelled(true);
                e.setResult(Event.Result.DENY);
                e.setCurrentItem(new ItemStack(Material.AIR));
                p.sendMessage(" �7�l� �cMusisz miec ViPa, zeby craftowac ten przedmiot!");
            }
        }
    }
    
    @EventHandler
    public void onConsume(final PlayerItemConsumeEvent e) {
        final ItemStack item = e.getItem();
        if (item != null && item.getItemMeta() != null && item.getItemMeta().equals(Recipe.itemCiastkoVip().getItemMeta())) {
            final Player p = e.getPlayer();
            p.addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, 300, 1));
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 280, 1));
            p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 75, 1));
            p.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 180, 1));
            p.setFoodLevel(p.getFoodLevel() + 7);
        }
    }
}
