package com.gmail.tirexgta.ttoolsex.commands;

import com.gmail.tirexgta.ttoolsex.*;
import java.util.*;
import org.bukkit.command.*;
import org.bukkit.*;

public class HelpopCommand implements CommandExecutor
{
    Main plugin;
    HashMap<String, Long> cooldown;
    
    public HelpopCommand(final Main plugin) {
        super();
        this.cooldown = new HashMap<String, Long>();
        this.plugin = plugin;
        this.plugin.getCommand("helpop").setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (args.length < 1) {
            sender.sendMessage("�cPoprawne uzycie: �6/helpop <wiadomosc>");
            return true;
        }
        if (this.cooldown.containsKey(sender.getName().toLowerCase())) {
            long time = this.cooldown.get(sender.getName().toLowerCase());
            if (time > System.currentTimeMillis()) {
                time = (System.currentTimeMillis() - time) / 60000L;
                sender.sendMessage("�cNa HelpOp mozna pisac co " + time + " minut!");
                return true;
            }
        }
        final StringBuilder sb = new StringBuilder();
        sb.append("�c�l[HelpOp] �f").append(sender.getName()).append(" ").append("->").append(" ");
        for (int i = 0; i < args.length; ++i) {
            sb.append(args[i]).append(" ");
        }
        this.cooldown.put(sender.getName().toLowerCase(), System.currentTimeMillis() + 300000L);
        Bukkit.broadcast(Main.fixMsg(sb.toString()), "tirex.helpop.message");
        sender.sendMessage("�c�l[HelpOp] �fCONSOLE -> Wiadomosc zostala wyslana, dziekujemy!");
        return false;
    }
}
