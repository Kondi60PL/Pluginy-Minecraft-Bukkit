package com.gmail.tirexgta.ttoolsex.listeners;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.plugin.*;
import org.bukkit.event.player.*;
import com.gmail.tirexgta.ttoolsex.database.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.*;
import org.bukkit.entity.*;

public class ItemShopListener implements Listener
{
    Main plugin;
    
    public ItemShopListener(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerJoin(final PlayerJoinEvent e) {
        final Player p = e.getPlayer();
        final DataUser user = Datasource.getUserData(p);
        if (user == null) {
            return;
        }
        final ItemStack[] is = user.getItemShop();
        if (is == null) {
            return;
        }
        ItemStack[] array;
        for (int length = (array = is).length, i = 0; i < length; ++i) {
            final ItemStack item = array[i];
            if (item != null && !item.getType().equals((Object)Material.AIR)) {
                p.sendMessage(" �7�l� �aW twoim ItemShopie znajduja sie nowe przedmioty.");
                p.sendMessage(" �7�l� �aUzyj komendy �f/is �azeby je odebrac!");
                return;
            }
        }
    }
    
    @EventHandler
    public void onInventoryClose(final InventoryCloseEvent e) {
        final Inventory inventory = e.getInventory();
        if (inventory.getTitle().equals("ItemShop")) {
            final ItemStack[] items = inventory.getContents();
            if (items == null) {
                return;
            }
            final Player p = (Player)e.getPlayer();
            final DataUser user = Datasource.getUserData(p);
            if (items.equals(user.getItemShop())) {
                return;
            }
            user.setItemShop(items);
            p.playSound(p.getLocation(), Sound.CHEST_CLOSE, 1.0f, 1.0f);
        }
    }
    
    @EventHandler
    public void onInventoryClick(final InventoryClickEvent e) {
        final Inventory inventory = e.getInventory();
        final ClickType click = e.getClick();
        if (inventory.getTitle().equals("ItemShop")) {
            if (click.equals((Object)ClickType.SHIFT_LEFT) || click.equals((Object)ClickType.SHIFT_RIGHT)) {
                if (e.getSlotType().equals((Object)InventoryType.SlotType.CONTAINER) && e.getRawSlot() > 8) {
                    final ItemStack item = e.getCurrentItem();
                    if (item == null) {
                        return;
                    }
                    if (!item.getType().equals((Object)Material.AIR)) {
                        e.setResult(Event.Result.DENY);
                        e.setCancelled(true);
                        final HumanEntity human = e.getWhoClicked();
                        e.setCursor((ItemStack)null);
                        human.openInventory(inventory);
                        ((Player)human).sendMessage(" �7�l� �cNie mozesz podnosic przedmiotow z tej czesci ItemShopu!");
                    }
                }
            }
            else if (click.equals((Object)ClickType.LEFT) || click.equals((Object)ClickType.RIGHT)) {
                if (e.getSlotType().equals((Object)InventoryType.SlotType.CONTAINER)) {
                    if (e.getRawSlot() >= 27) {
                        final ItemStack item = e.getCurrentItem();
                        if (item == null) {
                            return;
                        }
                        if (!item.getType().equals((Object)Material.AIR)) {
                            e.setResult(Event.Result.DENY);
                            e.setCancelled(true);
                            final HumanEntity human = e.getWhoClicked();
                            e.setCursor((ItemStack)null);
                            human.openInventory(inventory);
                            ((Player)human).sendMessage(" �7�l� �cNie mozesz podnosic przedmiotow z tej czesci ItemShopu!");
                        }
                    }
                }
                else {
                    final ItemStack item = e.getCurrentItem();
                    if (item == null) {
                        return;
                    }
                    if (!item.getType().equals((Object)Material.AIR)) {
                        e.setResult(Event.Result.DENY);
                        e.setCancelled(true);
                        final HumanEntity human = e.getWhoClicked();
                        e.setCursor((ItemStack)null);
                        human.openInventory(inventory);
                        ((Player)human).sendMessage(" �7�l� �cNie mozesz podnosic przedmiotow z tej czesci ItemShopu!");
                    }
                }
            }
            else if (click.equals((Object)ClickType.DOUBLE_CLICK)) {
                if (e.getSlotType().equals((Object)InventoryType.SlotType.CONTAINER)) {
                    final ItemStack item = e.getCurrentItem();
                    if (item == null) {
                        return;
                    }
                    if (!item.getType().equals((Object)Material.AIR)) {
                        final ItemStack cursor = e.getCursor();
                        if (cursor == null) {
                            return;
                        }
                        if (cursor.getType().equals((Object)Material.AIR)) {
                            e.setResult(Event.Result.DENY);
                            e.setCancelled(true);
                            final HumanEntity human2 = e.getWhoClicked();
                            human2.openInventory(inventory);
                            ((Player)human2).sendMessage(" �7�l� �cNie mozesz podnosic przedmiotow z tej czesci ItemShopu!");
                        }
                    }
                }
            }
            else {
                if (!click.equals((Object)ClickType.WINDOW_BORDER_LEFT) && !click.equals((Object)ClickType.WINDOW_BORDER_RIGHT)) {
                    e.setResult(Event.Result.DENY);
                    e.setCancelled(true);
                    final HumanEntity human3 = e.getWhoClicked();
                    human3.getInventory().addItem(new ItemStack[] { e.getCursor() });
                    e.setCursor((ItemStack)null);
                    human3.openInventory(inventory);
                    ((Player)human3).sendMessage(" �7�l� �cNie mozesz podnosic przedmiotow z tej czesci ItemShopu!");
                    return;
                }
                e.setCursor((ItemStack)null);
                e.setCurrentItem((ItemStack)null);
            }
        }
    }
}
