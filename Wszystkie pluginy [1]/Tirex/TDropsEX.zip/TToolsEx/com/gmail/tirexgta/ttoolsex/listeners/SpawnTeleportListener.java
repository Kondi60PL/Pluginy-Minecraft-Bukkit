package com.gmail.tirexgta.ttoolsex.listeners;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.plugin.*;
import org.bukkit.event.player.*;
import org.bukkit.event.*;

public class SpawnTeleportListener implements Listener
{
    Main plugin;
    
    public SpawnTeleportListener(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(final PlayerRespawnEvent e) {
        if (this.plugin.config.spawn != null) {
            e.getPlayer().teleport(this.plugin.config.spawn);
            this.plugin.config.spawn.getWorld().refreshChunk(this.plugin.config.spawn.getBlockX(), this.plugin.config.spawn.getBlockZ());
        }
    }
}
