package com.gmail.tirexgta.ttoolsex.commands;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;

public class EnderchestCommand implements CommandExecutor
{
    Main plugin;
    
    public EnderchestCommand(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getCommand("enderchest").setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (args.length == 1) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Stop!");
                return true;
            }
            final Player other = Bukkit.getPlayerExact(args[0]);
            if (other == null) {
                sender.sendMessage(" �7�l� �cTego gracza nie ma online!");
                return true;
            }
            final Player p = (Player)sender;
            p.openInventory(other.getEnderChest());
        }
        else {
            sender.sendMessage(" �7�l� �c/invsee <gracz>");
        }
        return false;
    }
}
