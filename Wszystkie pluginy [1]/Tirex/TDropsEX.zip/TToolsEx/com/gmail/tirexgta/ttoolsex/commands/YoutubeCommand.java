package com.gmail.tirexgta.ttoolsex.commands;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.command.*;

public class YoutubeCommand implements CommandExecutor
{
    Main plugin;
    
    public YoutubeCommand(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getCommand("youtube").setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        sender.sendMessage(" �4�l� �6Uprawnienia dla Youtubera:");
        sender.sendMessage("   �4�l� �6To samo co ViP");
        sender.sendMessage(" �4�l� �6Wymagania na Youtubera:");
        sender.sendMessage("   �4�l� �6Duza liczba wyswietlen");
        sender.sendMessage("   �4�l� �6Potwierdzenie swojej tozsamosci");
        sender.sendMessage(" �4�l� �6Masz ochote zosta\u0107 youtuberem, napisz do administracji!");
        return false;
    }
}
