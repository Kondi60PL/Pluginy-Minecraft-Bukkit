package com.gmail.tirexgta.ttoolsex.commands;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.command.*;

public class VipCommand implements CommandExecutor
{
    Main plugin;
    
    public VipCommand(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getCommand("vip").setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        sender.sendMessage(" �4�l� �6Uprawnienia dla Vipa:");
        sender.sendMessage("   �4�l� �6Rezerwacje Slota");
        sender.sendMessage("   �4�l� �6Wiekszy plecak");
        sender.sendMessage("   �4�l� �6Wiekszy Drop");
        sender.sendMessage("   �4�l� �6Prefix na czacie");
        sender.sendMessage("   �4�l� �6/spawn co chwile");
        sender.sendMessage("   �4�l� �6/hat");
        return false;
    }
}
