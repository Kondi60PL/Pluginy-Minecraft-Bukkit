package com.gmail.tirexgta.ttoolsex.listeners;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.plugin.*;
import com.gmail.tirexgta.ttoolsex.others.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.entity.*;
import com.gmail.tirexgta.ttoolsex.database.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import org.bukkit.*;
import org.bukkit.inventory.*;

public class BackpackListener implements Listener
{
    final Main plugin;
    
    public BackpackListener(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
    }
    
    @EventHandler
    public static void onInventoryClick(final InventoryClickEvent e) {
        final Inventory inventory = e.getInventory();
        if (inventory.getTitle().equals("Plecak")) {
            final ItemStack plecak = Recipe.itemSuperChest();
            final ItemStack przedmiot = e.getCurrentItem();
            if (przedmiot == null) {
                return;
            }
            final ItemMeta przedmiotMeta = przedmiot.getItemMeta();
            if (przedmiotMeta == null) {
                return;
            }
            if (przedmiotMeta.equals(plecak.getItemMeta())) {
                e.setCancelled(true);
                e.getWhoClicked().openInventory(inventory);
            }
        }
    }
    
    @EventHandler
    public void onInventoryClose(final InventoryCloseEvent e) {
        final Inventory inventory = e.getInventory();
        final HumanEntity he = e.getPlayer();
        final Player p = (Player)he;
        if (inventory.getName().equals("Plecak")) {
            final DataUser user = Datasource.getUserData(p);
            user.setPlecak(inventory.getContents());
            user.update();
            p.playSound(p.getLocation(), Sound.CHEST_CLOSE, 1.0f, 1.0f);
        }
    }
    
    @EventHandler
    public void onPlayerInteract(final PlayerInteractEvent e) {
        if (e.getAction() == Action.RIGHT_CLICK_AIR) {
            final ItemStack superchest = Recipe.itemSuperChest();
            final ItemStack item = e.getItem();
            if (item == null) {
                return;
            }
            final ItemMeta meta = item.getItemMeta();
            if (meta == null) {
                return;
            }
            if (!meta.equals(superchest.getItemMeta())) {
                return;
            }
            this.openPlecak(e.getPlayer());
        }
    }
    
    @EventHandler
    public void onBlockPlace(final BlockPlaceEvent e) {
        final ItemStack superchest = Recipe.itemSuperChest();
        final ItemStack item = e.getItemInHand();
        if (item == null) {
            return;
        }
        final ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        if (!meta.equals(superchest.getItemMeta())) {
            return;
        }
        this.openPlecak(e.getPlayer());
        e.setCancelled(true);
    }
    
    public void openPlecak(final Player p) {
        Inventory inv;
        if (p.hasPermission("tirex.vip")) {
            inv = Bukkit.createInventory((InventoryHolder)null, 36, "Plecak");
        }
        else {
            inv = Bukkit.createInventory((InventoryHolder)null, 27, "Plecak");
        }
        inv.clear();
        final DataUser user = Datasource.getUserData(p);
        if (user == null) {
            return;
        }
        final ItemStack[] items = user.getPlecak();
        if (items == null) {
            p.openInventory(inv);
            return;
        }
        ItemStack[] array;
        for (int length = (array = items).length, i = 0; i < length; ++i) {
            final ItemStack item = array[i];
            final Inventory invPlayer = (Inventory)p.getInventory();
            if (item != null) {
                if (inv.firstEmpty() >= 0) {
                    inv.addItem(new ItemStack[] { item });
                }
                else if (invPlayer.firstEmpty() >= 0) {
                    invPlayer.addItem(new ItemStack[] { item });
                }
                else {
                    p.getWorld().dropItem(p.getLocation(), item);
                }
            }
        }
        p.openInventory(inv);
        p.playSound(p.getLocation(), Sound.CHEST_OPEN, 1.0f, 1.0f);
    }
}
