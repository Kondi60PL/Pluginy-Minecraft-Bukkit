package com.gmail.tirexgta.ttoolsex.commands;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.gmail.tirexgta.ttoolsex.database.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.inventory.*;

public class ItemShopCommand implements CommandExecutor
{
    Main plugin;
    
    public ItemShopCommand(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getCommand("itemshop").setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("KONSOLA STOP !");
                return true;
            }
            this.openItemShop((Player)sender, null, sender.getName());
        }
        else if (args.length > 0) {
            if (args[0].equalsIgnoreCase("give")) {
                if (!sender.hasPermission("tirex.itemshop.give")) {
                    this.openItemShop((Player)sender, null, sender.getName());
                    return true;
                }
                if (args.length != 3) {
                    sender.sendMessage("/is give <pack> <player>");
                    return true;
                }
                final String packName = args[1];
                final String playerName = args[2];
                final DataUser user = Datasource.getUserByNick(playerName);
                if (user == null) {
                    sender.sendMessage("Nie ma takiego gracza!");
                    return true;
                }
                if (!this.plugin.config.packs.containsKey(packName.toLowerCase())) {
                    sender.sendMessage("Nie ma takiego zestawu!");
                    return true;
                }
                final ItemStack[] pack = this.plugin.config.packs.get(packName.toLowerCase());
                final List<ItemStack> packIS = new ArrayList<ItemStack>();
                ItemStack[] array;
                for (int length = (array = pack).length, i = 0; i < length; ++i) {
                    final ItemStack item = array[i];
                    if (!packIS.contains(item)) {
                        packIS.add(item);
                    }
                }
                ItemStack[] itemShop;
                for (int length2 = (itemShop = user.getItemShop()).length, j = 0; j < length2; ++j) {
                    final ItemStack item = itemShop[j];
                    if (!packIS.contains(item)) {
                        packIS.add(item);
                    }
                }
                final ItemStack[] table = new ItemStack[0];
                user.setItemShop(packIS.toArray(table));
                sender.sendMessage("Zestaw " + packName + " zostal dodany do ItemShopu gracza " + user.getNick());
                final Player other = Bukkit.getPlayerExact(playerName);
                if (other != null) {
                    other.sendMessage(" �7�l� �aW twoim ItemShopie znajduja sie nowe przedmioty.");
                    other.sendMessage(" �7�l� �aUzyj komendy �f/is �azeby je odebrac!");
                }
            }
            else if (args[0].equalsIgnoreCase("add")) {
                if (!(sender instanceof Player)) {
                    sender.sendMessage("KONSOLA STOP !");
                    return true;
                }
                if (!sender.hasPermission("tirex.itemshop.add")) {
                    this.openItemShop((Player)sender, null, sender.getName());
                    return true;
                }
                if (args.length != 2) {
                    sender.sendMessage("/is add <pack>");
                    return true;
                }
                final String packName = args[1];
                if (this.plugin.config.packs.containsKey(packName.toLowerCase())) {
                    sender.sendMessage("Jest juz taki zestaw!");
                    return true;
                }
                final Player p = (Player)sender;
                final ItemStack itemHand = p.getItemInHand();
                if (itemHand == null) {
                    sender.sendMessage("Nie trzymasz zadnego przedmiotu w rece!");
                    return true;
                }
                if (itemHand.getType().equals((Object)Material.AIR)) {
                    sender.sendMessage("Nie trzymasz zadnego przedmiotu w rece!");
                    return true;
                }
                final ItemStack[] packItem = { p.getItemInHand() };
                this.plugin.config.packsName.add(packName);
                this.plugin.config.packs.put(packName.toLowerCase(), packItem);
                this.plugin.config.save();
                sender.sendMessage("Dodano zestaw o nazwie " + packName);
            }
            else {
                this.openItemShop((Player)sender, null, sender.getName());
            }
        }
        return false;
    }
    
    public void openItemShop(final Player p, final String s, final String sender) {
        final Inventory inv = Bukkit.createInventory((InventoryHolder)null, 27, "ItemShop");
        DataUser user = null;
        if (p != null) {
            user = Datasource.getUserData(p);
        }
        else if (s != null) {
            user = Datasource.getUserByNick(s);
        }
        if (user == null) {
            return;
        }
        final ItemStack[] items = user.getItemShop();
        if (items == null) {
            p.openInventory(inv);
            return;
        }
        ItemStack[] array;
        for (int length = (array = items).length, i = 0; i < length; ++i) {
            final ItemStack item = array[i];
            final Inventory invPlayer = (Inventory)p.getInventory();
            if (item != null) {
                if (inv.firstEmpty() >= 0) {
                    inv.addItem(new ItemStack[] { item });
                }
                else if (invPlayer.firstEmpty() >= 0) {
                    invPlayer.addItem(new ItemStack[] { item });
                }
                else {
                    p.getWorld().dropItem(p.getLocation(), item);
                }
            }
        }
        if (p != null) {
            p.openInventory(inv);
            p.playSound(p.getLocation(), Sound.CHEST_OPEN, 1.0f, 1.0f);
        }
        else if (sender != null) {
            final Player other = Bukkit.getPlayerExact(sender);
            if (other != null) {
                other.openInventory(inv);
                other.playSound(other.getLocation(), Sound.CHEST_OPEN, 1.0f, 1.0f);
            }
        }
    }
}
