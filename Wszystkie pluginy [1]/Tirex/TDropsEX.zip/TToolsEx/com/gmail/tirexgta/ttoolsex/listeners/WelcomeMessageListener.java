package com.gmail.tirexgta.ttoolsex.listeners;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.plugin.*;
import org.bukkit.event.player.*;
import org.bukkit.*;
import org.bukkit.enchantments.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.meta.*;
import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.event.*;

public class WelcomeMessageListener implements Listener
{
    Main plugin;
    
    public WelcomeMessageListener(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerJoin(final PlayerJoinEvent event) {
        final Player player = event.getPlayer();
        if (!player.hasPlayedBefore()) {
            player.teleport(player.getWorld().getSpawnLocation());
            Bukkit.broadcastMessage("�7Witamy �3" + player.getName() + " �7pierwszy raz na serwerze!");
            final ItemStack kurczak = new ItemStack(Material.COOKED_CHICKEN, 64);
            final ItemStack kilof = new ItemStack(Material.STONE_PICKAXE, 1);
            final ItemStack enderchest = new ItemStack(Material.ENDER_CHEST, 1);
            final ItemStack pochodnie = new ItemStack(Material.TORCH, 16);
            final ItemMeta metaKurczak = kurczak.getItemMeta();
            final ItemMeta metaKilof = kilof.getItemMeta();
            final ItemMeta metaEnderchest = enderchest.getItemMeta();
            final ItemMeta metaPochodnie = pochodnie.getItemMeta();
            metaKurczak.setDisplayName(" �b�l\u2605 �6�lSmiercionosny Kurczak!");
            metaKilof.setDisplayName(" �b�l\u2605 �6�lSmiercionosny Kilof!");
            metaEnderchest.setDisplayName(" �b�l\u2605 �6�lSmiercionosny Enderchest!");
            metaPochodnie.setDisplayName(" �b�l\u2605 �6�lSmiercionosne Pochodnie!");
            metaKurczak.addEnchant(Enchantment.KNOCKBACK, 1, true);
            metaKilof.addEnchant(Enchantment.KNOCKBACK, 1, true);
            metaEnderchest.addEnchant(Enchantment.KNOCKBACK, 1, true);
            metaPochodnie.addEnchant(Enchantment.KNOCKBACK, 1, true);
            kurczak.setItemMeta(metaKurczak);
            kilof.setItemMeta(metaKilof);
            enderchest.setItemMeta(metaEnderchest);
            pochodnie.setItemMeta(metaPochodnie);
            final Inventory inv = (Inventory)player.getInventory();
            inv.addItem(new ItemStack[] { kilof });
            inv.addItem(new ItemStack[] { kurczak });
            inv.addItem(new ItemStack[] { kurczak });
            inv.addItem(new ItemStack[] { enderchest });
            inv.addItem(new ItemStack[] { pochodnie });
        }
        if (player.hasPermission("tirex.welcomemessage")) {
            for (String line : this.plugin.config.welcomeMessage) {
                line = line.replace("&", "�");
                line = line.replace("{odwiedzilo}", String.valueOf(this.plugin.data.users.size()));
                line = line.replace("{playername}", player.getName());
                line = line.replace("{online}", Integer.toString(this.plugin.slot()));
                line = line.replace("{slot}", Integer.toString(Bukkit.getMaxPlayers()));
                player.sendMessage(line);
            }
        }
    }
}
