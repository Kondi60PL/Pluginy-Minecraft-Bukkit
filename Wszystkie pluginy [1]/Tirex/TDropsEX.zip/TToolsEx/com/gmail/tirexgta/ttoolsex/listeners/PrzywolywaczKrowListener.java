package com.gmail.tirexgta.ttoolsex.listeners;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.plugin.*;
import org.bukkit.event.player.*;
import org.bukkit.event.block.*;
import com.gmail.tirexgta.ttoolsex.others.*;
import org.bukkit.inventory.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.block.*;
import org.bukkit.event.*;

public class PrzywolywaczKrowListener implements Listener
{
    Main plugin;
    
    public PrzywolywaczKrowListener(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
    }
    
    @EventHandler
    public void interact(final PlayerInteractEvent e) {
        if (!e.getAction().equals((Object)Action.RIGHT_CLICK_AIR) && !e.getAction().equals((Object)Action.RIGHT_CLICK_BLOCK)) {
            return;
        }
        final ItemStack item = e.getItem();
        if (item != null && item.getItemMeta() != null && item.getItemMeta().equals(Recipe.itemPrzywolywaczKrow().getItemMeta())) {
            if (e.getClickedBlock() == null) {
                return;
            }
            e.setUseInteractedBlock(Event.Result.DENY);
            e.setUseItemInHand(Event.Result.DENY);
            final Player p = e.getPlayer();
            p.getInventory().removeItem(new ItemStack[] { Recipe.itemPrzywolywaczKrow() });
            final BlockFace face = e.getBlockFace();
            final Location loc = e.getClickedBlock().getLocation();
            loc.add(new Location(loc.getWorld(), (double)face.getModX(), (double)face.getModY(), (double)face.getModZ()));
            ((Cow)loc.getWorld().spawnEntity(loc, EntityType.COW)).setCustomName("�c�lMAMA");
            ((Cow)loc.getWorld().spawnEntity(loc, EntityType.COW)).setCustomName("�9�lTATA");
        }
    }
}
