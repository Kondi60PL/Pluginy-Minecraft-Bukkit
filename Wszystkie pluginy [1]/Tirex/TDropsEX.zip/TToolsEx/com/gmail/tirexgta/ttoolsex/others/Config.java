package com.gmail.tirexgta.ttoolsex.others;

import org.bukkit.configuration.file.*;
import org.bukkit.inventory.*;
import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.configuration.*;
import org.bukkit.*;
import org.apache.commons.lang.*;
import java.util.*;

public class Config
{
    public Main plugin;
    public static FileConfiguration config;
    public int autoSaveDelay;
    public List<String> autoMessageMessages;
    public int autoMessageDelay;
    public String autoMessagePrefix;
    public int slotManagerSlots;
    public String slotManagerMotd;
    public List<String> helpMessages;
    public int teleportDelay;
    public int teleportSpawnCooldown;
    public boolean silentJoinLeave;
    public List<String> welcomeMessage;
    public String mysqlHost;
    public String mysqlUser;
    public String mysqlPass;
    public String mysqlDb;
    public int randomMin;
    public int randomMax;
    public int randomGroupRadius;
    public int homeNormal;
    public int homeMulti;
    public List<String> packsName;
    public HashMap<String, ItemStack[]> packs;
    public boolean nether;
    public Location spawn;
    public HashMap<String, WarpManager> warps;
    
    public Config(final Main plugin) {
        super();
        this.packsName = new ArrayList<String>();
        this.packs = new HashMap<String, ItemStack[]>();
        this.warps = new HashMap<String, WarpManager>();
        this.plugin = plugin;
        this.plugin.getConfig().options().copyDefaults(true);
        this.plugin.saveConfig();
        this.load();
    }
    
    public void load() {
        this.plugin.reloadConfig();
        this.autoSaveDelay = this.plugin.getConfig().getInt("config.auto-save.delay");
        this.autoMessageMessages = (List<String>)this.plugin.getConfig().getStringList("config.automessage.messages");
        this.autoMessageDelay = this.plugin.getConfig().getInt("config.automessage.delay");
        this.autoMessagePrefix = this.plugin.getConfig().getString("config.automessage.prefix");
        this.slotManagerSlots = this.plugin.getConfig().getInt("config.slotmanager.slots");
        this.slotManagerMotd = this.plugin.getConfig().getString("config.slotmanager.motd");
        this.helpMessages = (List<String>)this.plugin.getConfig().getStringList("config.helpMessages");
        this.teleportDelay = this.plugin.getConfig().getInt("config.teleport.delay");
        this.teleportSpawnCooldown = this.plugin.getConfig().getInt("config.teleport.spawn.cooldown");
        this.silentJoinLeave = this.plugin.getConfig().getBoolean("config.silentjoinleave");
        this.welcomeMessage = (List<String>)this.plugin.getConfig().getStringList("config.welcomemessage");
        this.mysqlHost = this.plugin.getConfig().getString("MySQL.Host");
        this.mysqlUser = this.plugin.getConfig().getString("MySQL.Username");
        this.mysqlPass = this.plugin.getConfig().getString("MySQL.Password");
        this.mysqlDb = this.plugin.getConfig().getString("MySQL.Database");
        this.randomMin = this.plugin.getConfig().getInt("config.randomtp.min");
        this.randomMax = this.plugin.getConfig().getInt("config.randomtp.max");
        this.randomGroupRadius = this.plugin.getConfig().getInt("config.randomtp.groups.radius");
        this.homeNormal = this.plugin.getConfig().getInt("config.home.normal");
        this.homeMulti = this.plugin.getConfig().getInt("config.home.multi");
        final ConfigurationSection section = this.plugin.getConfig().getConfigurationSection("packs");
        for (final String packString : section.getKeys(false)) {
            this.packsName.add(packString);
            this.packs.put(packString.toLowerCase(), Main.deserializeItemStacks(section.getString(packString)));
        }
        this.nether = this.plugin.getConfig().getBoolean("config.nether");
        this.spawn = this.loc(this.plugin.getConfig().getString("config.spawn"));
        if (this.plugin.getConfig().isConfigurationSection("warps")) {
            final ConfigurationSection sectionW = this.plugin.getConfig().getConfigurationSection("warps");
            for (final String warpName : sectionW.getKeys(false)) {
                final String warpS = warpName;
                final String[] split = this.plugin.getConfig().getString("warps." + warpS).split(";");
                if (split.length == 2) {
                    final World world = Bukkit.getWorld(split[0]);
                    final String[] xyzSplit = split[1].split(",");
                    if (xyzSplit.length != 3) {
                        continue;
                    }
                    final int x = Integer.parseInt(xyzSplit[0]);
                    final int y = Integer.parseInt(xyzSplit[1]);
                    final int z = Integer.parseInt(xyzSplit[2]);
                    this.warps.put(warpName.toLowerCase(), new WarpManager(warpName, new Location(world, (double)x, (double)y, (double)z)));
                }
            }
        }
        else {
            this.plugin.getConfig().createSection("warps");
        }
    }
    
    public void save() {
        this.plugin.getConfig().set("config.auto-save.delay", (Object)this.autoSaveDelay);
        this.plugin.getConfig().set("config.automessage.messages", (Object)this.autoMessageMessages);
        this.plugin.getConfig().set("config.automessage.delay", (Object)this.autoMessageDelay);
        this.plugin.getConfig().set("config.automessage.prefix", (Object)this.autoMessagePrefix);
        this.plugin.getConfig().set("config.slotmanager.slots", (Object)this.slotManagerSlots);
        this.plugin.getConfig().set("config.slotmanager.motd", (Object)this.slotManagerMotd);
        this.plugin.getConfig().set("config.helpMessages", (Object)this.helpMessages);
        this.plugin.getConfig().set("config.teleport.delay", (Object)this.teleportDelay);
        this.plugin.getConfig().set("config.teleport.spawn.cooldown", (Object)this.teleportSpawnCooldown);
        this.plugin.getConfig().set("config.silentjoinleave", (Object)this.silentJoinLeave);
        this.plugin.getConfig().set("config.welcomemessage", (Object)this.welcomeMessage);
        this.plugin.getConfig().set("MySQL.Host", (Object)this.mysqlHost);
        this.plugin.getConfig().set("MySQL.Username", (Object)this.mysqlUser);
        this.plugin.getConfig().set("MySQL.Password", (Object)this.mysqlPass);
        this.plugin.getConfig().set("MySQL.Database", (Object)this.mysqlDb);
        this.plugin.getConfig().set("config.randomtp.min", (Object)this.randomMin);
        this.plugin.getConfig().set("config.randomtp.max", (Object)this.randomMax);
        this.plugin.getConfig().set("config.randomtp.groups.radius", (Object)this.randomGroupRadius);
        final ConfigurationSection section = this.plugin.getConfig().getConfigurationSection("packs");
        for (final String packName : this.packsName) {
            section.set(packName, (Object)Main.serializeItemStacks(this.packs.get(packName.toLowerCase())));
        }
        this.plugin.getConfig().set("config.nether", (Object)this.nether);
        this.plugin.getConfig().set("config.spawn", (Object)this.loc(this.spawn));
        if (!this.plugin.getConfig().isConfigurationSection("warps")) {
            this.plugin.getConfig().createSection("warps");
        }
        final ConfigurationSection sectionW = this.plugin.getConfig().getConfigurationSection("warps");
        for (final WarpManager warp : this.warps.values()) {
            final Location loc = warp.getLoc();
            final List<String> cos = new ArrayList<String>();
            cos.add(loc.getWorld().getName());
            cos.add(loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ());
            sectionW.set(warp.getName(), (Object)StringUtils.join((Collection)cos, ";"));
        }
        this.plugin.saveConfig();
    }
    
    String loc(final Location loc) {
        final List<String> list = new ArrayList<String>();
        if (loc != null) {
            list.add(loc.getWorld().getName());
            list.add(Integer.toString(loc.getBlockX()));
            list.add(Integer.toString(loc.getBlockY()));
            list.add(Integer.toString(loc.getBlockZ()));
        }
        return StringUtils.join((Collection)list, ",");
    }
    
    Location loc(final String s) {
        if (s == null) {
            return null;
        }
        if (s.equals("")) {
            return null;
        }
        final String[] splitS = s.split("\\,");
        if (splitS.length == 4) {
            final World world = Bukkit.getWorld(splitS[0]);
            final int x = Integer.parseInt(splitS[1]);
            final int y = Integer.parseInt(splitS[2]);
            final int z = Integer.parseInt(splitS[3]);
            return new Location(world, x + 0.5, (double)y, z + 0.5);
        }
        return null;
    }
    
    public void reload() {
        this.load();
    }
}
