package com.gmail.tirexgta.ttoolsex.listeners;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.plugin.*;
import org.bukkit.event.player.*;
import org.bukkit.event.*;
import org.bukkit.event.world.*;

public class PortalListener implements Listener
{
    Main plugin;
    
    public PortalListener(final Main main) {
        super();
        this.plugin = main;
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
    }
    
    @EventHandler
    public void onTravel(final PlayerPortalEvent e) {
        if (e.getCause().equals((Object)PlayerTeleportEvent.TeleportCause.NETHER_PORTAL)) {
            if (!this.plugin.config.nether) {
                e.getPlayer().sendMessage(" �7�l� �cNie mozesz sie teleportowac do piekla!");
                e.setCancelled(true);
            }
        }
        else if (e.getCause().equals((Object)PlayerTeleportEvent.TeleportCause.END_PORTAL)) {
            e.getPlayer().sendMessage(" �7�l� �cNie mozesz sie teleportowac do endu!");
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onTravel(final PortalCreateEvent e) {
        e.setCancelled(true);
    }
}
