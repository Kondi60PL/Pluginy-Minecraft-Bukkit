package com.gmail.tirexgta.ttoolsex.listeners;

import com.gmail.tirexgta.ttoolsex.*;
import java.util.*;
import org.bukkit.entity.*;
import org.bukkit.plugin.*;
import org.bukkit.*;
import org.bukkit.craftbukkit.v1_7_R3.entity.*;
import com.gmail.tirexgta.tguildsex.mysql.*;
import com.gmail.tirexgta.ttoolsex.database.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.scoreboard.*;

public class ScoreboardListener implements Listener
{
    Main plugin;
    ScoreboardManager sbManager;
    Scoreboard board;
    HashMap<Player, Objective> players;
    
    public ScoreboardListener(final Main plugin) {
        super();
        this.players = new HashMap<Player, Objective>();
        this.plugin = plugin;
        this.plugin.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this.plugin);
        this.sbManager = this.plugin.getServer().getScoreboardManager();
        this.board = this.sbManager.getMainScoreboard();
        this.plugin.getServer().getScheduler().runTaskTimerAsynchronously((Plugin)this.plugin, (Runnable)new Runnable() {
            @Override
            public void run() {
                Player[] onlinePlayers;
                for (int length = (onlinePlayers = Bukkit.getOnlinePlayers()).length, i = 0; i < length; ++i) {
                    final Player p = onlinePlayers[i];
                    if (p != null) {
                        final Objective objective = ScoreboardListener.this.players.get(p);
                        if (objective != null) {
                            ScoreboardListener.this.setScore("�fOnline:", Bukkit.getOnlinePlayers().length, objective);
                            final double ping = ((CraftPlayer)p).getHandle().ping / 2.5;
                            ScoreboardListener.this.setScore("�fPing:", (int)ping, objective);
                            final DataGuildUser user = com.gmail.tirexgta.tguildsex.Main.getInstance().data.getUserByPlayer(p);
                            if (user != null) {
                                ScoreboardListener.this.setScore("�fRanking", user.getPoints(), objective);
                            }
                            final DataUser user$2 = Datasource.getUserData(p);
                            if (user$2 != null) {
                                ScoreboardListener.this.setScore("�fPunkty", user$2.getPkt(), objective);
                            }
                        }
                    }
                }
            }
        }, 20L, 200L);
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onLogin(final PlayerJoinEvent e) {
        final Player p = e.getPlayer();
        if (p == null) {
            return;
        }
        final Scoreboard board = p.getScoreboard();
        if (board == null) {
            return;
        }
        Objective objective = board.getObjective(p.getName());
        if (objective == null) {
            objective = board.registerNewObjective(p.getName(), "global");
        }
        if (objective == null) {
            return;
        }
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        objective.setDisplayName("�8[ �cL�fC �8]");
        this.setScore("�fOnline:", Bukkit.getOnlinePlayers().length, objective);
        final double ping = ((CraftPlayer)p).getHandle().ping / 2.5;
        this.setScore("�fPing:", (int)ping, objective);
        final DataGuildUser user = com.gmail.tirexgta.tguildsex.Main.getInstance().data.getUserByPlayer(p);
        if (user != null) {
            this.setScore("�fRanking", user.getPoints(), objective);
        }
        final DataUser user$2 = Datasource.getUserData(p);
        if (user$2 != null) {
            this.setScore("�fPunkty", user$2.getPkt(), objective);
        }
        this.players.put(p, objective);
    }
    
    @EventHandler
    public void onQuit(final PlayerQuitEvent e) {
        final Player p = e.getPlayer();
        if (p == null) {
            return;
        }
        if (!this.players.containsKey(p)) {
            return;
        }
        this.players.get(p).unregister();
        this.players.remove(p);
    }
    
    @EventHandler
    public void onKicked(final PlayerKickEvent e) {
        final Player p = e.getPlayer();
        if (p == null) {
            return;
        }
        if (!this.players.containsKey(p)) {
            return;
        }
        this.players.get(p).unregister();
        this.players.remove(p);
    }
    
    void setScore(final String name, final int amount, final Objective objective) {
        final Score score = objective.getScore(name);
        score.setScore(amount);
    }
    
    void setPktObjective(final Scoreboard board) {
    }
}
