package com.gmail.tirexgta.ttoolsex.commands;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import com.gmail.tirexgta.ttoolsex.database.*;

public class SethomeCommand implements CommandExecutor
{
    Main plugin;
    
    public SethomeCommand(final Main plugin) {
        super();
        this.plugin = plugin;
        this.plugin.getCommand("sethome").setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("�cTa komenda nie moze byc wywolana z konsoli!");
            return true;
        }
        final Player p = (Player)sender;
        final Location loc = p.getLocation();
        final DataUser user = Datasource.getUserData(p);
        if (args.length == 0) {
            if (this.setHome(sender, user, loc, 0, args)) {
                sender.sendMessage(" �7�l� �aUstawiles dom!");
            }
        }
        else if (args[0].equalsIgnoreCase("list")) {
            sender.sendMessage(" �7�l� Dom nie moze sie tak nazywac!");
        }
        else if (this.setHome(sender, user, loc, 1, args)) {
            sender.sendMessage(" �7�l� �aUstawiles dom!");
        }
        return false;
    }
    
    boolean setHome(final CommandSender sender, final DataUser user, final Location loc, final int argsLength, final String[] args) {
        if (argsLength == 0) {
            user.setHome("home", loc);
        }
        else if (argsLength == 1) {
            if (sender.hasPermission("tirex.home.multi")) {
                if (user.isHome(args[0])) {
                    user.setHome(args[0], loc);
                    return true;
                }
                if (user.isHome(this.plugin.config.homeMulti)) {
                    sender.sendMessage(" �7�l� �cMasz za duzo ustawionych domow!");
                    return false;
                }
                user.setHome(args[0], loc);
            }
            else {
                if (user.isHome(args[0])) {
                    user.setHome(args[0], loc);
                    return true;
                }
                if (user.isHome(this.plugin.config.homeNormal)) {
                    sender.sendMessage(" �7�l� �cMasz za duzo ustawionych domow!");
                    return false;
                }
                user.setHome(args[0], loc);
            }
        }
        return true;
    }
}
