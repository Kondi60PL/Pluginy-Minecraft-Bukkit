package com.gmail.tirexgta.ttoolsex.commands;

import com.gmail.tirexgta.ttoolsex.*;
import org.bukkit.command.*;
import org.bukkit.*;

public class NetherCommand implements CommandExecutor
{
    Main plugin;
    
    public NetherCommand(final Main plugin) {
        super();
        this.plugin = plugin;
        plugin.getCommand("nether").setExecutor((CommandExecutor)this);
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String label, final String[] args) {
        if (this.plugin.config.nether) {
            this.plugin.config.nether = false;
            Bukkit.broadcastMessage("");
            Bukkit.broadcastMessage("�7##############");
            Bukkit.broadcastMessage("�7Nether �aWlaczony�7!");
            Bukkit.broadcastMessage("�7##############");
            Bukkit.broadcastMessage("");
        }
        else {
            this.plugin.config.nether = true;
            Bukkit.broadcastMessage("");
            Bukkit.broadcastMessage("�7##############");
            Bukkit.broadcastMessage("�7Nether �aWylaczony�7!");
            Bukkit.broadcastMessage("�7##############");
            Bukkit.broadcastMessage("");
        }
        this.plugin.config.save();
        return false;
    }
}
