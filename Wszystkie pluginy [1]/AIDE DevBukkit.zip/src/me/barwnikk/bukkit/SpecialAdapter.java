package me.barwnikk.bukkit;
import android.content.*;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.*;
public class SpecialAdapter extends BaseAdapter
{
    private LayoutInflater mInflater; private String[] data;private int[] ktore2;private String[] langi;
	public SpecialAdapter(Context context, String[] results, int[] ktore, String[] langi2)
	{ mInflater = LayoutInflater.from(context); data = results;ktore2 = ktore;this.langi=langi2;
	}
	public int getCount()
	{ return data.length;
	}
	public Object getItem(int position)
	{ return position; }
	public long getItemId(int position)
	{ return position; }
	public View getView(int position, View convertView, ViewGroup parent)
	{ MainActivity holder;
		if (convertView == null)
		{ convertView = mInflater.inflate(R.layout.row, null); holder = new MainActivity();holder.ikona = (ImageView) convertView.findViewById(R.id.ikona);   holder.obrazek = (ImageView) convertView.findViewById(R.id.ptaszek); 
			holder.text = (TextView) convertView.findViewById(R.id.headline); convertView.setTag(holder); }
		else
		{
			holder = (MainActivity) convertView.getTag();
		}
		holder.text.setText(data[position]);holder.obrazek.setVisibility(8);try{if(langi[position]==""){holder.ikona.setVisibility(4);} else {holder.ikona.setImageResource(addedApi.getFromDrawable(langi[position]));}  } catch (ArrayIndexOutOfBoundsException e){ holder.ikona.setVisibility(4); }
		for (int i=0;i < ktore2.length;i++)
		{   if (ktore2[i] == position)
			{ holder.obrazek.setVisibility(0);}}
		return convertView; }
}
