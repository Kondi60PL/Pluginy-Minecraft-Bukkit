package me.barwnikk.bukkit;
import me.barwnikk.bukkit.*;
public class lgread
{ static public String setlg = "en";

	public static void setlg(String czytaj)
	{
		setlg=czytaj.replaceAll("\n","");System.err.println(czytaj);
	}
	public static String getLanguage(String args)
	{return language.lg[getIntOfParametr(args)][getIntOfLg()];}
    public static int getIntOfParametr(String parametr)
	{for (int i=0;i < language.lg.length;i++)
		{if (language.lg[i][0].equalsIgnoreCase(parametr))
			{return i;}}return 0;}
    public static int getIntOfLg()
	{for (int i=1;i < language.lg[getIntOfParametr("language")].length;i++)
		{if (setlg.equalsIgnoreCase(language.lg[getIntOfParametr("language")][i]))
			{return i;}}return 0;}
}
