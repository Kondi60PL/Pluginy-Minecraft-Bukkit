package me.barwnikk.bukkit;
 public class language
{
public final static String lg[][] = {
{"language","gb","pl"},
{"dia_save","Save","Zapisz"},
{"dia_canel","Canel","Anuluj"},
{"ak_text","You must log in with apikey. You can get it on <link> and click 'Regenerate'. Api-key:","Musisz podać kod api do zalogowania. Możesz zdobyć go na <link> klikając na przycisk 'Regenerate'. Klucz api:"},
{"lg_name","English","Polish"},
{"lg_inany","English","Polski"},
{"dia_no","No","Nie"},
{"dia_yes","Yes","Tak"},
{"set_forget_msg","Delete api key?","Napewno usunąć zapamiętany klucz?"},
{"set_forget","Forget key","Zapomnij klucz"},
{"set_language","Change language","Zmień język"},
{"log_settings","Settings","Ustawienia"},
{"log_messages","Messages","Wiadomości"},
{"log_language","Change language","Zmień język"},
{"log_title","Hi <user>!","Witaj <user>!"},
{"log_authors","Authors","Autorzy"},
{"log_profile","Your profile","Twój profil"},
{"log_server","Server mods","Pluginy"},
{"log_client","Client mods","Modyfikacje klienta"},
{"log_texturepack","Texture Pack","Tekstury"},
{"log_loginout","Login out","Wyloguj"},
{"ak_button","Log in", "Zaloguj"},
{"ak_use","Use saved key","Użyj zapisany klucz"},
{"ak_remember","Remember key","Pamiętaj klucz"},
{"ak_errmember","I can't remember key!","Nie mogę zapamiętać kluczu!"},
{"ak_incorrect","Your api-key is incorrect or You are disconnect from network! Please check your network connect and api-key","Twój api-key jest niepoprawny lub jesteś rozłączony od sieci! Sprawdź połączenie internetowe i kod."},
{"ak_long","Api-key is too long!","Kod api jest zbyt długi!"},
{"ak_short","Api-key is too short!","Kod api jest zbyt krótki!"},
{"ak_char","<number><end> char \"<char_incorrect>\" is not allowed! Allowed chars: <chars_allowed>","<number> znak \"<char_incorrect>\" jest niedozwolony! Dozwolone znaki: <chars_allowed>"}
};}
