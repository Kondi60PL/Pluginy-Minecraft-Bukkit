package me.barwnikk.bukkit;
import android.content.*;
import java.io.*;
import java.net.*;
public class addedApi
{   
static public int getFromDrawable(String name) {
   try
	{
	return	R.drawable.class.getField(name).getInt(name);
	}
	catch (NoSuchFieldException e)
	{}
	catch (IllegalAccessException e)
	{}
	catch (IllegalArgumentException e)
	{}return R.drawable.red;
}






static public String[][] push(String[][] array, String[] push)
	{
		String[][] temp = new String[array.length + 1][];
		for (int i=0;i < array.length;i++)
		{
			temp[i] = array[i];
		}
		temp[array.length] = push;
		return temp;}
    static public String[] remove(String[] array, int when) {
        String[] temp = new String[array.length-1];int j=0;
        for(int i=0;i<array.length;i++){
            if(when!=i){ temp[j]=array[i]; j++;  }
        }
        return temp;
    }
	static public boolean searchStr(String search, String what)
	{
		if (!search.replaceAll(what, "_").equals(search))
		{return true;}
		return false;
	}static public String czytaj(FileInputStream read)
	{
		//openFileInput(FILENAME)
		String calosc = "";
		int line;int k=0;
		try
		{
			while ((line = read.read()) != -1)
			{if (k == 0)
				{calosc += line;}
				else
				{
					calosc += "\n" + line;}k++;
			}
		}
		catch (IOException e)
		{e.printStackTrace();return "LocalizedMessage:" + e.getLocalizedMessage() + " Message:\n" + e.getMessage();}String[] t1 = calosc.split("\n");byte[] bajty = new byte[t1.length];for (int j=0;j < t1.length;j++)
		{bajty[j] = new Byte(t1[j]);}
		return (new String(bajty));

	}
    static public void zapisz(FileOutputStream fos, String tresc)
	{
		try
		{
			fos.write(tresc.getBytes());fos.close();
		}
		catch (IOException e)
		{e.printStackTrace();}
	}
	static public String wyslijPost(String url2, String data)
	{
		try
		{
			URL url = new URL(url2);
			URLConnection conn = url.openConnection();
			conn.setDoOutput(true);
			OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
			wr.write(data);
			wr.flush();
			BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String calosc = "";
			String line;
			while ((line = rd.readLine()) != null)
			{
				calosc += "\n" + line;
			}
			wr.close();
			rd.close();return calosc;
		}
		catch (IOException e)
		{ByteArrayOutputStream baos = new ByteArrayOutputStream(); PrintStream ps = new PrintStream(baos); e.printStackTrace(ps); String content = baos.toString();e.printStackTrace();return content;
		}}static public String wyslijGet(String url2)
	{
		try
		{
			URL url = new URL(url2);
			url.openConnection();
			BufferedReader rd = new BufferedReader(new InputStreamReader(url.openStream()));
			String calosc = "";
			String line;
			while ((line = rd.readLine()) != null)
			{	calosc += "\n" + line;
			}
			rd.close();return calosc;
		}
		catch (IOException e)
		{ByteArrayOutputStream baos = new ByteArrayOutputStream(); PrintStream ps = new PrintStream(baos); e.printStackTrace(ps); String content = baos.toString();e.printStackTrace();return content;
		}}
	static public String czyPoprawny(String apikey)
	{   String code = wyslijGet("http://dev.bukkit.org/home/?api-key=" + apikey);  if (getLogged(code).equalsIgnoreCase("false"))
		{return "false";} String[] code2 = code.split("\n");if (code2.length > 10)
		{return code;}
		return "false";
	}static public String getLogged(String code)
	{String[] kod = code.split("\n");for (int i=0;i < kod.length;i++)
		{if (searchStr(kod[i], "<input type=\"text\" name=\"search\" class=\"search-input\" value=\"\" data-watermark-text=\"Search...\" />"))
			{return kod[i + 5].replaceAll("                            ", "");}}return "false";}
}
