package me.barwnikk.bukkit;

import android.app.*;
import android.content.*;
import android.os.*;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.lang.reflect.*;
import android.graphics.drawable.*;

public class MainActivity extends Activity
{   
	boolean bledy = true;
	boolean logged = false;
	boolean jezyki = false;
	boolean menugl = true;
    Button anuluj;Button savedak;
	Button przycisk;
	Button zapisz;
	CheckBox pudlo;
	EditText login;
	ImageView obrazek;
	ImageView ikona;
	int zaznaczonyjezyk=0;
	int[] zadne = {};
	ListView list;
	String apikey = "";
	String uzytkownik = "";
    String[] obecne;
	String[] jezykiPub;
	String[] plangi={};
	String[] flagi = addedApi.remove(language.lg[lgread.getIntOfParametr("language")],0);
	TextView ak_text;
	TextView text;
	TextView title;String[] menuglik={"","","","","","","",""};
	ProgressBar pasek;
	public void loguj(String kodz)
	{
		String zrodlo = addedApi.getLogged(addedApi.czyPoprawny(kodz));
		if (!zrodlo.equalsIgnoreCase("false"))
		{
			pudlo.setVisibility(8);uzytkownik = zrodlo;
			title.setText(lgread.getLanguage("log_title").replaceAll(
							  "<user>", uzytkownik));
			apikey = login.getText().toString();
			list.setVisibility(0);
			glmenu();savedak.setVisibility(8);
			login.setVisibility(8);
			przycisk.setVisibility(8);
			ak_text.setVisibility(8);
		}
		else
		{
			Toast.makeText(getApplicationContext(),
						   lgread.getLanguage("ak_incorrect"), 5000).show();
		}
	}
	public void glmenu()
	{menugl = true;
		String[] wynik={lgread.getLanguage("log_authors"),
			lgread.getLanguage("log_profile"),
			lgread.getLanguage("log_messages"),
			lgread.getLanguage("log_server"),
			lgread.getLanguage("log_client"),
			lgread.getLanguage("log_texturepack"),
			lgread.getLanguage("log_settings"),
			lgread.getLanguage("log_loginout") };zmien(wynik, zadne, menuglik);}
	public void zmien(String[] items, int[] ktore, String[] langi)
	{
		obecne = items;
		SpecialAdapter adapter = new SpecialAdapter(this, items, ktore, langi);
		list.setAdapter(adapter);
	}
	public void jezyki()
	{	savedak.setText(lgread.getLanguage("ak_use"));
		pudlo.setText(lgread.getLanguage("ak_remember"));
		title.setText(lgread.getLanguage("log_title").replaceAll("<user>", uzytkownik));
		ak_text.setText(Html
						.fromHtml(lgread
								  .getLanguage("ak_text")
								  .replaceAll(
									  "<link>",
									  "<a href='https://dev.bukkit.org/home/api-key'>https://dev.bukkit.org/home/api-key</a>")));
		przycisk.setText(lgread.getLanguage("ak_button"));}
	public void onBackPressed()
	{
		if (login.getVisibility() == 0)
		{ finish(); }jezyki = false;
		anuluj.setVisibility(8);
		zapisz.setVisibility(8);
		if (menugl)
		{ wyloguj();}
		else
		{
			glmenu(); jezyki();} 
	}
	private void wyloguj()
	{if(isSet("key")){savedak.setVisibility(0);}
		apikey = "";uzytkownik = "";
		list.setVisibility(8);
		title.setText("Api-key");
		przycisk.setVisibility(0);
		pudlo.setVisibility(0);
		ak_text.setVisibility(0);
		login.setVisibility(0);
		logged = true;
		login.setText("");
		menugl = true;
	}public void ustawienia()
	{menugl = false;String temp[] = { lgread.getLanguage("set_language"),
			lgread.getLanguage("set_forget")};  if (isSet("key"))
		{zmien(temp, zadne, plangi);}
		else
		{temp = addedApi.remove(temp, 1);
			zmien(temp, zadne, plangi);}}
	public boolean isSet(String file)
	{
		try
		{
			FileInputStream test = openFileInput(file);
			test.close();
			return true;
		}
		catch (IOException e)
		{
			return false;
		}
	}
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);savedak=(Button)findViewById(R.id.writeak);
		anuluj = (Button) findViewById(R.id.lgcanel);
		pudlo = (CheckBox) findViewById(R.id.member);
		pasek = (ProgressBar) findViewById(R.id.progress);
		title = (TextView) findViewById(R.id.tytulak);
		list = (ListView) findViewById(R.id.list);
		ak_text = (TextView) findViewById(R.id.textnadapikey);
		przycisk = (Button) findViewById(R.id.logowanieOkak);
		zapisz = (Button) findViewById(R.id.lgsave);
		login = (EditText) findViewById(R.id.apikey);
		list.setSmoothScrollbarEnabled(true);
		try
		{
			if (!isSet("language"))
			{
				addedApi.zapisz(openFileOutput("language", 0), "gb");
			}
			lgread.setlg(addedApi.czytaj(openFileInput("language")));
			if (isSet("key"))
			{loguj(addedApi.czytaj(openFileInput("key")));
			} else {savedak.setVisibility(8);}
		}
		catch (IOException e)
		{
		}
		pasek.setVisibility(8);
		zapisz.setVisibility(8);
		anuluj.setVisibility(8);jezyki();
		login.setMaxLines(1);
		przycisk.setEnabled(false);
		list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				public void onItemClick(AdapterView<?> parent, View view,
										int position, long id)
				{menugl = false;
					if (jezyki)
					{

						int[] wybrany = {position};
						zmien(jezykiPub, wybrany, flagi);
						anuluj.setText(lgread.getLanguage("dia_canel")
									   + " ("
									   + language.lg[lgread.getIntOfParametr("dia_canel")][position + 1]
									   + ")");
						zapisz.setText(lgread.getLanguage("dia_save")
									   + " ("
									   + language.lg[lgread.getIntOfParametr("dia_save")][position + 1]
									   + ")");
						title.setText((lgread.getLanguage("log_title")
									  + " ("
									  + language.lg[lgread.getIntOfParametr("log_title")][position
									  + 1]
									  + ")")
									  .replaceAll(
										  "<user>", uzytkownik));
						zaznaczonyjezyk = position;
					}
					else if (position == 7
							 && obecne[position].equalsIgnoreCase(lgread .getLanguage("log_loginout")))
					{
						wyloguj();
					}
					else if (position == 6
							 && obecne[position].equals(lgread.getLanguage("log_settings")))
					{
						ustawienia();
					}
					else if (position == 1 && obecne[position].equals(lgread.getLanguage("set_forget")))
					{
						AlertDialog komunikat =new AlertDialog.Builder(MainActivity.this).create(); 
						komunikat.setMessage(lgread.getLanguage("set_forget_msg")); 
						komunikat.setButton(lgread.getLanguage("dia_yes"), new DialogInterface.OnClickListener() {

								public void onClick(DialogInterface p1, int p2)
								{
									getApplicationContext().deleteFile("key");ustawienia();
								}
							}); komunikat.setButton2(lgread.getLanguage("dia_no"), new DialogInterface.OnClickListener() {

								public void onClick(DialogInterface p1, int p2)
								{

								}
							});komunikat.show(); }
					else if (position == 0 && obecne[position].equals(lgread.getLanguage("set_language")))
					{   String[] skroty = language.lg[lgread.getIntOfParametr("language")];
						skroty = addedApi.remove(skroty, 0);
						String[] jezykiEN =  language.lg[lgread.getIntOfParametr("lg_name")];
						jezykiEN = addedApi.remove(jezykiEN, 0);
						String[] jezykiIN =language.lg[lgread.getIntOfParametr("lg_inany")];
						jezykiIN = addedApi.remove(jezykiIN, 0);
						String[] wynik = new String[jezykiEN.length];
						for (int i=0;i < jezykiEN.length;i++)
						{
							wynik[i] = jezykiIN[i] + " - " + jezykiEN[i];
						}
						int[] wybrany = {lgread.getIntOfLg() - 1};
						zaznaczonyjezyk = wybrany[0];
						zmien(wynik, wybrany, flagi);
						jezyki = true;
						zapisz.setText(lgread.getLanguage("dia_save"));
						jezykiPub = wynik;anuluj.setText(lgread.getLanguage("dia_canel"));
						zapisz.setVisibility(0);
						anuluj.setVisibility(0);
					}
				}
			});
		anuluj.setOnClickListener(new View . OnClickListener(){

				public void onClick(View p1)
				{
					zapisz.setVisibility(8);
					jezyki = false;ustawienia();
					jezyki();
					anuluj.setVisibility(8);
				}
			});
		zapisz.setOnClickListener(new View . OnClickListener(){
				public void onClick(View p1)
				{
					lgread.setlg(language.lg[lgread.getIntOfParametr("language")][zaznaczonyjezyk + 1]);
					zapisz.setVisibility(8);
					jezyki = false;ustawienia();
					jezyki();
					anuluj.setVisibility(8);
					try
					{
						addedApi.zapisz(openFileOutput("language", 0), lgread.setlg);
					}
					catch (FileNotFoundException e)
					{}
				}
			});savedak.setOnClickListener(new View . OnClickListener(){

				public void onClick(View p1)
				{
					try
					{
						login.setText(addedApi.czytaj(openFileInput("key")));
					}
					catch (FileNotFoundException e)
					{}
				}
			});
		login.addTextChangedListener(new TextWatcher() {
				public void beforeTextChanged(CharSequence p1, int p2, int p3,
											  int p4)
				{
				}
				public String end(int num)
				{
					String nums = num + "";
					if ((num < 21) && (num > 3))
					{
						return "th";
					}
					else
					{
						num = Integer.parseInt("" + nums.charAt(nums.length() - 1));
						if (num == 1)
						{
							return "st";
						}
						if (num == 2)
						{
							return "nd";
						}
						if (num == 3)
						{
							return "rd";
						}
						return "th";
					}
				}
				public void onTextChanged(CharSequence p1, int p2, int p3, int p4)
				{
				}
				public void onErr(String err)
				{
					if (bledy)
					{
						if (!logged)
						{
							bledy = false;
							Toast.makeText(getApplicationContext(), err, 1000).show();
							System.err.println("[WARRNING!] " + err);
						}
						else
						{
							logged = false;
						}
					}
				}
				public void afterTextChanged(Editable p1)
				{
					bledy = true;
					boolean poprawne = false;
					int iloscok = 0;
					String p2 = p1 + "";
					if (p2.length() > 40)
					{
						onErr(lgread.getLanguage("ak_long"));
					}
					if (p2.length() < 40)
					{
						onErr(lgread.getLanguage("ak_short"));
					}
					String[] acceptChars = { "1", "2", "3", "4", "5", "6", "7",
						"8", "9", "0", "a", "b", "c", "d", "e", "f" };
					String znaki = "1234567890abcdef";
					for (int i = 0; i < p2.length(); i++)
					{
						boolean il = true;
						for (int y = 0; y < acceptChars.length; y++)
						{
							if (acceptChars[y].equalsIgnoreCase(p2.charAt(i) + ""))
							{
								il = false;
								iloscok++;
							}
						}
						if (il)
						{
							onErr(lgread
								  .getLanguage("ak_char")
								  .replaceAll("<number>", i + "")
								  .replaceAll("<end>", end(i))
								  .replaceAll("<chars_allowed>", znaki)
								  .replaceAll("<char_incorrect>", p2.charAt(i) + ""));
						}
					}
					if (iloscok == 40 && p2.length() == 40)
					{
						poprawne = true;
					}
					przycisk.setEnabled(poprawne);
				}
			});
		przycisk.setOnClickListener(new View.OnClickListener() {
				public void onClick(View p1)
				{
					p1.setEnabled(false);loguj(login.getText().toString());
					if (pudlo.isChecked())
					{
						try
						{
							addedApi.zapisz(openFileOutput("key", 0), login.getText().toString());
						}
						catch (FileNotFoundException e)
						{
							Toast.makeText(getApplicationContext(), lgread.getLanguage("ak_errmember"), 5000).show();
						}
					}
				}
			});
	}
}

