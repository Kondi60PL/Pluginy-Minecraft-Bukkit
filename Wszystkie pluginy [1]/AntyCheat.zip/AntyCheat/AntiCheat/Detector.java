

import org.bukkit.entity.Player;

public abstract interface Detector
{
  public abstract void Reset(Player paramPlayer);
}
