
public enum DeathMessageType
{
  Absolute,  Detailed,  Simple,  None;
}
