package pl.digitalix96.mchard;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import net.minecraft.server.v1_7_R1.Scoreboard;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import pl.digitalix96.mchard.Managers.GPlayer;
import pl.digitalix96.mchard.Managers.Guild;
import pl.digitalix96.mchard.Managers.GuildLocation;
import pl.digitalix96.mchard.Managers.HPlayer;
import pl.digitalix96.mchard.Managers.Ranking;

public class MCH {

	
	public HashMap<String, Guild> guilds = new HashMap<String, Guild>();
	public static List<HPlayer> hp = new ArrayList<HPlayer>();
	public static HashMap<String, HPlayer> HPlayers = new HashMap<String, HPlayer>();
	public HashMap<String, HPlayer> hpm = new HashMap<String, HPlayer>();
	public static HashMap<Player, GPlayer> pzone = new HashMap<Player, GPlayer>();
	public List<Guild> guildlist = new ArrayList<Guild>();
	public List<String> ips = new ArrayList<String>();
	public int appnum = 1;
	public static int size = 50;
	
	public static String world = "world";
    public static Scoreboard board;
	public int a(String a) {
		return Integer.valueOf(a);
	}

	public boolean HCMode = true;
	public boolean AntiRelogEnable = true;
            
        public static HashMap<String,Ranking> rankings = new HashMap();
        public static ArrayList<Ranking> ranks = new ArrayList();
        
	public boolean loadGuilds() {
            
		try {
                        ResultSet rss = MCHard.mysql.query("SELECT * FROM statystyki");
                        while(rss.next()){
                            String n = rss.getString("nick");
                            int p = rss.getInt("punkty");
                            int s = rss.getInt("smierci");
                            int z = rss.getInt("zabojstwa");
                            Ranking r = new Ranking(n, p, z, s);
                            MCH.rankings.put(n, r);
                            MCH.ranks.add(r);
                        }
                        MCH.board = new Scoreboard();
			ResultSet rs = MCHard.mysql.query("SELECT * FROM gildie");
			while (rs.next()) {
				String name = rs.getString("logo").toUpperCase();
				String fullname = rs.getString("nazwa").toUpperCase();
				String[] l = rs.getString("pol").split(":");
				String lider = rs.getString("lider");
				String zastepca = rs.getString("zastepca");
				List<String> czlonkowie = new ArrayList<String>();
				List<String> sojusze = new ArrayList<String>();
				ResultSet rs1 = MCHard.mysql
						.query("SELECT * FROM czlonkowie WHERE gildia = '"
								+ name + "'");
				ResultSet rs2 = MCHard.mysql
						.query("SELECT * FROM ghome WHERE gildia = '" + name
								+ "'");
				Location h = null;
				if (rs2.next()) {
					String[] u = rs2.getString("loc").split(":");
					h = new Location(Bukkit.getWorld(u[0]), a(u[1]), a(u[2]),
							a(u[3]));
				}
				while (rs1.next()) {
					czlonkowie.add(rs1.getString("nick").toLowerCase());
				}
				boolean j = false;
				for (String cz : czlonkowie) {
					if (cz.equalsIgnoreCase(lider))
						j = true;
				}
				if (j == false)
					czlonkowie.add(lider);
				ResultSet rs12 = MCHard.mysql
						.query("SELECT * FROM sojusze WHERE g0 = '" + name
								+ "'");
				while (rs12.next()) {
					sojusze.add(rs12.getString("g1"));
				}
				Location center = new Location(Bukkit.getWorld(this.world),
						Integer.parseInt(l[0]), Integer.parseInt(l[1]),
						Integer.parseInt(l[2]));

				Location min = new Location(Bukkit.getWorld(this.world),
						center.getBlockX() - size, 0, center.getBlockZ() - size);

				Location max = new Location(Bukkit.getWorld(this.world),
						center.getBlockX() + size, 0, center.getBlockZ() + size);
				
				GuildLocation gloc = new GuildLocation(name, center, min, max);
				ArrayList<Location> furancelist = new ArrayList<Location>();
				ResultSet rs123 = MCHard.mysql
						.query("SELECT * FROM piecyki WHERE gildia = '" + name
								+ "'");
				while (rs123.next()) {
					String[] loc = rs123.getString("loc").split(":");
					int x = Integer.parseInt(loc[0]);
					int y = Integer.parseInt(loc[1]);
					int z = Integer.parseInt(loc[2]);
					furancelist.add(new Location(Bukkit.getWorld(this.world),
							x, y, z));
				}
				Guild guild = new Guild(name, fullname, gloc, lider, zastepca,
						czlonkowie, sojusze, false, furancelist, h);
				guilds.put(name, guild);
				guildlist.add(guild);
			}
			return true;
		} catch (SQLException e) {
			e.printStackTrace();

			return false;
		}

	}
}