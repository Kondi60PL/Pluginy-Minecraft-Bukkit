package pl.digitalix96.mchard.Commands;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Rank;
import pl.digitalix96.mchard.Managers.HPlayerManager;


public class RankingCMD implements CommandExecutor {

	public MCHard plugin;
	public RankingCMD(MCHard instance) {
		this.plugin = instance;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String cmdlabel, String[] args) {
		Player p = (Player) sender;
		
		if(cmd.getName().equalsIgnoreCase("ranking")){
			if(args.length == 1){
				
				new Rank(p).getRankInfo(args[0]);
				return true;
			}
			p.sendMessage(ChatColor.GREEN+"   Ranking - TOP 10");
			new Rank(p).start();
			return true;
		}
		return false;
	}

}
