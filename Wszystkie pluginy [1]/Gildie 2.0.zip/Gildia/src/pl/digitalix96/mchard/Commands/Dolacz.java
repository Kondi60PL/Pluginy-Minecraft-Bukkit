package pl.digitalix96.mchard.Commands;

import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.GuildManager;
import pl.digitalix96.mchard.Managers.HPlayerManager;
import pl.digitalix96.mchard.TagAPI;

public class Dolacz implements CommandExecutor {


	public MCHard plugin;

	public Dolacz(MCHard instance) {
		this.plugin = instance;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd,
			String cmdlabel, String[] args) {
		 Player p = (Player) sender;
		 // PlayerInventory inventory = p.getInventory(); //Ekwipunek gracza
		//    ItemStack itemstack = new ItemStack(Material.DIAMOND, 8); //Stack diament�w
		GuildManager GM = new GuildManager(p.getName());
		if (cmd.getName().equalsIgnoreCase("dolacz")) {
			if (GM.inGuild()) {
				p.sendMessage(MCHard.M.get("niedolacz"));
				return true;
			}
			if (args.length == 1) {
				if(p.getInventory().contains(Material.DIAMOND, 8)){
				List<String> hpi = new HPlayerManager(p.getName()).getHPlayer()
						.getInvites();
				boolean j = false;
				for (String i : hpi) {
					if (i.equalsIgnoreCase(args[0])) {
						j = true;
					}
				
				}
				if (j == true) {
					for (Player p1 : Bukkit.getOnlinePlayers()) {
						TagAPI.refreshPlayer(p1);
					}
					hpi.remove(args[0].toUpperCase());
					GM.getGuild(args[0].toUpperCase()).add(
							p.getName().toLowerCase());
					p.getInventory().removeItem(new ItemStack(Material.DIAMOND, 8));
					Bukkit.broadcastMessage(MCHard.M.get("dodany")
							.replace("%p%", p.getName())
							.replace("%g%", GM.getGuild().getName()));
					return true;
				} else {
					p.sendMessage(MCHard.M.get("niejesteszaproszony"));
					return true;
				}
			} else {

				List<String> hpi = new HPlayerManager(p.getName()).getHPlayer()
						.getInvites();
				if (hpi.size() == 0) {
					p.sendMessage(ChatColor.RED
							+ "Nie jestes zaproszony do zadnej gildi.");
				} else {
					p.sendMessage(ChatColor.GOLD
							+ "  --- Lista zaproszen do gildi ---  ");
					for (String i : hpi) {
						p.sendMessage(ChatColor.YELLOW + " - " + i);
					}
					p.sendMessage(ChatColor.RED
							+ "Jesli chcesz dolaczyc do jeden z gildi musisz miec 8 diamentow :)");
				}
				p.sendMessage(ChatColor.GOLD
						+ "Jesli chcesz dolaczyc do jednej z gildi ktora ci zaprosila wpisz /dolacz nazwa");
			}
			}
			return true;
		}
		return false;
	}

}
