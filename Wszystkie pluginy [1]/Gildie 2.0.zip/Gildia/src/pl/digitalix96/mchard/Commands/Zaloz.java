package pl.digitalix96.mchard.Commands;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.Guild;
import pl.digitalix96.mchard.Managers.GuildLocation;
import pl.digitalix96.mchard.Managers.GuildManager;
import pl.digitalix96.mchard.TagAPI;

public class Zaloz implements CommandExecutor {
	public MCHard plugin;

	public Zaloz(MCHard instance) {
		this.plugin = instance;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd,
			String cmdlabel, String[] args) {
		Player p = (Player) sender;
		GuildManager GM = new GuildManager(p.getName());
		if (cmd.getName().equalsIgnoreCase("zaloz") && GM.canCreate(p)) {
			if (GM.inGuild()) {
				p.sendMessage(MCHard.M.get("niemoznanowej"));
				return true;
			}
			if (!GM.checkItems()) {
				GM.getItemsfromGuild();
				return true;
			} else {
				if (args.length == 2) {
					String name, fullname;
					name = args[0].toUpperCase();
					fullname = args[1];
					if (!(name.length() == 4)) {
						p.sendMessage(MCHard.M.get("zakrutka"));
						return true;
					}
					if (GM.getGuild(name) != null) {
						p.sendMessage(MCHard.M.get("juzistnieje"));
						return true;
					}
					GM.removeItems();
					List<String> l = new ArrayList<String>();
					Location center = p.getLocation();

					Location min = new Location(
							Bukkit.getWorld(MCHard.MCH.world),
							center.getBlockX() - MCHard.MCH.size, 0,
							center.getBlockZ() - MCHard.MCH.size);

					Location max = new Location(
							Bukkit.getWorld(MCHard.MCH.world),
							center.getBlockX() + MCHard.MCH.size, 0,
							center.getBlockZ() + MCHard.MCH.size);

					GuildLocation gloc = new GuildLocation(name, center, min,
							max);
					ArrayList<Location> furancelist = new ArrayList<Location>();
					ArrayList<String> a = new ArrayList<String>();
					Guild guild = new Guild(name, fullname, gloc, p.getName()
							.toLowerCase(), null, l, a, false, furancelist,
							null);
					GM.addGuild(guild);
					new GuildManager(p.getName()).getGuild(name).add(
							p.getName().toLowerCase());
					Bukkit.broadcastMessage(MCHard.M.get("nowagildia")
							.replace("%g%", name).replace("%p%", p.getName()));
					TagAPI.refreshPlayer(p);
					p.getLocation().getBlock().setTypeId(7);
					Location newlo = p.getLocation();
					newlo.setY(p.getLocation().getY() + 2);
					guild.setHomeLocation(newlo);
				} else {
					p.sendMessage("/zaloz NAZWA PelnaNazwa - Nazwa moze zawierac tylko 4 litery!");
				}

			}
			return true;
		} else if (cmd.getName().equalsIgnoreCase("zaloz")
				&& GM.canCreate(p) == false) {
			p.sendMessage(MCHard.M.get("zablisko"));
			p.sendMessage(MCHard.M.get("zablisko1"));
			return true;
		}
		p.sendMessage("error");
		return false;
	}

}