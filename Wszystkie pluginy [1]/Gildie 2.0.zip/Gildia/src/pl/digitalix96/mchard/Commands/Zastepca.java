package pl.digitalix96.mchard.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.GuildManager;
import pl.digitalix96.mchard.TagAPI;

public class Zastepca implements CommandExecutor {

	public MCHard plugin;

	public Zastepca(MCHard instance) {
		this.plugin = instance;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd,
			String cmdlabel, String[] args) {
		Player p = (Player) sender;
		GuildManager GM = new GuildManager(p.getName());
		if (cmd.getName().equalsIgnoreCase("zastepca")) {
			if (GM.inGuild()) {

				if (GM.getGuild().getLider().equalsIgnoreCase(p.getName())) {
					if (args.length == 1) {
						if (GM.inMyGuild(args[0])) {
							for (Player p1 : Bukkit.getOnlinePlayers()) {
								TagAPI.refreshPlayer(p1);
							}
							Bukkit.broadcastMessage(MCHard.M
									.get("nowyzastepca")
									.replace("%p%", args[0])
									.replace("%g%", GM.getGuild().getName()));
							GM.getGuild().setZastepca(args[0].toLowerCase());
						} else {
							p.sendMessage(MCHard.M.get("niemago"));
						}
					} else {
						p.sendMessage(ChatColor.AQUA
								+ "By zmienic zastępce gildi wpisz /zastepca nick");
					}
				} else {
					p.sendMessage(MCHard.M.get("nielider"));
					return true;
				}

				return true;
			} else {
				p.sendMessage(MCHard.M.get("bezgildi"));
				return true;
			}
		}
		return false;
	}

}
