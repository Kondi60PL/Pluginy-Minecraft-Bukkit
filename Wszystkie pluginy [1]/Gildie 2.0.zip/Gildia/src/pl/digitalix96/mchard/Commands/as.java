package pl.digitalix96.mchard.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.GuildManager;

public class as implements CommandExecutor {

	public MCHard plugin;

	public as(MCHard instance) {
		this.plugin = instance;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd,
			String cmdlabel, String[] args) {
		Player p = (Player) sender;
		GuildManager GM = new GuildManager(p.getName());
		if (cmd.getName().equalsIgnoreCase("asojusz")) {
			if (GM.inGuild()) {

				if (GM.getGuild().getLider().equalsIgnoreCase(p.getName())
						|| GM.getGuild().getZastepca()
								.equalsIgnoreCase(p.getName())) {
					if (args.length == 1) {
						if (GM.getGuild().isAllyInvite(args[0])) {
							GM.getGuild(args[0]).addAlly(
									GM.getGuild().getName());
							GM.getGuild().addAlly(args[0]);
							Bukkit.broadcastMessage(MCHard.M.get("sojusz")
									.replace("%g%", GM.getGuild().getName())
									.replace("%g1%", args[0].toUpperCase()));
						} else {
							p.sendMessage(MCHard.M.get("sojusznie"));
						}
					} else {
						p.sendMessage(ChatColor.AQUA
								+ "By akceptowac sojusz wpisz /asojusz nazwa");
					}
				} else {
					p.sendMessage(MCHard.M.get("nielider"));
					return true;
				}

				return true;
			} else {
				p.sendMessage(MCHard.M.get("bezgildi"));
				return true;
			}
		}
		return false;
	}

}
