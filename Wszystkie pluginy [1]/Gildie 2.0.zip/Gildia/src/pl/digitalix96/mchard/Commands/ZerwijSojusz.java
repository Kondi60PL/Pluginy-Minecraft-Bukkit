package pl.digitalix96.mchard.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.GuildManager;

public class ZerwijSojusz implements CommandExecutor {

	public MCHard plugin;

	public ZerwijSojusz(MCHard instance) {
		this.plugin = instance;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd,
			String cmdlabel, String[] args) {
		Player p = (Player) sender;
		GuildManager GM = new GuildManager(p.getName());
		if (cmd.getName().equalsIgnoreCase("zerwijsojusz")) {
			if (GM.inGuild()) {

				if (GM.getGuild().getLider().equalsIgnoreCase(p.getName())
						|| GM.getGuild().getZastepca()
								.equalsIgnoreCase(p.getName())) {
					if (args.length == 1) {
						if (GM.getGuild().isAlly(args[0].toUpperCase()) == true) {

							GM.getGuild().removeAlly(args[0].toUpperCase());
							GM.getGuild(args[0].toUpperCase()).removeAlly(
									GM.getGuild().getName().toUpperCase());
							Bukkit.broadcastMessage(MCHard.M
									.get("koniecsojuszu")
									.replace("%g%", GM.getGuild().getName())
									.replace("%g1%", args[0].toUpperCase()));
						} else {
							p.sendMessage(MCHard.M.get("sojuszniejest"));
						}
					} else {
						p.sendMessage(ChatColor.AQUA
								+ "By zerwac sojusz wpisz /zerwijsojusz nazwa");
					}
				} else {
					p.sendMessage(MCHard.M.get("nielider"));
					return true;
				}

				return true;
			} else {
				p.sendMessage(MCHard.M.get("bezgildi"));
				return true;
			}
		}
		return false;
	}

}
