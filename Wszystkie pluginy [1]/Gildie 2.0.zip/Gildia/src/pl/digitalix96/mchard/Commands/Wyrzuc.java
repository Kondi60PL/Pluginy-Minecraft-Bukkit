package pl.digitalix96.mchard.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.GuildManager;
import pl.digitalix96.mchard.TagAPI;

public class Wyrzuc implements CommandExecutor {

	public MCHard plugin;

	public Wyrzuc(MCHard instance) {
		this.plugin = instance;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd,
			String cmdlabel, String[] args) {
		Player p = (Player) sender;
		GuildManager GM = new GuildManager(p.getName());
		if (cmd.getName().equalsIgnoreCase("wyrzuc")) {
			if (GM.inGuild()) {
				if (GM.getGuild().getLider().equalsIgnoreCase(p.getName())
						|| String.valueOf(GM.getGuild().getZastepca())
								.equalsIgnoreCase(p.getName())) {
					if (args.length == 1) {
						if (GM.inMyGuild(args[0])) {
							boolean hp = false;
							if (Bukkit.getPlayer(args[0].toLowerCase()) != null) {
								hp = true;
							}
							if (hp) {
								for (Player p1 : Bukkit.getOnlinePlayers()) {
									TagAPI.refreshPlayer(p1);
								}
							}
							if (String
									.valueOf(
											new GuildManager(args[0]
													.toLowerCase()).getGuild()
													.getZastepca())
									.toLowerCase()
									.equalsIgnoreCase(args[0].toLowerCase())) {
								new GuildManager(args[0].toLowerCase())
										.getGuild().setZastepca(null);
							}
							if (String
									.valueOf(
											new GuildManager(args[0]
													.toLowerCase()).getGuild()
													.getZastepca())
									.toLowerCase()
									.equalsIgnoreCase(args[0].toLowerCase())) {
								p.sendMessage(MCHard.M.get("lideropusc"));
								return true;
							}
							if (String
									.valueOf(
											new GuildManager(args[0]
													.toLowerCase()).getGuild()
													.getZastepca())
									.toLowerCase()
									.equalsIgnoreCase(
											new GuildManager(args[0]
													.toLowerCase()).getGuild()
													.getLider().toLowerCase())) {
								p.sendMessage(MCHard.M.get("lideropusc"));
								return true;
							}
							TagAPI.refreshPlayer(p);
							Bukkit.broadcastMessage(MCHard.M.get("wyrzucony")
									.replace("%p%", args[0])
									.replace("%g%", GM.getGuild().getName()));
							GM.getGuild().remove(args[0].toLowerCase());

						} else {
							p.sendMessage(MCHard.M.get("niemago"));
						}
					} else {
						p.sendMessage(ChatColor.AQUA
								+ "By wyrzucic gracza z gildi wpisz /wyrzuc nick");
					}
				} else {
					p.sendMessage(MCHard.M.get("nielider"));
					return true;
				}
				return true;
			} else {
				p.sendMessage(MCHard.M.get("bezgildi"));
				return true;
			}
		}
		return false;
	}

}
