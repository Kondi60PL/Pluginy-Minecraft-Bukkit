package pl.digitalix96.mchard.Commands;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.Guild;
import pl.digitalix96.mchard.Managers.GuildManager;

public class Gildie implements CommandExecutor {
	public MCHard plugin;

	public Gildie(MCHard instance) {
		this.plugin = instance;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd,
			String cmdlabel, String[] args) {
		Player p = (Player) sender;
		GuildManager GM = new GuildManager(p.getName());
		if (cmd.getName().equalsIgnoreCase("lista")) {
			p.sendMessage(ChatColor.GREEN + "Lista gildi:");
			final long start1 = System.currentTimeMillis();
			for (Guild g : GM.getGuildList()) {
				p.sendMessage(ChatColor.GREEN + " # "+ g.getFullName() + " �e[�3"+ (g.getName()) +"�e]�2"
						+ " Lider: " + g.getLider() + " (Punkty: "+ ChatColor.RED + g.getPoints()+"�2)");
			}
			final long end1 = System.currentTimeMillis();
			MCHard.console.sendMessage(ChatColor.AQUA + "Wykonano w "
					+ (end1 - start1) + "ms");
			return true;
		}
		return false;
	}

}
