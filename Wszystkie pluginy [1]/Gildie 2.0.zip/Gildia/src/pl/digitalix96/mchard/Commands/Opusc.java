package pl.digitalix96.mchard.Commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.GuildManager;
import pl.digitalix96.mchard.TagAPI;

public class Opusc implements CommandExecutor {

	public MCHard plugin;

	public Opusc(MCHard instance) {
		this.plugin = instance;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd,
			String cmdlabel, String[] args) {
		Player p = (Player) sender;
		GuildManager GM = new GuildManager(p.getName());
		if (cmd.getName().equalsIgnoreCase("opusc")) {
			if (GM.inGuild()) {

				if (GM.getGuild().getLider().equalsIgnoreCase(p.getName())) {
					p.sendMessage(MCHard.M.get("lideropusc"));
					return true;
				}
				if (String.valueOf(GM.getGuild().getZastepca())
						.equalsIgnoreCase(p.getName())) {
					GM.getGuild().setZastepca(null);

				}
				for (Player p1 : Bukkit.getOnlinePlayers()) {
					TagAPI.refreshPlayer(p1);
				}
				Bukkit.broadcastMessage(MCHard.M.get("opuscil")
						.replace("%p%", p.getName())
						.replace("%g%", GM.getGuild().getName()));
				GM.getGuild().remove(p.getName().toLowerCase());
				return true;
			} else {
				p.sendMessage(MCHard.M.get("bezgildi"));
				return true;
			}
		}
		return false;
	}

}
