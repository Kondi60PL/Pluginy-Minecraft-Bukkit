package pl.digitalix96.mchard.Commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.Guild;
import pl.digitalix96.mchard.Managers.GuildManager;
import pl.digitalix96.mchard.Managers.HPlayer;
import pl.digitalix96.mchard.Managers.HPlayerManager;
import pl.digitalix96.mchard.TagAPI;

public class Dodaj implements CommandExecutor {
	public MCHard plugin;

	public Dodaj(MCHard instance) {
		this.plugin = instance;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd,
			String cmdlabel, String[] args) {
		Player p = (Player) sender;
		GuildManager GM = new GuildManager(p.getName());
		if (cmd.getName().equalsIgnoreCase("dodaj")) {

			if (GM.inGuild() == false) {
				p.sendMessage(MCHard.M.get("bezgildi"));
				return true;
			}
			Guild guild = GM.getGuild();
			String zastepca = String.valueOf(guild.getZastepca());

			if (guild.getLider().equalsIgnoreCase(p.getName())
					|| zastepca.equalsIgnoreCase(p.getName())) {
			} else {

				p.sendMessage(MCHard.M.get("nielider"));
				return true;
			}
			if (args.length == 1) {
				GuildManager GM1 = new GuildManager(args[0]);
				if (GM1.inGuild()) {
					p.sendMessage(MCHard.M.get("niezaproszony").replace("%p%",
							args[0]));
					return true;
				}
				HPlayerManager hpm = new HPlayerManager(args[0]);
				HPlayer hp = hpm.getHPlayer();
				hp.addInvite(guild.getName());
				p.sendMessage(MCHard.M.get("zaproszenie").replace("%p%",
						args[0]));
				TagAPI.refreshPlayer(p);
				if (Bukkit.getServer().getPlayer(hp.getName()) != null) {
					Player pl = Bukkit.getServer().getPlayer(hp.getName());
					pl.sendMessage(MCHard.M.get("infozaproszenie").replace(
							"%g%", guild.getName()));
					for (Player p1 : Bukkit.getOnlinePlayers()) {
						TagAPI.refreshPlayer(p1);
					}
				}
				return true;
			} else {
				p.sendMessage(MCHard.M.get("bydodac"));
				return true;
			}

		}
		return false;
	}

}
