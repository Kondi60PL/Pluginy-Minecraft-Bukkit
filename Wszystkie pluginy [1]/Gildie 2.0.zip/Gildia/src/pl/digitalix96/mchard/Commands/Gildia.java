package pl.digitalix96.mchard.Commands;
 
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
 





import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
 





import pl.digitalix96.mchard.MCH;
import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Message;
import pl.digitalix96.mchard.Managers.Guild;
import pl.digitalix96.mchard.Managers.GuildManager;
import pl.digitalix96.mchard.Managers.HPlayer;
import pl.digitalix96.mchard.TagAPI;
 
public class Gildia implements CommandExecutor {
        public MCHard plugin;
 
        public Gildia(MCHard instance) {
                this.plugin = instance;
        }
        Object localObject;
        @Override
        public boolean onCommand(CommandSender sender, Command cmd,
                        String cmdlabel, final String[] args) {
        	 
        	 
                final Player p = (Player) sender;
                final GuildManager GM = new GuildManager(p.getName());
                //if(cmd.getName().equalsIgnoreCase("cobbel")){
                // HPlayer hp = MCH.HPlayers.get(sender.getName().toLowerCase());
                // if(hp.cobbel == true){
                //     p.sendMessage(ChatColor.GREEN+"Drop cobbla został wyłączony.");
                //     hp.cobbel = false;
               //  }else{
                //      p.sendMessage(ChatColor.GREEN+"Drop cobbla został włączony.");
                 //     hp.cobbel = true;
                // }
             //}

        		if(cmd.getName().equalsIgnoreCase("gczat")&& GM.inGuild()) {
               	 if (args.length == 0){
            		 sender.sendMessage(ChatColor.RED +"Nie wybrales wiadomosci do wyslania , wpisz /gczat WIADOMOSC");
               	 }
               	 if(args.length>=1){
      			  GuildManager gm = new GuildManager(p.getPlayer().getName());
      			  if(!gm.inGuild()){p.getPlayer().sendMessage(MCHard.M.get("chat@"));return false;}
      			  if(gm.getGuild()==null){return false;}
      			  Guild g = gm.getGuild();
      			  List<String> l = g.getPlayers();
	                StringBuilder StringBuilder = new StringBuilder();
	                for (int i = 0; i < args.length; ++i)
	                  StringBuilder.append(args[i]).append(" ");

	                String msg = StringBuilder.toString().trim();
      			  for(String ps: l){
      				  if(Bukkit.getServer().getPlayer(ps) != null){
      					  Player pl = Bukkit.getServer().getPlayer(ps);
      					  pl.sendMessage(ChatColor.GREEN+"["+gm.getGuild().getName()+"] "+p.getPlayer().getName()+": "+msg);
      					  
      				  }
      			  }
      			  
      			  }
        			
        		}
        		//if(cmd.getName().equalsIgnoreCase("gsoj")&& GM.inGuild()) {
        		//    List<String> l;
        	//	    List<String> ally;
             //     	 if (args.length == 0){
            //   		 sender.sendMessage(ChatColor.RED +"Nie wybrales wiadomosci do wyslania , wpisz /gsoj WIADOMOSC");
            //      	 }
            //      	 if(args.length>=1){
                  	    
            //      	      GuildManager gm = new GuildManager(sender.getName());
            //      	      if (!gm.inGuild())
            //      	      {
           //       	        sender.sendMessage(MCHard.M.get("chat@"));return false;
           //       	      }
           //       	    StringBuilder StringBuilder = new StringBuilder();
    	   //             for (int i = 0; i < args.length; ++i)
    	      //            StringBuilder.append(args[i]).append(" ");

    	     //           String msg = StringBuilder.toString().trim();
            //      	      Guild g = gm.getGuild();
           //       	      l = g.getPlayers();
           //       	        ally = g.getAllyList();
         //         	        //Guild abc = gm.getGuild(ally);
           //       	        List<String> l1 = abc.getPlayers();
          //        	      for(String ps: l){
           //   				  if(Bukkit.getServer().getPlayer(ps) != null){
            //  					  Player pl = Bukkit.getServer().getPlayer(ps);
            //  					  pl.sendMessage(ChatColor.GREEN+"["+gm.getGuild().getName()+"] "+p.getPlayer().getName()+": "+msg);
            //  				  }
            //      	      }
           //       	    }
                //  	 }
      	
        		
        		if(cmd.getName().equalsIgnoreCase("gbaza")&& GM.inGuild()) {
    				        final Location l1 = p.getLocation();
    				        p.sendMessage("�4Nie ruszaj sie ! Teleportacja trwa");
    		    	        new Thread(){
  		    	        	  public void run(){
  		    	        		  try {
  									Thread.sleep(10000);
  								} catch (InterruptedException e) {
  									// TODO Auto-generated catch block
  									e.printStackTrace();
  								}
  		                        Location l2 = p.getLocation();
  		                        if(l1.getX() == l2.getX() && l1.getY() == l2.getY() &&l1.getZ() == l2.getZ()){
          					Location gl = new GuildManager(p.getName()).getGuild().getLocation().getCenterLocation();
          					p.teleport(gl);
  		                        	  p.sendMessage("�4Teleportacja udana !");
  		                        }else{
  		                        	p.sendMessage("�4Teleportacja nie udana !");
  		                        }
  		    	        	  }
  		    	        	  
  		    	        	  
  		    	         }.start();;
  		    	         
        				
        		}
                if (cmd.getName().equalsIgnoreCase("gildia") && GM.inGuild()) {
                        if (MCHard.tag)
                                TagAPI.refreshPlayer(p);
                        sender.sendMessage(ChatColor.GREEN
                                        + "---------------------------------------------------");
                        sender.sendMessage(ChatColor.GOLD + "" + ChatColor.BOLD
                                        + "         Gildia [" + GM.getGuild().getName() + "]");
                        sender.sendMessage(ChatColor.GREEN + " ");
                        sender.sendMessage(ChatColor.GOLD
                                        + "   Polozenie: [x: "
                                        + GM.getGuild().getLocation().getCenterLocation()
                                                        .getBlockX()
                                        + ", z: "
                                        + GM.getGuild().getLocation().getCenterLocation()
                                                        .getBlockZ() + "]");
                        sender.sendMessage(ChatColor.GOLD + "   Punkty: "+GM.getGuild().getPoints());
                        sender.sendMessage(ChatColor.GOLD + "   Lider: "
                                        + GM.getGuild().getLider());
                        sender.sendMessage(ChatColor.GOLD
                                        + "   Zastepca Lidera: "
                                        + String.valueOf(GM.getGuild().getZastepca()).replace(
                                                        "null", "(Brak Zastepcy)"));
                        sender.sendMessage(ChatColor.GOLD + "   Czlonkowie: "
                                        + GM.getGuild().getPlayers());
                        List<String> gg = new ArrayList<String>();
                        try {
                                for (String g : GM.getGuild().getAllyList()) {
                                        gg.add(g);
                                }
                        } catch (Exception e) {
                        }
                        sender.sendMessage(ChatColor.GOLD + "   Sojusz: "
                                        + String.valueOf(gg).replace("null", "Brak sojuszy"));
                        sender.sendMessage(ChatColor.GREEN + " ");
                        sender.sendMessage(ChatColor.GREEN
                                        + "---------------------------------------------------");
                        return true;
                		
    
                } else if (cmd.getName().equalsIgnoreCase("gildia") && GM.inGuild() == false) {
                        p.sendMessage(new Message().get("bezgildi"));
                        return true;
                }

                return false;
        }
 
        }

        