package pl.digitalix96.mchard.Commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.GuildManager;
import pl.digitalix96.mchard.TagAPI;

public class Zamknij implements CommandExecutor {

	public MCHard plugin;

	public Zamknij(MCHard instance) {
		this.plugin = instance;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd,
			String cmdlabel, String[] args) {
		Player p = (Player) sender;
		GuildManager GM = new GuildManager(p.getName());
		if (cmd.getName().equalsIgnoreCase("zamknij")) {
			if (GM.inGuild()) {
				if (GM.getGuild().getLider().equalsIgnoreCase(p.getName())) {
					TagAPI.refreshPlayer(p);
					Bukkit.broadcastMessage(MCHard.M.get("zamknij").replace(
							"%g%", GM.getGuild().getName()));
					GM.removeGuild(GM.getGuild());
				} else {
					p.sendMessage(MCHard.M.get("nielider"));
					return true;
				}
				return true;
			} else {
				p.sendMessage(MCHard.M.get("bezgildi"));
				return true;
			}
		}
		return false;
	}

}
