package pl.digitalix96.mchard.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.GuildManager;

public class Sojusz implements CommandExecutor {

	public MCHard plugin;

	public Sojusz(MCHard instance) {
		this.plugin = instance;
	}

	@Override
	public boolean onCommand(CommandSender sender, Command cmd,
			String cmdlabel, String[] args) {
		Player p = (Player) sender;
		GuildManager GM = new GuildManager(p.getName());
		if (cmd.getName().equalsIgnoreCase("sojusz")) {
			if (GM.inGuild()) {

				if (GM.getGuild().getLider().equalsIgnoreCase(p.getName())
						|| String.valueOf(GM.getGuild().getZastepca())
								.equalsIgnoreCase(p.getName())) {
					if (args.length == 1) {
						if (GM.getGuild().isAlly(args[0]) == false) {

							if (GM.getGuild(args[0]) != null) {
								GM.getGuild(args[0]).addAllyInvite(
										GM.getGuild().getName());
								String lider = GM.getGuild(args[0]).getLider();
								boolean hp = false;
								if (Bukkit.getPlayer(lider) != null) {
									hp = true;
								}

								if (hp) {
									Bukkit.getPlayer(lider).sendMessage(
											MCHard.M.get("sojuszzap").replace(
													"%g%",
													GM.getGuild().getName()));
								}
							} else {
								p.sendMessage(MCHard.M.get("niematakiej")
										.replace("%g%", args[0].toUpperCase()));
							}
						} else {
							p.sendMessage(MCHard.M.get("sojuszjest").replace(
									"%g%", args[0].toUpperCase()));
						}
					} else {
						p.sendMessage(ChatColor.AQUA
								+ "By zaproscic gildie do sojuszu wpisz /sojusz nazwa");
					}
				} else {
					p.sendMessage(MCHard.M.get("nielider"));
					return true;
				}

				return true;
			} else {
				p.sendMessage(MCHard.M.get("bezgildi"));
				return true;
			}
		}
		return false;
	}

}
