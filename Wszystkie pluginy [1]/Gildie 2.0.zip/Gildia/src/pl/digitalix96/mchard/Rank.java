package pl.digitalix96.mchard;

import java.util.Collections;
import java.util.LinkedList;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import pl.digitalix96.mchard.Managers.Guild;
import pl.digitalix96.mchard.Managers.GuildComparator;

import pl.digitalix96.mchard.Managers.HPlayerManager;
import pl.digitalix96.mchard.Managers.Ranking;
import pl.digitalix96.mchard.Managers.RankingManager;

public class Rank extends Thread{
	public Player player;
	public Rank(Player p){
		this.player = p;
	}

    public Rank() {
    }
        
	public Integer max = 0;
	public Integer m = 0;
	public void getRankInfo(String p){
		final long start1 = System.currentTimeMillis();
		Collections.sort(MCH.ranks,new RankingManager());
		if(MCH.rankings.get(p.toLowerCase()) == null){this.player.sendMessage("Niema takiego gracza.");}
	     for(Ranking rank:MCH.ranks){
	    	 int num = m++;
	    	 
	    	 if(p.equalsIgnoreCase(rank.getName())){
	    		 int r = rank.getPoints();
	    		 this.player.sendMessage(ChatColor.GREEN+"Gracz "+ChatColor.WHITE+p+ChatColor.GREEN+" ma "+r+" Punktow i jest na miejscu "+((int)num+1)+".");
	    	 }
	    		
	    	 
	     }
	     final long end1 = System.currentTimeMillis();
	}
        public String getRankInfo2(String p){
		final long start1 = System.currentTimeMillis();
		Collections.sort(MCH.ranks,new RankingManager());
                String mm = "";
		if(MCH.rankings.get(p.toLowerCase()) == null){this.player.sendMessage("Niema takiego gracza.");}
	     for(Ranking rank:MCH.ranks){
	    	 int num = m++;
	    	 if(p.equalsIgnoreCase(rank.getName())){
	    		 int r = rank.getPoints();
                         mm = String.valueOf(((int)num+1));
	    		 //this.player.sendMessage(ChatColor.GREEN+"Gracz "+ChatColor.WHITE+p+ChatColor.GREEN+" ma "+r+" Punktow i jest na miejscu "+((int)num+1)+".");
	    	 }
	    		
	    	 
	     }
	     final long end1 = System.currentTimeMillis();
                        
                return mm;
	}
        public static LinkedList<String> getRankTop(){
            LinkedList<String> list = new LinkedList();
            Collections.sort(MCH.ranks,new RankingManager());
            int maxx = 0;
	     for(Ranking r:MCH.ranks){
	    	 if(maxx >= 15)break;
	    	 maxx++;
	    	 list.add(Bukkit.getOfflinePlayer(r.getName()).getName());
	     }
            
            return list;
        }
        public static LinkedList<String> getGuildRankTop(){
            LinkedList<String> list = new LinkedList();
            Collections.sort(MCHard.MCH.guildlist,new GuildComparator());
            int maxx = 0;
	     for(Guild g:MCHard.MCH.guildlist){
	    	 if(maxx >= 15)break;
	    	 maxx++;
	    	 list.add(g.getName());
	     }
            
            return list;
        }
        public static int getGuildRankInfo(Guild guild){
            Collections.sort(MCHard.MCH.guildlist,new GuildComparator());
            int num = 1;
	     for(Guild g:MCHard.MCH.guildlist){
	    	 if(g==guild)break;
                 num = num + 1; 
             }
            
            return num;
        }
	public void run(){
		
		Collections.sort(MCH.ranks,new RankingManager());
	     for(Ranking r:MCH.ranks){
	    	 if(max >= 10)return;
	    	 max++;
	    	 this.player.sendMessage(" "+max + ". "+Bukkit.getOfflinePlayer(r.getName()).getName()+" "+ r.getPoints());
	     }
	     
	}
	
}