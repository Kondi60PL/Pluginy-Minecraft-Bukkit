package pl.digitalix96.mchard;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Date;

public class Crash {
	
	private Exception e;
	
	public Crash(Exception e){
		this.e = e;
	}
	
	public void show(){
		
	}
	
	public void save(){
		Date d = new Date();
		File plik = new File("MCHard/Error-"+d.toString()+".txt");
		try {
			PrintWriter zapis = new PrintWriter(plik);
			zapis.println("Problem Gildie ! - "+d.toString());
			zapis.println("");
			zapis.println("---------------------------------------------------------");
			zapis.println(e.getLocalizedMessage());
			zapis.println("---------------------------------------------------------");
			zapis.println(e.getMessage());
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
