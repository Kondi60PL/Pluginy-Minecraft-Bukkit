
package pl.digitalix96.mchard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import net.minecraft.server.v1_7_R1.PacketPlayOutScoreboardTeam;
import net.minecraft.server.v1_7_R1.ScoreboardTeam;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.craftbukkit.v1_7_R1.entity.CraftPlayer;
import org.bukkit.entity.Player;

import pl.digitalix96.mchard.Managers.Guild;
import pl.digitalix96.mchard.Managers.GuildManager;

public class TagAPI {
    
    public static Object lock = new Object();
    //public static HashMap<Player,String> playersTag = new HashMap();
    public static void refreshPlayer(Player p){
        synchronized(lock){
            try{

                GuildManager GM = new GuildManager(p.getName());
                Guild guild = GM.getGuild();
                for(Player player : Bukkit.getOnlinePlayers()){
                    try{
                    GuildManager GMOther = new GuildManager(player.getName());
                    Guild go = GMOther.getGuild();
                    ScoreboardTeam team = MCH.board.getPlayerTeam(Bukkit.getPlayer(player.getName()).getName());
                    boolean g = false;
                    String pre = null;
                   
                   
                    
                    if(team==null)continue;
                    
                   // if(p.getPlayer().getName().equalsIgnoreCase("Hunterss")){
                    //	team.setPrefix(ChatColor.RED + "["+ChatColor.GREEN + "DEV"+ChatColor.RED+"] "+ChatColor.GREEN);
                    	//PacketPlayOutScoreboardTeam packet = new PacketPlayOutScoreboardTeam(team,2);
                    //	((CraftPlayer) p).getHandle().playerConnection.sendPacket(packet);
      			//  }

                    
                        if(GMOther.inGuild()){
                            boolean ally = false;
                            
                          
                            if(GM.inGuild())
                                for(String al : guild.getAllyList())
                                    if(al.equalsIgnoreCase(go.getName()))ally = true;
                            
                            if(guild == go && (go!=null||guild!=null)){//gildia
                                team.setPrefix(ChatColor.GRAY + "["+ChatColor.GREEN +go.getName()+ChatColor.GRAY+"] "+ChatColor.GREEN);
                                PacketPlayOutScoreboardTeam packet = new PacketPlayOutScoreboardTeam(team,2);

                                ((CraftPlayer) p).getHandle().playerConnection.sendPacket(packet);
                            }else if(go!=null&&ally==false){//gildia
                                team.setPrefix(ChatColor.GRAY + "["+ChatColor.RED +go.getName()+ChatColor.GRAY+"] "+ChatColor.RED);
                                PacketPlayOutScoreboardTeam packet = new PacketPlayOutScoreboardTeam(team,2);


                                ((CraftPlayer) p).getHandle().playerConnection.sendPacket(packet);
                            }else if(guild != go && (go!=null||guild!=null)){

                                if(ally){//sojusz
                                    team.setPrefix(ChatColor.GRAY + "["+ChatColor.YELLOW +go.getName()+ChatColor.GRAY+"] "+ChatColor.YELLOW);
                                    PacketPlayOutScoreboardTeam packet = new PacketPlayOutScoreboardTeam(team,2);


                                    ((CraftPlayer) p).getHandle().playerConnection.sendPacket(packet);
                                }else{//wrog

                                    team.setPrefix(ChatColor.GRAY + "["+ChatColor.RED +go.getName()+ChatColor.GRAY+"] "+ChatColor.RED);
                                    PacketPlayOutScoreboardTeam packet = new PacketPlayOutScoreboardTeam(team,2);



                                    ((CraftPlayer) p).getHandle().playerConnection.sendPacket(packet);

                                }

                            } 


                        }else if(!GMOther.inGuild()){
                            team.setPrefix(ChatColor.GRAY+"");
                            PacketPlayOutScoreboardTeam packet = new PacketPlayOutScoreboardTeam(team,2);



                                    ((CraftPlayer) p).getHandle().playerConnection.sendPacket(packet);

                        }else if(!GM.inGuild()){
                            team.setPrefix(ChatColor.AQUA+"");
                            PacketPlayOutScoreboardTeam packet = new PacketPlayOutScoreboardTeam(team,2);


                                    ((CraftPlayer) p).getHandle().playerConnection.sendPacket(packet);

                        }
                }catch(Exception e){
                    MCHard.console.sendMessage(ChatColor.RED+"Wystąpił problem w odswiezeniu Taga dla gracza "+player.getName()+"!");
                    e.printStackTrace();

                }
                }

            }catch(Exception e){e.printStackTrace();}
    }
}
    
}
