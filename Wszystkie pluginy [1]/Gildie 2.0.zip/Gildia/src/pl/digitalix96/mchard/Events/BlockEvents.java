package pl.digitalix96.mchard.Events;

import java.util.Map;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Biome;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.MCHard.TMySQL;
import pl.digitalix96.mchard.Managers.Guild;
import pl.digitalix96.mchard.Managers.GuildManager;
import pl.digitalix96.mchard.MCH;
import pl.digitalix96.mchard.Managers.GPlayer;
import pl.digitalix96.mchard.Managers.HPlayer;
import pl.digitalix96.mchard.Events.CommandsEvent;

public class BlockEvents implements Listener {
	  private int random = -1;
	  private int random1 = -1;
	  private int ldrop = 0;

	@EventHandler(priority=EventPriority.HIGH)
	public void onPlace(BlockPlaceEvent e){
		//final long start = System.currentTimeMillis();
		Player p = e.getPlayer();
		//if(p.isOp())return;
		GuildManager GM = new GuildManager(p.getName());
		boolean mozna = true;
		
		for(Guild g:GM.getGuildList()){
			if(g.isInZone(p.getName().toLowerCase(), e.getBlockPlaced().getLocation())){
				mozna=false;
				
			}
		}
		if(mozna==false){
			e.setCancelled(true);
		}else{
			
			if(GM.inGuild()){
				if(GM.getGuild().isCubZone(e.getBlockPlaced().getLocation())){
			if(GM.getGuild().PlayerIsInGuild(p.getName())){
				//System.out.print("true - jest gildia");
			if(GM.getGuild().isBattle()){
				//System.out.print("true - jest walka"+GM.getGuild().getBattleTime());
				e.setCancelled(true);
				return;
			}
			}}}
			if(e.getBlockPlaced().getType() == Material.FURNACE && GM.inGuild()){
				Guild g = GM.getGuild();
				g.runFuranceChecker();
				if(g.getFurances().size() >= 10 && e.getBlockPlaced().getType() == Material.FURNACE && g.isCubZone(e.getBlockPlaced().getLocation())){
					
					e.getPlayer().sendMessage(ChatColor.RED+"Na cuboidzie gildi mo�na postawi� maxymalnie 10 piecyk�w!");
					e.setCancelled(true);
					return;
				}
				if(e.getBlockPlaced().getType() == Material.FURNACE && g.isCubZone(e.getBlockPlaced().getLocation())){
				g.getFurances().add(e.getBlockPlaced().getLocation());
				int x = e.getBlockPlaced().getLocation().getBlockX();
				int y = e.getBlockPlaced().getLocation().getBlockY();
				int z = e.getBlockPlaced().getLocation().getBlockZ();
				new TMySQL("INSERT INTO piecyki (`gildia`, `loc`) VALUES ('" + g.getName().toUpperCase() + "', '"+x+":"+y+":"+z+"')").send();
				e.getPlayer().sendMessage(g.getFurances().size()+" "+g.getName());
				}
			}
		}
		//final long end = System.currentTimeMillis();
		//MCHard.D.send(e.getEventName()+" wykonano w "+(end-start)+"ms.");
	}
	@EventHandler
	public void bucket(PlayerBucketEmptyEvent e){
		Player p = e.getPlayer();
		//if(p.isOp())return;
		GuildManager GM = new GuildManager(p.getName());
		Location ploc = p.getLocation();
		boolean mozna = true;
		for(Guild g:GM.getGuildList()){
			if(g.isInZone(p.getName().toLowerCase(), e.getBlockClicked().getLocation())){
				mozna=false;
			}
		}
		if(mozna==false){e.setCancelled(true);}
	}
	@EventHandler
	public void bucket(PlayerBucketFillEvent e){
		Player p = e.getPlayer();
		//if(p.isOp())return;
		GuildManager GM = new GuildManager(p.getName());
		Location ploc = p.getLocation();
		boolean mozna = true;
		for(Guild g:GM.getGuildList()){
			if(g.isInZone(p.getName().toLowerCase(), e.getBlockClicked().getLocation())){
				mozna=false;
			}
		}
		if(mozna==false){e.setCancelled(true);}
	}
	@SuppressWarnings("rawtypes")
	@EventHandler(priority=EventPriority.HIGH)
	  public void onBlockBreak(BlockBreakEvent event)
	  {
		if(event.isCancelled() == true)return;
		final long start = System.currentTimeMillis();
		if (event.isCancelled()) return;
	    Block brokenBlock = event.getBlock();
	    Player player = event.getPlayer();
	   // HPlayer hp = MCH.HPlayers.get(player.getName().toLowerCase());
	    Player p = player;
	    //if(p.isOp())return;
		GuildManager GM = new GuildManager(p.getName());
		Guild gg = null;
		Location ploc = p.getLocation();
		boolean mozna = true;
		for(Guild g:GM.getGuildList()){
			if(g.isInZone(p.getName().toLowerCase(), event.getBlock().getLocation())){
				mozna=false;
				gg=g;
			}
		}
    	//if(hp.cobbel){
       //     brokenBlock.breakNaturally(new ItemStack(Material.COBBLESTONE, 1));
       //         }
       // 	brokenBlock.getWorld().dropItemNaturally(brokenBlock.getLocation(), new ItemStack(Material.IRON_ORE, 1));
//
       // 	set(brokenBlock, event, player);
		if(mozna==false){event.setCancelled(true);return;}else{
			if(event.getBlock().getType() != Material.FURNACE || GM.inGuild() == false){}else{
			if(GM.getGuild().isCubZone(event.getBlock().getLocation())){
			GM.getGuild().
			getFurances()
			.remove(event.getBlock().getLocation());
			int x = event.getBlock().getLocation().getBlockX();
			int y = event.getBlock().getLocation().getBlockY();
			int z = event.getBlock().getLocation().getBlockZ();
			new TMySQL("DELETE FROM `piecyki` WHERE `loc` = '"+x+":"+y+":"+z+"'").send();
			event.getPlayer().sendMessage(GM.getGuild().getFurances().size()+" "+GM.getGuild().getName());
			}}
			
		}
		if(gg!=null&&gg.isCubZone(event.getBlock().getLocation()))return;

		if(MCHard.st==MCHard.ServerType.MCPack)return;
	    if (player != null)
	  
	              if(brokenBlock.getTypeId() == 1){
	    		p.giveExp(2);
	              }	
	          
	            
	  }
	@EventHandler
	public void move(PlayerMoveEvent e) {
		if (MCHard.move_info) {
			//
			final Player p = e.getPlayer();
			final GuildManager gm = new GuildManager(p.getName().toLowerCase());
			boolean mozna = true;
			Guild gu = null;
			GPlayer gp = MCH.pzone.get(p);
			try {
				for (Guild magic : gm.getGuildList()) {
					if (magic.isInZone(p.getName().toLowerCase(),
							p.getLocation())) {
						gu = magic;
						mozna = false;

					}
				}

				if (mozna == false && gp.isIntruz() == false && gp.getG() != gu) {
					gp.setIntruz(true);
					gp.setG(gu);
					p.sendMessage(ChatColor.RED
							+ "Uwaga jestes na terytorium gildi "
							+ gu.getName() + "!");
					for (String pp : gu.getPlayers()) {
						if (Bukkit.getPlayer(pp) != null) {
							Bukkit.getPlayer(pp)
									.sendMessage(
											ChatColor.RED
													+ "Uwaga intruz na terytorium gildi!");
						}
					}

				} else if (mozna == true && gp.isIntruz() == true) {
					gp.setIntruz(false);
					p.sendMessage(ChatColor.GREEN
							+ "Jestes ju� po za terytorium gildi "
							+ gp.getG().getName() + ".");
					for (String pp : gp.getG().getPlayers()) {
						if (Bukkit.getPlayer(pp) != null) {
							Bukkit.getPlayer(pp)
									.sendMessage(
											ChatColor.GREEN
													+ "Intruz jest ju� po za terytorium gildi.");
						}
					}
					gp.setG(null);
				}
			}

					// wyszedl po za terytirium
				 catch (Exception ex) {

				}
		}
	}
			
		
	

		
			
	  
	  private void set(Block set, BlockBreakEvent event,Player player) {

	  	
		  event.setCancelled(true);
	  	set.setTypeId(0);
	  	set.breakNaturally(player.getItemInHand());
	  	
	  	
	}
	  
	
}
