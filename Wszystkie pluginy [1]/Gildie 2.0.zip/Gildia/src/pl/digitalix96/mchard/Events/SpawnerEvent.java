package pl.digitalix96.mchard.Events;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;

import pl.digitalix96.mchard.MCHard;

public class SpawnerEvent implements Listener {

	@EventHandler
	public void onCreatureSpawn(CreatureSpawnEvent event) {
		if (MCHard.st == MCHard.ServerType.MCPack)
			return;
		if (!(event.getSpawnReason() == CreatureSpawnEvent.SpawnReason.SPAWNER))
			return;

		Location location = event.getEntity().getLocation();
		World world = event.getLocation().getWorld();

		for (int x = location.getBlockX() - 8; x <= location.getBlockX() + 8; x++) {
			for (int z = location.getBlockZ() - 8; z <= location.getBlockZ() + 8; z++) {
				for (int y = location.getBlockY() - 3; y <= location
						.getBlockY() + 3; y++) {

					if (world.getBlockTypeIdAt(x, y, z) == 52) {

						Bukkit.getWorld(
								event.getEntity().getLocation().getWorld()
										.getName())
								.getBlockAt(new Location(world, x, y, z))
								.setTypeId(89);
					}
				}
			}
		}

	}

}