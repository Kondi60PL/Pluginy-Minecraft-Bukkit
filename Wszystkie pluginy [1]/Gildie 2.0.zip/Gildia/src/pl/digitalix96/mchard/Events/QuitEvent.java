package pl.digitalix96.mchard.Events;

import net.minecraft.server.v1_7_R1.PacketPlayOutScoreboardTeam;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_7_R1.entity.CraftPlayer;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Minecart;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import pl.digitalix96.mchard.MCH;
import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.GPlayer;
import pl.digitalix96.mchard.Managers.HPlayer;
import pl.digitalix96.mchard.Managers.HPlayerManager;
import pl.digitalix96.mchard.Managers.Ranking;
import pl.digitalix96.mchard.TagAPI;

public class QuitEvent implements Listener {

	@EventHandler
	public void add(PlayerJoinEvent e) {
                Player p = e.getPlayer();
		MCH.pzone.put(e.getPlayer(), new GPlayer(e.getPlayer()));
                HPlayer hp = new HPlayer(e.getPlayer().getName().toLowerCase());
		MCHard.MCH.hpm.put(e.getPlayer().getName().toLowerCase(), hp);
                if(MCH.rankings.get(e.getPlayer().getName().toLowerCase())==null){
                    Ranking r = new Ranking(e.getPlayer().getName().toLowerCase(), 1000, 0, 0);
                    MCH.rankings.put(e.getPlayer().getName().toLowerCase(), r);
                    MCH.ranks.add(r);
                    new MCHard.TMySQL("INSERT INTO statystyki (`nick`, `punkty`,`zabojstwa`,`smierci`) VALUES ('" + e.getPlayer().getName().toLowerCase() + "', '1000', '0', '0')").send();
                }
                        hp.updatePrefix();
                        TagAPI.refreshPlayer(p);
	}
	  @EventHandler
	   public void onEntityDeath(EntityDeathEvent e)
	   {
	   if(e.getEntity() instanceof Player){
	    Player p = (Player) e.getEntity();
	    HPlayerManager hpm = new HPlayerManager(p.getName());
	    HPlayer hp = hpm.getHPlayer();
	    if(!(e.getEntity().getKiller() instanceof Player))return;
	    
	    Player k = p.getKiller();
	    HPlayerManager hpm1 = new HPlayerManager(p.getKiller().getName());
	    HPlayer hp1 = hpm1.getHPlayer();
	                                
	    String[] info = hpm.updateRanking(hp.getName(), hp1.getName()).split(":");
	    Bukkit.broadcastMessage(ChatColor.RED+"Gracz "+ChatColor.GOLD+hp1.getName()+"(+"+(int)Double.parseDouble(info[0])+")"+ChatColor.RED+" zabil gracza "+ChatColor.GOLD+p.getName()+"(-"+(int)Double.parseDouble(info[1])+")"+ChatColor.RED+".");
	   
	   }

	   }

	@EventHandler
	public void rem(PlayerQuitEvent event) {

		Player p = event.getPlayer();
		MCHard.MCH.hpm.remove(event.getPlayer().getName());
                PacketPlayOutScoreboardTeam removep = new PacketPlayOutScoreboardTeam(MCH.board.getTeam(p.getName().toLowerCase()),1);
                    for(Player pl:Bukkit.getOnlinePlayers()){
                        if(pl==event.getPlayer())continue;
                        ((CraftPlayer) pl).getHandle().playerConnection.sendPacket(removep);
                    }
                    
                    MCH.board.removeTeam(MCH.board.getTeam(p.getName().toLowerCase()));
		Location l = p.getLocation();

		for (Entity e : l.getWorld().getEntities()) {
			if (e instanceof Boat) {
				Location loc1 = e.getLocation();
				if (loc1.distanceSquared(l) <= 10) {
					e.remove();
					loc1.getWorld().spawnEntity(loc1, EntityType.BOAT);

				}
			}
			if(HPlayer.battle == true ){
			p.setHealth(0);
			HPlayer.battle = false;
			}
			if (e instanceof Minecart) {
				Location loc1 = e.getLocation();
				if (loc1.distanceSquared(l) <= 10) {
					e.remove();
					loc1.getWorld().spawnEntity(loc1, EntityType.MINECART);

				}
			}
			
		}

		// this.ar.remBattle(p.getName());
	}

}
