package pl.digitalix96.mchard.Events;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import pl.digitalix96.mchard.MCH;
import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.Guild;
import pl.digitalix96.mchard.Managers.GuildManager;
import pl.digitalix96.mchard.Managers.HPlayer;

public class CommandsEvent implements Listener {

	@EventHandler(priority = EventPriority.HIGHEST)
	public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent event) {
		String msg = event.getMessage().toLowerCase();
		msg = msg.replace("/", "");
		String[] args = msg.split(" ");
		Player p = event.getPlayer();
		if (args[0].equalsIgnoreCase("tnt-cuboid")) {
			if (p.isOp()) {
				for (Guild g : MCHard.MCH.guilds.values()) {
					if (g.isBattle()) {
						p.sendMessage(g.getName() + " czas: "
								+ g.getBattleTime());
					}
				}
			}
			event.setCancelled(true);
		}
		if (args[0].equalsIgnoreCase("gdel") && p.isOp()) {
			if (args.length >= 2) {
				Guild g = new GuildManager().getGuild(args[1].toUpperCase());
				if (g != null) {
					new GuildManager().removeGuild(g);
					p.sendMessage("Gildia została usunieta");
				} else {
					p.sendMessage("Gildia o tej nazwie nie istnieje!");
				}
			} else {
				p.sendMessage("Usuwanie gildi: /gdel TAG");
			}
			event.setCancelled(true);
		}
		 if(args[0].equalsIgnoreCase("cobbel")){
             HPlayer hp = MCH.HPlayers.get(event.getPlayer().getName().toLowerCase());
             if(hp.cobbel){
                 p.sendMessage(ChatColor.GREEN+"Drop cobbla został wyłączony.");
                 hp.cobbel = false;
             }else{
                  p.sendMessage(ChatColor.GREEN+"Drop cobbla został włączony.");
                  hp.cobbel = true;
             }
             event.setCancelled(true);
         }

	}

}
