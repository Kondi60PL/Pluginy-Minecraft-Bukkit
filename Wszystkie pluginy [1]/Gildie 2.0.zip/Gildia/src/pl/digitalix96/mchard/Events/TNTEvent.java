package pl.digitalix96.mchard.Events;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.inventory.ItemStack;

import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.Managers.Guild;

public class TNTEvent implements Listener {

	private int random = -1;
	private int random1 = -1;
	private int random4 = -1;
	private int random5 = -1;

	private int numDrops = 1;
	private int ldrop = 0;
	public Entity pig1;
	public Entity pig2;
	public Entity pig3;
	public List<Entity> et = new ArrayList<Entity>();
	public boolean d1 = false;
	public boolean d3 = false;
	public boolean d2 = false;

	@EventHandler(priority = EventPriority.HIGH)
	public void onExplosion(EntityExplodeEvent event) {

		Iterator iter = event.blockList().iterator();
		EntityType type = event.getEntity().getType();

		while (iter.hasNext()) {
			Block next = (Block) iter.next();

			if ((next.getTypeId() == 56) || (next.getTypeId() == 129)
					|| (next.getTypeId() == 14) || (next.getTypeId() == 15)) {
				next.setTypeId(0);
				iter.remove();
				next.getWorld().dropItemNaturally(next.getLocation(),
						new ItemStack(Material.COBBLESTONE, 1));

			}

		}
		if (type.toString().equalsIgnoreCase("CREEPER")) {
			return;
		}
		// EntityType.PRIMED_TNT
		Date d = new Date();
		int h = d.getHours();
		if (h <= 11 && event.getEntity().getType() == EntityType.PRIMED_TNT) {
            Bukkit.broadcastMessage(ChatColor.RED +"TnT zostalo wylaczone!");
			event.setCancelled(true);
			return;
		}
		Entity et = event.getEntity();
		Location loc = et.getLocation();
		Random numGen = new Random();
		this.random4 = (numGen.nextInt(99) + 1);
		Random numGen1 = new Random();
		this.random5 = (numGen1.nextInt(99) + 1);

		Location l = event.getLocation();
		// System.out.print("sprawdzam...");
		for (Guild g : MCHard.MCH.guilds.values()) {
			if (g.isCubZone(l)) {
				// System.out.print("blokuje");
				g.setBattle(true);
				g.setBattleTime(120);
			}
		}

		boolean water = false;

		if (checktnt(loc) == true) {
			water = true;
		}
		// this.deb1.l("watercheck - "+checktnt(loc) + loc.getX() + " " +
		// loc.getY() + " " + loc.getZ() + " ");
		for (int x = 0; x <= 6; x++)
			for (int y = 0; y <= 6; y++)
				for (int z = 0; z <= 6; z++) {
					Location targetLoc = new Location(et.getWorld(), loc.getX()
							+ x, loc.getY() + y, loc.getZ() + z);
					Location targetLoc1 = new Location(et.getWorld(),
							loc.getX() + x, loc.getY() - y, loc.getZ() - z);
					Location targetLoc2 = new Location(et.getWorld(),
							loc.getX() + x, loc.getY() - y, loc.getZ() + z);
					Location targetLoc3 = new Location(et.getWorld(),
							loc.getX() + x, loc.getY() + y, loc.getZ() - z);
					Location targetLoc4 = new Location(et.getWorld(),
							loc.getX() - x, loc.getY() + y, loc.getZ() + z);
					Location targetLoc5 = new Location(et.getWorld(),
							loc.getX() - x, loc.getY() - y, loc.getZ() - z);
					Location targetLoc6 = new Location(et.getWorld(),
							loc.getX() - x, loc.getY() - y, loc.getZ() + z);
					Location targetLoc7 = new Location(et.getWorld(),
							loc.getX() - x, loc.getY() + y, loc.getZ() - z);

					if (water == true) {

						if (this.random4 <= 90) {

							if (loc.distance(targetLoc) <= 4) {
								tnt(targetLoc, water);
							}
							if (loc.distance(targetLoc1) <= 4) {
								tnt(targetLoc1, water);
							}
							if (loc.distance(targetLoc2) <= 4) {
								tnt(targetLoc2, water);
							}
							if (loc.distance(targetLoc3) <= 4) {
								tnt(targetLoc3, water);
							}
							if (loc.distance(targetLoc4) <= 4) {
								tnt(targetLoc4, water);
							}
							if (loc.distance(targetLoc5) <= 4) {
								tnt(targetLoc5, water);
							}
							if (loc.distance(targetLoc6) <= 4) {
								tnt(targetLoc6, water);
							}
							if (loc.distance(targetLoc7) <= 4) {
								tnt(targetLoc7, water);
							}
							// numGen = new Random();
							// this.random4 = (numGen.nextInt(99) + 1);
							if (this.random5 <= 90) {
								water = false;
								if (loc.distance(targetLoc) <= 2) {
									tnt(targetLoc, water);
								}
								if (loc.distance(targetLoc1) <= 2) {
									tnt(targetLoc1, water);
								}
								if (loc.distance(targetLoc2) <= 2) {
									tnt(targetLoc2, water);
								}
								if (loc.distance(targetLoc3) <= 2) {
									tnt(targetLoc3, water);
								}
								if (loc.distance(targetLoc4) <= 2) {
									tnt(targetLoc4, water);
								}
								if (loc.distance(targetLoc5) <= 2) {
									tnt(targetLoc5, water);
								}
								if (loc.distance(targetLoc6) <= 2) {
									tnt(targetLoc6, water);
								}
								if (loc.distance(targetLoc7) <= 2) {
									tnt(targetLoc7, water);
								}
								water = true;
							}

						}

					} else {
						// numGen = new Random();
						// this.random4 = (numGen.nextInt(99) + 1);
						if (this.random5 <= 90) {

							if (loc.distance(targetLoc) <= 2) {
								tnt(targetLoc, water);
							}
							if (loc.distance(targetLoc1) <= 2) {
								tnt(targetLoc1, water);
							}
							if (loc.distance(targetLoc2) <= 2) {
								tnt(targetLoc2, water);
							}
							if (loc.distance(targetLoc3) <= 2) {
								tnt(targetLoc3, water);
							}
							if (loc.distance(targetLoc4) <= 2) {
								tnt(targetLoc4, water);
							}
							if (loc.distance(targetLoc5) <= 2) {
								tnt(targetLoc5, water);
							}
							if (loc.distance(targetLoc6) <= 2) {
								tnt(targetLoc6, water);
							}
							if (loc.distance(targetLoc7) <= 2) {
								tnt(targetLoc7, water);
							}
						}
					}

				}
	}

	private boolean checktnt(Location at) {
		boolean water = false;

		int id = at.getBlock().getTypeId();
		if ((id == 8) || (id == 9) || (id == 10) || (id == 11) || (id == 56)) {
			water = true;
			// this.plugin.deb.l(id);
		}

		return water;
	}

	private void tnt(Location at, boolean w) {

		Block b = at.getBlock();
		int id = at.getBlock().getTypeId();
		if ((b.getType() != null) && (b.getTypeId() != 7)
				&& (b.getTypeId() != 49) && (b.getTypeId() != 14)
				&& (b.getTypeId() != 15) && (b.getTypeId() != 56)
				&& (b.getTypeId() != 129)) {
			b.breakNaturally();
			b.setTypeId(0);

		} else {
			if ((id == 15) || (id == 14)) {
				b.setTypeId(0);
			}
			b.getLocation().getWorld()
					.dropItem(b.getLocation(), new ItemStack(4, 1));
		}
		if (w == false) {
			if (id == 49) {
				b.setTypeId(0);
				b.getLocation().getWorld()
						.dropItem(b.getLocation(), new ItemStack(id, 1));
			}
		}
		if (b.getTypeId() == 8) {
			b.breakNaturally();
			b.setTypeId(0);
		}
		if (b.getTypeId() == 9) {
			b.breakNaturally();
			b.setTypeId(0);
		}
		if (b.getTypeId() == 10) {
			b.breakNaturally();
			b.setTypeId(0);
		}
		if (b.getTypeId() == 11) {
			b.breakNaturally();
			b.setTypeId(0);
		}

	}

}
