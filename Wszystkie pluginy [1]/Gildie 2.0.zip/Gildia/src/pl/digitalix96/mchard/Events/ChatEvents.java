package pl.digitalix96.mchard.Events;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import pl.digitalix96.mchard.Managers.GuildManager;

public class ChatEvents implements Listener {

	  @EventHandler(priority=EventPriority.HIGH)
	  public void chatG(AsyncPlayerChatEvent e){
		  
		  Player p = e.getPlayer();
		  GuildManager gm = new GuildManager(e.getPlayer().getName());
			  if(p.getPlayer().hasPermission("czat.gracz")) {
				  if (gm.inGuild()){
				  e.setFormat("�8[�c"+gm.getGuild().getName()+"�8]�2[�7Gracz�2]�8"+ p.getDisplayName() +"�a�l >> �f"+e.getMessage());
				  }else{
					  e.setFormat("�2[�7Gracz�2]�8"+ p.getDisplayName() +"�a�l >> �f"+e.getMessage());
				  }
			  }
				  if(p.getPlayer().hasPermission("czat.vip")) {
					  if (gm.inGuild()){
						  e.setFormat("�8[�c"+gm.getGuild().getName()+"�8]�2[�3Vip�2]�2"+ p.getDisplayName() +"�a�l >> �6"+e.getMessage());
					  }else{
						  e.setFormat("�2[�3Vip�2]�2"+ p.getDisplayName() +"�a�l >> �6"+e.getMessage());
					  }
				  }
					  if(p.getPlayer().hasPermission("czat.youtuber")) {
						  if (gm.inGuild()){
							  e.setFormat("�8[�c"+gm.getGuild().getName()+"�8]�2[�5Youtuber�2]�e"+ p.getDisplayName() +"�a�l >> �2�l"+e.getMessage());
						  }  else{
							  e.setFormat("�2[�5Youtuber�2]�e"+ p.getDisplayName() +"�a�l >> �2�l"+e.getMessage());
						  }
					  }
						  if(p.getPlayer().hasPermission("czat.admin")) {
							  if (gm.inGuild()){
								  e.setFormat("�8[�c"+gm.getGuild().getName()+"�8]�2[�cHeadAdmin�2]�3"+ p.getDisplayName() +"�a�l >> �2�l"+e.getMessage());
							  }  else{
								  e.setFormat("�2[�cHeadAdmin�2]�3"+ p.getDisplayName() +"�a�l >> �2�l"+e.getMessage());
							  }
						  }
							  if(p.getPlayer().hasPermission("czat.mod")) {
								  if (gm.inGuild()){
									  e.setFormat("�8[�c"+gm.getGuild().getName()+"�8]�2[�bModerator�2]�3"+ p.getDisplayName() +"�a�l >> �2"+e.getMessage());
								  }else{
									  e.setFormat("�2[�bModerator�2]�3"+ p.getDisplayName() +"�a�l >> �2"+e.getMessage());
								  }
							  }
								  if(p.getPlayer().hasPermission("czat.wlasciciel")) {
									  if (gm.inGuild()){
										  e.setFormat("�8[�c"+gm.getGuild().getName()+"�8]�2[�5Youtuber�2]�e"+ p.getDisplayName() +"�a�l >> �2�l"+e.getMessage());
								  } else{
										  e.setFormat("�2[�4�lWlasciciel�2]�3�l"+ p.getDisplayName() +"�a�l >> �2�l"+e.getMessage());
									  }
								  }
	  }
}
						
				 
		  
		  
	 

	
