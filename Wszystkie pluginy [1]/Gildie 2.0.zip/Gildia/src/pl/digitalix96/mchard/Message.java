package pl.digitalix96.mchard;

import java.util.HashMap;

import org.bukkit.ChatColor;

public class Message {

	public HashMap<String, String> m = new HashMap<String, String>();

	public Message() {
		// GuildMSG
		m.put("opusciles", ChatColor.AQUA + "Opusciles gildie "
				+ ChatColor.YELLOW + "%g%" + ChatColor.AQUA + ".");
		m.put("opuscil", ChatColor.GREEN + "Gracz " + ChatColor.WHITE + "%p%"
				+ ChatColor.GREEN + " opuscil gildie " + ChatColor.YELLOW
				+ "%g%" + ChatColor.GREEN + "!");
		m.put("lideropusc", ChatColor.RED
				+ "Jestes liderem gildi, nie mozesz jej opuscic.");
		m.put("zastepcaopusc", ChatColor.RED
				+ "Jestes zastępcą gildi, nie mozesz jej opuscic.");
		m.put("bezgildi", ChatColor.RED + "Nie jestes czlonkiem gildi.");
		m.put("niemago", ChatColor.RED
				+ "Ten gracz nie jest czlonkiem twojej gildi!");
		m.put("wyrzucony", ChatColor.RED + "Gracz " + ChatColor.WHITE + "%p%"
				+ ChatColor.RED + " zostal wyrzucony z gildi "
				+ ChatColor.YELLOW + "%g%" + ChatColor.RED + "!");
		m.put("nielider", ChatColor.RED
				+ "Nie jestes Liderem tej gildi. Nie mozesz uzyc tej komendy.");
		m.put("dodany", ChatColor.GREEN + "Gracz " + ChatColor.WHITE + "%p%"
				+ ChatColor.GREEN + " dolaczyl do gildi " + ChatColor.YELLOW
				+ "%g%" + ChatColor.GREEN + "!");
		m.put("zaproszenie", ChatColor.AQUA
				+ "Gracz %p% zostal zaproszony do gildi.");
		m.put("niezaproszony", ChatColor.RED
				+ "Gracz %p% nalezy juz do innej gildi.");
		m.put("niejesteszaproszony", ChatColor.RED
				+ "Nie jestes zaproszony do tej gildi.");
		m.put("niedolacz",
				ChatColor.RED
						+ "Jestes juz czlonkiem gildi, by dolaczyc do innej gildi musisz opuscic aktualna (/opusc).");
		m.put("sojusz", ChatColor.GREEN + "Gildia %g% i %g1% zawarly sojusz.");
		m.put("niematakiej", ChatColor.RED + "Gildia %g% nie istnieje.");
		m.put("zaprossojusz", ChatColor.AQUA
				+ "Gildia %g% zostala zaproszona do sojuszu.");
		m.put("sojuszjest", ChatColor.RED
				+ "Twoja gildia zawarla juz sojusz z gildia %g%.");
		m.put("sojusznie", ChatColor.RED
				+ "Twoja gildia nie zostala zaproszona do sojuszu z ta gildia!");
		m.put("sojuszniejest", ChatColor.RED
				+ "Twoja gildia nie zawarla sojuszu z ta gildia!");
		m.put("sojuszzap",
				ChatColor.AQUA
						+ "Twoja gildia zostala zaproszona do sojuszu z %g%.\nBy akceptowac sojusz wpisz /akcpetujsojusz %g%");
		m.put("koniecsojuszu", ChatColor.RED
				+ "Gildia %g% i %g1% zerwaly sojusz.");
		m.put("zablisko", ChatColor.RED
				+ "Jestes zbyt blisko innej gildi by zalozyc nowa gildie!");
		m.put("zablisko1", ChatColor.RED
				+ "Oddal sie troche i sproboj ponownie!");
		m.put("zakrutka", ChatColor.RED
				+ "Nazwa twojej gildi moze zawierac tylko 4 litery.");
		m.put("juzistnieje", ChatColor.RED
				+ "Gildia o tej nazwie juz istnieje.");
		m.put("nowagildia", ChatColor.GREEN
				+ "Gildia %g% zostala zalozona przez" + ChatColor.WHITE
				+ " %p%" + ChatColor.GREEN + "!");
		m.put("chat@", ChatColor.RED
				+ "Nie mozesz pisac na czacie gildijnym nie nalezac do gildi!");
		m.put("allychat@", ChatColor.RED
				+ "Nie mozesz pisac na czacie gildijnym nie nalezac do gildi!");
		m.put("niemoznanowej", ChatColor.RED
				+ "Nie mozna zalozyc nowej gildi bedac czlonkiem innej!");
		m.put("bydodac", ChatColor.AQUA + "/dodaj nick");
		m.put("infozaproszenie",
				ChatColor.GREEN
						+ "Zostales zaproszony do gildi %g%.\nBy dolaczyc do tej gildi wpisz /dolacz %g%");
		m.put("nowylider", ChatColor.GREEN + "Nowym Liderem gildi "
				+ ChatColor.YELLOW + "%g%" + ChatColor.GREEN + " zostal gracz "
				+ ChatColor.WHITE + "%p%" + ChatColor.GREEN + "!");
		m.put("nowyzastepca", ChatColor.GREEN
				+ "Nowym Zastępcą Lidera gildi " + ChatColor.YELLOW + "%g%"
				+ ChatColor.GREEN + " zostal gracz " + ChatColor.WHITE + "%p%"
				+ ChatColor.GREEN + "!");
		m.put("zamknij", ChatColor.RED + "Gildia " + ChatColor.YELLOW + "%g%"
				+ ChatColor.GREEN + " zostala zamknieta!");
		m.put("walkastart",ChatColor.RED+"Walka sie rozpoczela! Jesli sie teraz wylogujesz zostaniesz zbanowany!");
	}

	public String get(String s) {
		return this.m.get(s);
	}

}
