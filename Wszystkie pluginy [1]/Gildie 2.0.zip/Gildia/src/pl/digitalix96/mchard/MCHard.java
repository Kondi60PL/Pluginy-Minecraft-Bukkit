package pl.digitalix96.mchard;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

import pl.digitalix96.mchard.Commands.Dodaj;
import pl.digitalix96.mchard.Commands.Dolacz;
import pl.digitalix96.mchard.Commands.Gildia;
import pl.digitalix96.mchard.Commands.Gildie;
import pl.digitalix96.mchard.Commands.Lider;
import pl.digitalix96.mchard.Commands.Opusc;
import pl.digitalix96.mchard.Commands.RankingCMD;
import pl.digitalix96.mchard.Commands.Sojusz;
import pl.digitalix96.mchard.Commands.Wyrzuc;
import pl.digitalix96.mchard.Commands.Zaloz;
import pl.digitalix96.mchard.Commands.Zamknij;
import pl.digitalix96.mchard.Commands.Zastepca;
import pl.digitalix96.mchard.Commands.ZerwijSojusz;
import pl.digitalix96.mchard.Commands.as;
import pl.digitalix96.mchard.Events.BlockEvents;
import pl.digitalix96.mchard.Events.ChatEvents;
import pl.digitalix96.mchard.Events.CommandsEvent;
import pl.digitalix96.mchard.Events.QuitEvent;
import pl.digitalix96.mchard.Events.TNTEvent;
import pl.digitalix96.mchard.Managers.Guild;
import pl.digitalix96.mchard.Managers.GuildManager;
import pl.digitalix96.mchard.Managers.HPlayer;
import pl.digitalix96.mchard.Managers.HPlayerManager;

public class MCHard extends JavaPlugin {

	public enum ServerType {
		MCHard, MCPack
	}

	public static MCHard plugin = null;
	protected static final Logger log = Logger.getLogger("Minecraft");
	protected static final String prefix = "[MCW] ";
	public static boolean MySQL = true;
	public static MySQLDatabase mysql;
	public static ServerType st;

	public static ConsoleCommandSender console;
	public static String name;
	public static String version;

	public static MCH MCH = null;
	public static Message M = new Message();

	public static boolean running = true;
	public static boolean move_info = true;
	public static boolean chat;
	public static boolean home = true;
	public static boolean tag;

	public void onDisable() {
		MCHard.running = false;
	}

	public void onEnable() {
		final long start1 = System.currentTimeMillis();
		plugin = this;
		console = this.getServer().getConsoleSender();
		name = this.getDescription().getName();
		version = this.getDescription().getVersion();

		loadConfiguration();
		loadMySQL();

		st = ServerType.valueOf(this.getConfig().getString("Server.Type"));

		console.sendMessage(ChatColor.GREEN + "[" + name + "] Wlaczony.");

		pl.digitalix96.mchard.MCH.world = this.getConfig().getString(
				"Server.world");
		pl.digitalix96.mchard.MCH.size = this.getConfig().getInt("Cuboid.Size");
		MCH = new MCH();
		MCH.loadGuilds();
		GuildManager.i1 = this.getConfig().getInt("Item.1.ID");
		GuildManager.it1 = this.getConfig().getString("Item.1.Name");
		GuildManager.ii1 = this.getConfig().getInt("Item.1.Amount");

		GuildManager.i2 = this.getConfig().getInt("Item.2.ID");
		GuildManager.it2 = this.getConfig().getString("Item.2.Name");
		GuildManager.ii2 = this.getConfig().getInt("Item.2.Amount");

		GuildManager.i3 = this.getConfig().getInt("Item.3.ID");
		GuildManager.it3 = this.getConfig().getString("Item.3.Name");
		GuildManager.ii3 = this.getConfig().getInt("Item.3.Amount");

		GuildManager.i4 = this.getConfig().getInt("Item.4.ID");
		GuildManager.it4 = this.getConfig().getString("Item.4.Name");
		GuildManager.ii4 = this.getConfig().getInt("Item.4.Amount");

		GuildManager.i5 = this.getConfig().getInt("Item.5.ID");
		GuildManager.it5 = this.getConfig().getString("Item.5.Name");
		GuildManager.ii5 = this.getConfig().getInt("Item.5.Amount");

		GuildManager.i6 = this.getConfig().getInt("Item.6.ID");
		GuildManager.it6 = this.getConfig().getString("Item.6.Name");
		GuildManager.ii6 = this.getConfig().getInt("Item.6.Amount");

		GuildManager.i7 = this.getConfig().getInt("Item.7.ID");
		GuildManager.it7 = this.getConfig().getString("Item.7.Name");
		GuildManager.ii7 = this.getConfig().getInt("Item.7.Amount");

		getCommand("gildia").setExecutor(new Gildia(this));
		getCommand("lista").setExecutor(new Gildie(this));
		getCommand("dodaj").setExecutor(new Dodaj(this));
		getCommand("dolacz").setExecutor(new Dolacz(this));
		getCommand("opusc").setExecutor(new Opusc(this));
		getCommand("wyrzuc").setExecutor(new Wyrzuc(this));
		getCommand("lider").setExecutor(new Lider(this));
		getCommand("zastepca").setExecutor(new Zastepca(this));
		getCommand("zamknij").setExecutor(new Zamknij(this));
		getCommand("zaloz").setExecutor(new Zaloz(this));
		getCommand("sojusz").setExecutor(new Sojusz(this));
		getCommand("zerwijsojusz").setExecutor(new ZerwijSojusz(this));
		getCommand("asojusz").setExecutor(new as(this));
        getCommand("ranking").setExecutor(new RankingCMD(this));
        getCommand("gbaza").setExecutor(new Gildia(this));
        getCommand("gczat").setExecutor(new Gildia(this));
        getCommand("gsoj").setExecutor(new Gildia(this));
        //getCommand("cobbel").setExecutor(new Gildia(this));

		getServer().getPluginManager().registerEvents(new QuitEvent(), this);
		getServer().getPluginManager().registerEvents(new BlockEvents(), this);
		getServer().getPluginManager().registerEvents(new TNTEvent(), this);
		getServer().getPluginManager().registerEvents(new ChatEvents(), this);
		getServer().getPluginManager().registerEvents(new CommandsEvent(), this);
		
		new Reconnect().start();
		new TNT().start();
                new Thread(){

                    @Override
                    public void run() {
                    	
                        while(true){
                            for(Player p:Bukkit.getOnlinePlayers()){
                                TagAPI.refreshPlayer(p);
                            }
                            try {
                                Thread.sleep(5000);
                            } catch (InterruptedException ex) {
                                Logger.getLogger(MCHard.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                }.start();
        		
    					
    				
    			
    			
    		
                
                
                
                
		final long end1 = System.currentTimeMillis();
		console.sendMessage(ChatColor.GREEN + "[" + name + "] Wersja "
				+ version + " - plugin zaladowany w " + ((end1 - start1))
				+ " ms");
	}

	private void loadConfiguration() {
		getConfig().addDefault("MySQL.Host", "db4free.net");
		getConfig().addDefault("MySQL.Port", "3306");
		getConfig().addDefault("MySQL.User", "otus123");
		getConfig().addDefault("MySQL.Password", "51027otek1992");
		getConfig().addDefault("MySQL.Database", "otus123");
		getConfig().addDefault("MySQL.Table", "bany");
		getConfig().addDefault("Stone-Info", "null");
		getConfig().addDefault("Server.Type", "MCHard");
		getConfig().addDefault("Server.world", "world");
		getConfig().addDefault("Cuboid.Size", 50);
		getConfig().addDefault("Item.1.ID", 0);
		getConfig().addDefault("Item.1.Name", "AIR");
		getConfig().addDefault("Item.1.Amount", 64);
		getConfig().addDefault("Item.2.ID", 0);
		getConfig().addDefault("Item.2.Name", "AIR");
		getConfig().addDefault("Item.2.Amount", 64);
		getConfig().addDefault("Item.3.ID", 0);
		getConfig().addDefault("Item.3.Name", "AIR");
		getConfig().addDefault("Item.3.Amount", 64);
		getConfig().addDefault("Item.4.ID", 0);
		getConfig().addDefault("Item.4.Name", "AIR");
		getConfig().addDefault("Item.4.Amount", 64);
		getConfig().addDefault("Item.5.ID", 0);
		getConfig().addDefault("Item.5.Name", "AIR");
		getConfig().addDefault("Item.5.Amount", 64);
		getConfig().addDefault("Item.6.ID", 0);
		getConfig().addDefault("Item.6.Name", "AIR");
		getConfig().addDefault("Item.6.Amount", 64);
		getConfig().addDefault("Item.7.ID", 0);
		getConfig().addDefault("Item.7.Name", "AIR");
		getConfig().addDefault("Item.7.Amount", 64);

		getConfig().options().copyDefaults(true);
		saveConfig();
		console.sendMessage(ChatColor.GREEN + "[" + name + "] Zaladowal sie!");
	}

	public void loadMySQL() {
		if (getConfig().getString("MySQL.Host").equals(null)) {
			MySQL = false;
			log.severe("["
					+ name
					+ "] MySQL is on, but host is not defined, disabling plugin");
			// getServer().getPluginManager().disablePlugin(this);
		}
		if (getConfig().getString("MySQL.User").equals(null)) {
			MySQL = false;
			log.severe("["
					+ name
					+ "] MySQL is on, but username is not defined, disabling plugin");
			// getServer().getPluginManager().disablePlugin(this);
		}
		if (getConfig().getString("MySQL.Password").equals(null)) {
			MySQL = false;
			log.severe("["
					+ name
					+ "] MySQL is on, but password is not defined, disabling plugin");
			// getServer().getPluginManager().disablePlugin(this);
		}
		if (getConfig().getString("MySQL.Database").equals(null)) {
			MySQL = false;
			log.severe("["
					+ name
					+ "] MySQL is on, but database is not defined, disabling plugin");
			// getServer().getPluginManager().disablePlugin(this);
		}

		if (MySQL) {
			mysql = new MySQLDatabase(this,
					getConfig().getString("MySQL.Host"), getConfig().getString(
							"MySQL.User"), getConfig().getString("MySQL.Port"),
					getConfig().getString("MySQL.Password"), getConfig()
							.getString("MySQL.Database"));
			logMessage(Level.INFO, "Inicjalizacja MySQL...");
			try {
				mysql.open();
			} catch (Exception e) {
				logMessage(Level.SEVERE,
						"Nie mozna nazwiÄ…zaÄ‡ poĹ‚Ä…czenia z MySQL: "
								+ e.getMessage());
			}

			if (mysql.checkConnection()) {
				logMessage(Level.INFO, "Polaczono z BazÄ… MySQL");

				if (!mysql.checkTable("gildie")) {
					logMessage(Level.INFO,
							"Table 'gildie' not found, creating...");
					String query = "CREATE TABLE gildie (lider char(50),  logo text, nazwa text )";
					mysql.createTable(query);
				}
				if (!mysql.checkTable("czlonkowie")) {
					logMessage(Level.INFO,
							"Table 'czlonkowie' not found, creating...");
					String query = "CREATE TABLE czlonkowie (nick char(50),  gildia text)";
					mysql.createTable(query);

				}
				if (!mysql.checkTable("ghome")) {
					logMessage(Level.INFO,
							"Table 'ghome' not found, creating...");
					String query = "CREATE TABLE ghome (gildia char(4),  loc text)";
					mysql.createTable(query);
				}

			} else {
				logMessage(
						Level.INFO,
						"PoĹ‚Ä…czenie z MySQL nie powiodĹ‚o sie, serwer zostanie wyĹ‚Ä…czony.");
				// getServer().getPluginManager().disablePlugin(this);
			}
		}
	}

	public static void logMessage(Level lev, String msg) {
		log.log(lev, "[" + name + "] " + msg);
	}

	public static class Reconnect extends Thread {
		public void run() {
			while (MCHard.running) {
				System.out.print("Odswiezam polaczenie z serverem MySQL");
				MCHard.mysql.query("SELECT * FROM zycia LIMIT 1");
				try {
					Thread.sleep(60000 * 10L);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
	}

	public static class TNT extends Thread {
		public void run() {
			while (MCHard.running) {

				try {
					Thread.sleep(1000L);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				for (Guild g : MCHard.MCH.guilds.values()) {

					if (g.getBattleTime() >= 1 && g.getBattleTime() <= 120) {
						int time = g.getBattleTime();
						time = time - 1;
						g.setBattleTime(time);
						g.setBattle(true);
						if (time <= 0) {
							g.setBattleTime(121);
							g.setBattle(false);
						}
					}
				}
			}
		}
	}

	public static class TMySQL extends Thread {
		public String query;

		public TMySQL(String q) {
			this.query = q;
		}

		public void send() {
			try {
				MCHard.mysql.query(this.query);
			} catch (Exception e) {
				System.out.print(" ----- Blad servera MySQL ----- ");
				System.out.print(e.getMessage());
			}
		}

	}

}
