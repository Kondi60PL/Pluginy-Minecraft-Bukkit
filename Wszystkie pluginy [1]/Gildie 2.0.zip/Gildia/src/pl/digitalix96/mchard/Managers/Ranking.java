package pl.digitalix96.mchard.Managers;

import pl.digitalix96.mchard.MCHard.TMySQL;

public class Ranking {

	private String name;
	private Integer points;
	private int deads;
	private int kills;
	
	public Ranking(String name, int points, int kills, int deads){
		this.name = name;
		this.points = points;
		this.deads = deads;
		this.kills = kills;
	}
	
	public String getName(){
		return this.name;
	}
	public int getDeads(){
		return this.deads;
	}
	public boolean setDeads(int d){
		this.deads = d;
		new TMySQL("UPDATE `statystyki` SET `smierci` = '"+this.deads+"' WHERE nick = '" + getName().toLowerCase() + "'").send();
		return true;
	}
	public int getKills(){
		return this.kills;
	}
	public boolean setKills(int k){
		this.kills = k;
		new TMySQL("UPDATE `statystyki` SET `zabojstwa` = '"+this.kills+"' WHERE nick = '" + getName().toLowerCase() + "'").send();
		return true;
	}
	public Integer getPoints(){
		return this.points;
	}
	public boolean setPoints(int poitns){
		this.points = poitns;
		new TMySQL("UPDATE `statystyki` SET `punkty` = '"+this.points+"' WHERE nick = '" + getName().toLowerCase() + "'").send();
		return true;
	}
}
