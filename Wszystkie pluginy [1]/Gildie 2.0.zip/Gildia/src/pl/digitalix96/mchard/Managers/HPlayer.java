package pl.digitalix96.mchard.Managers;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.server.v1_7_R1.PacketPlayOutScoreboardTeam;
import net.minecraft.server.v1_7_R1.ScoreboardTeam;
import org.bukkit.Bukkit;
import org.bukkit.craftbukkit.v1_7_R1.entity.CraftPlayer;
import org.bukkit.entity.Player;
import pl.digitalix96.mchard.MCH;

public class HPlayer {

	public String name;
	private String player,playerhit;
	public static boolean battle = false;
    public boolean cobbel = true;
	private int time = 0;
	private int battletime = 16;
	private List<String> invites = new ArrayList<String>();
        private Ranking rank;
	public HPlayer(String name) {
		this.name = name.toLowerCase();
	}

	public String getName() {
		return this.name;
	}

	public List<String> getInvites() {
		return this.invites;
	}
        public Ranking getRanking(){
            return MCH.rankings.get(name.toLowerCase());
        }
                public void updatePrefix(){
            ScoreboardTeam t = MCH.board.getTeam(name.toLowerCase());
            if(t == null){
                t =  MCH.board.createTeam(name.toLowerCase());
                t.setCanSeeFriendlyInvisibles(false);
                t.setPrefix("MCH");
                t.setSuffix(" ");
                t.setDisplayName("MCH");
            }
            t.getFormattedName(name.toLowerCase());
            MCH.board.addPlayerToTeam(Bukkit.getPlayer(name).getName(), t.getName());
            PacketPlayOutScoreboardTeam packet = new PacketPlayOutScoreboardTeam(t,0);
            ((CraftPlayer) Bukkit.getPlayer(name)).getHandle().playerConnection.sendPacket(packet);
            for(Player p:Bukkit.getOnlinePlayers()){
                if(p==Bukkit.getPlayer(name))continue;
//                if(MCH.HPlayers.get(p.getName().toLowerCase()).recivedTeams.contains(t))continue;
                ((CraftPlayer) p).getHandle().playerConnection.sendPacket(packet);
            }
            for(Object sbt:MCH.board.getTeams()){
                if((ScoreboardTeam) sbt == t)continue;
//                if(recivedTeams.contains((ScoreboardTeam) sbt))continue;
//                recivedTeams.add((ScoreboardTeam) sbt);
                PacketPlayOutScoreboardTeam packet1 = new PacketPlayOutScoreboardTeam((ScoreboardTeam) sbt,0);
                ((CraftPlayer) Bukkit.getPlayer(name)).getHandle().playerConnection.sendPacket(packet1);
            }
        }
	public boolean checkInvite(String invite) {
		boolean ii = false;
		for (String i : invites) {
			if (i.equalsIgnoreCase(invite))
				ii = true;
		}
		return ii;
	}

	public boolean addInvite(String i) {
		this.invites.add(i.toUpperCase());
		return true;
	}

	public boolean removeInvite(String i) {
		this.invites.remove(i.toUpperCase());
		return true;
	}
	public boolean setBattle(boolean battle){
		this.battle = battle;
		return true;
	}
	public boolean setBattleTime(int time){
		this.battletime = time;
		return true;
	}
	public boolean setLastHit(String playerhit){
		this.playerhit = playerhit;
		return true;
	}
	
	public boolean isBattle(){
		return this.battle;
	}
	public int getBattleTime(){
		return this.battletime;
	
}
}
