package pl.digitalix96.mchard.Managers;
 
import java.util.ArrayList;
import java.util.List;
 


import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;

import pl.digitalix96.mchard.MCH;
 
import pl.digitalix96.mchard.MCHard.TMySQL;
import pl.digitalix96.mchard.Rank;
 
public class Guild {
 
        private String name;
        private String fullname;
        private GuildLocation loc;
        private String lider;
        private String zastepca;
        private List<String> czlonkowie;
        private List<String> ally;
        private Location home;
        private List<String> allyinv = new ArrayList<String>();
        private boolean pvp;
        private boolean battle = false;
        private int battleTime = 121;
        private ArrayList<Location> furances = new ArrayList<Location>();
 
        public Guild(String name, String fullname, GuildLocation loc, String lider,
                        String zastepca, List<String> czlonkowie, List<String> ally,
                        boolean pvp, ArrayList<Location> furances, Location home) {
 
                this.name = name;
                this.fullname = fullname;
                this.loc = loc;
                this.lider = lider;
                this.zastepca = zastepca;
                this.czlonkowie = czlonkowie;
                this.ally = ally;
                this.pvp = pvp;
                this.furances = furances;
                this.home = home;
 
        }
 
        public String getLider() {
                return this.lider;
        }
 
        public String getZastepca() {
                return this.zastepca;
        }
 
        public String getName() {
                return this.name;
        }
 
        public String getFullName() {
                return this.fullname;
        }
 
        public GuildLocation getLocation() {
                return this.loc;
        }
 
        public Location getHomeLocation() {
                return this.home;
        }
 
        public List<String> getPlayers() {
                return this.czlonkowie;
        }
 
        public List<String> getAllyInvites() {
                return this.allyinv;
        }
 
        public List<String> getAllyList() {
                return this.ally;
        }
 
        public boolean getPVP() {
                return this.pvp;
        }
 
        public ArrayList<Location> getFurances() {
                return this.furances;
        }
 
        public boolean isAlly(String g) {
                boolean ally = false;
                if (this.ally == null)
                        return false;
                for (String ga : this.ally) {
                        if (ga.equalsIgnoreCase(g)) {
                                ally = true;
                        }
                }
                return ally;
        }
 
        public int getBattleTime() {
                return this.battleTime;
        }
 
        public boolean setBattleTime(int time) {
                this.battleTime = time;
                return true;
        }
 
        public boolean isBattle() {
                return this.battle;
        }
 
        public boolean setBattle(boolean battle) {
                this.battle = battle;
                return true;
        }
 
        public boolean addAllyInvite(String g) {
                this.allyinv.add(g.toUpperCase());
                return true;
        }
 
        public boolean isAllyInvite(String g) {
                boolean j = false;
                for (String i : this.allyinv) {
                        if (i.equalsIgnoreCase(g)) {
                                j = true;
                        }
                }
                return j;
        }
 
        public boolean removeAllyInvite(String g) {
                this.allyinv.remove(g.toUpperCase());
                return true;
        }
 
        public boolean setLider(String player) {
                this.lider = player;
                new TMySQL("UPDATE `gildie` SET `lider` = '" + player
                                + "' WHERE logo = '" + getName() + "'").send();
                return true;
        }
 
        public boolean setZastepca(String player) {
                this.zastepca = player;
                new TMySQL("UPDATE `gildie` SET `zastepca` = '" + player
                                + "' WHERE logo = '" + getName() + "'").send();
                return true;
        }
 
        public boolean setPVP(boolean pvp) {
                this.pvp = pvp;
                // new TMySQL("").send();
                return pvp;
        }
 
        public boolean add(String player) {
 
                this.czlonkowie.add(player.toLowerCase());
                new TMySQL("INSERT INTO czlonkowie (`nick`, `gildia`) VALUES ('"
                                + player.toLowerCase() + "', '" + getName() + "')").send();
 
                return true;
        }
 
        public boolean remove(String player) {
                this.czlonkowie.remove(player.toLowerCase());
                new TMySQL("DELETE FROM `czlonkowie` WHERE `nick` = '"
                                + player.toLowerCase() + "'").send();
                return true;
        }
 
        public boolean addAlly(String allyname) {
                this.ally.add(allyname);
                new TMySQL("INSERT INTO sojusze (`g0`, `g1`) VALUES ('" + allyname
                                + "', '" + getName() + "')").send();
                return true;
        }
 
        public boolean removeAlly(String allyname) {
                this.ally.remove(allyname.toUpperCase());
                new TMySQL("DELETE FROM `sojusze` WHERE `g0` = '" + allyname
                                + "' AND `g1` = '" + getName() + "'").send();
                new TMySQL("DELETE FROM `sojusze` WHERE `g1` = '" + allyname
                                + "' AND `g0` = '" + getName() + "'").send();
                return true;
        }
 
        public boolean PlayerIsInGuild(String p) {
                boolean jest = false;
                for (String pp : getPlayers()) {
                        if (pp.equalsIgnoreCase(p)) {
                                jest = true;
                        }
                }
                return jest;
        }
         public boolean isInZone(String p, Location bpl) {
                boolean jest = false;
               
                p = p.toLowerCase();
                double xb = bpl.getX();
                double zb = bpl.getZ();
                int minxg = getLocation().getMinLocation().getBlockX();
                int minzg = getLocation().getMinLocation().getBlockZ();
                int maxxg = getLocation().getMaxLocation().getBlockX();
                int maxzg = getLocation().getMaxLocation().getBlockZ();
 
                if (xb >= minxg && zb >= minzg && xb <= maxxg && zb <= maxzg) {
                        if (PlayerIsInGuild(p)) {
 
                        } else {
                                jest = true;
                        }
                } else {
 
                }
 
                return jest;
        }
        public boolean isInZone2(String p, Location bpl) {
                boolean jest = true;
               
                p = p.toLowerCase();
                double xb = bpl.getX();
                double zb = bpl.getZ();
                int minxg = getLocation().getMinLocation().getBlockX();
                int minzg = getLocation().getMinLocation().getBlockZ();
                int maxxg = getLocation().getMaxLocation().getBlockX();
                int maxzg = getLocation().getMaxLocation().getBlockZ();
 
                if (xb >= minxg && zb >= minzg && xb <= maxxg && zb <= maxzg) {
                        if (PlayerIsInGuild(p)) {
                        } else {
                                jest = false;
                        }
                } else {
                        jest = false;
                }
 
                return jest;
        }
 
        public boolean isCubZone(Location bpl) {
                boolean jest = false;
 
                double xb = bpl.getX();
                double zb = bpl.getZ();
                int minxg = getLocation().getMinLocation().getBlockX();
                int minzg = getLocation().getMinLocation().getBlockZ();
                int maxxg = getLocation().getMaxLocation().getBlockX();
                int maxzg = getLocation().getMaxLocation().getBlockZ();
 
                if (xb >= minxg && zb >= minzg && xb <= maxxg && zb <= maxzg) {
 
                        jest = true;
 
                } else {
 
                }
 
                return jest;
        }
 
        public void runFuranceChecker() {
                new checkFurances().start();
        }
 
    public Integer getPoints(){
            int points = 0;
            for(String pl:getPlayers())points = points + MCH.rankings.get(pl.toLowerCase()).getPoints();
            points = points / getPlayers().size();
            return points;
     }
    public int getRankNum(){
            return Rank.getGuildRankInfo(this);
        }
 
        public void setHomeLocation(Location home){
                this.home = home;
                System.out.println("wpisano do mysql");
                new TMySQL("UPDATE `ghome` SET `loc` = '"+home.getWorld().getName()+":"+home.getBlockX()+":"+home.getBlockY()+":"+home.getBlockZ()+"' WHERE gildia = '" + getName()  + "'").send();
        }
        public class checkFurances extends Thread {
                public void run() {
                        List<Location> dellist = new ArrayList<Location>();
                        for (Location l : getFurances()) {
                                Material m = l.getBlock().getType();
                                if (m == Material.FURNACE || m == Material.BURNING_FURNACE) {
                                } else {
 
                                        int x = l.getBlockX();
                                        int y = l.getBlockY();
                                        int z = l.getBlockZ();
                                        System.out.print("Piecyk na lokalizacji " + x + " " + y
                                                        + " " + z + " nie istniej! " + m);
                                        dellist.add(l);
                                        new TMySQL("DELETE FROM `piecyki` WHERE `loc` = '" + x
                                                        + ":" + y + ":" + z + "'").send();
                                }
                        }
                        for (Location l : dellist) {
                                getFurances().remove(l);
                        }
                }
        }
        }