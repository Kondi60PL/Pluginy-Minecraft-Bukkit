package pl.digitalix96.mchard.Managers;

import org.bukkit.entity.Player;

public class GPlayer {

	private Player p;
	private boolean intruz = false;
	private Guild g;

	public GPlayer(Player p) {
		this.p = p;
	}

	public Guild getG() {
		return g;
	}

	public boolean isIntruz() {
		return intruz;
	}

	public void setG(Guild g) {
		this.g = g;
	}

	public void setIntruz(boolean intruz) {
		this.intruz = intruz;
	}
}