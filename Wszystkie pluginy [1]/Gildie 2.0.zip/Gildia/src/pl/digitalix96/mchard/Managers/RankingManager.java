package pl.digitalix96.mchard.Managers;

import java.util.Comparator;

public class RankingManager implements Comparator<Ranking> {

	@Override
	public int compare(Ranking r0, Ranking r1) {
		return r1.getPoints().compareTo(r0.getPoints());
	}

}
