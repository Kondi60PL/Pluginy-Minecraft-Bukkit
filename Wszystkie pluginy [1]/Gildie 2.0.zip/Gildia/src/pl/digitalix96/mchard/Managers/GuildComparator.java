/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pl.digitalix96.mchard.Managers;

import java.util.Comparator;
public class GuildComparator implements Comparator<Guild> {

	@Override
	public int compare(Guild g0, Guild g1) {
		return g1.getPoints().compareTo(g0.getPoints());
	}

}
