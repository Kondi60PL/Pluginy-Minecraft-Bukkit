package pl.digitalix96.mchard.Managers;

import pl.digitalix96.mchard.MCHard;

public class HPlayerManager {
	public String player;
	public pl.digitalix96.mchard.MCH MCH = MCHard.MCH;

	public HPlayerManager(String player) {
		this.player = player.toLowerCase();
	}

	public HPlayer getHPlayer(String p) {
		return this.MCH.hpm.get(p.toLowerCase());
	}

	public HPlayer getHPlayer() {
		return this.MCH.hpm.get(this.player.toLowerCase());
	}

        public String updateRanking(String player, String killer){
		String updatedstats = null;
		  HPlayer hp = new HPlayerManager(player).getHPlayer();
		  HPlayer hk = new HPlayerManager(killer).getHPlayer();
		  
		  double a = hk.getRanking().getPoints();
		  double b = hp.getRanking().getPoints();
		  double plus;
		  double minus;
		  double procent = b*0.05;

		  if(a<=b){
		   double wartosc = ((b-a)/a)+1;
		   
		   plus = Math.round(procent*wartosc);
		   minus =  Math.round(procent);
		   a = a + plus;
		   b = b - minus;
		   
		  }

		  else{
		   double wartosc = ((a-b)/b)+1;
		   plus = Math.round(procent/wartosc);
		   minus =  Math.round(procent/(wartosc*wartosc));
		   a = a + plus;
		   b = b - minus;
		   
		  }
		  final int aa = (int) a;
		  final int bb = (int) b;
		  hk.getRanking().setPoints((int) (hk.getRanking().getPoints()+plus));
		  hp.getRanking().setPoints((int) (hp.getRanking().getPoints()-minus));
		  
		  
		 int ki = hk.getRanking().getKills();
		 hk.getRanking().setKills(ki+1);
		  
		  int di = hp.getRanking().getDeads();
		  hp.getRanking().setDeads(di+1);
			
		 
		  updatedstats = ""+plus+":"+minus+"";
		  new MCHard.TMySQL("").send();
		return updatedstats;
	}
}
