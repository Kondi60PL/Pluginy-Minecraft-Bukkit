package pl.digitalix96.mchard.Managers;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import pl.digitalix96.mchard.MCH;
import pl.digitalix96.mchard.MCHard;
import pl.digitalix96.mchard.MCHard.TMySQL;

public class GuildManager {

	public String player = null;
	public MCH MCH = MCHard.MCH;

	public static int i1 = 110;
	public static int ii1 = 64;
	public static int i2 = 46;
	public static int ii2 = 64;
	public static int i3 = 341;
	public static int ii3 = 64;
	public static int i4 = 349;
	public static int ii4 = 64;
	public static int i5 = 388;
	public static int ii5 = 64;
	public static int i6 = 396;
	public static int ii6 = 64;
	public static int i7 = 264;
	public static int ii7 = 64;

	public static String it1 = "Grzybni", it2 = "TNT", it3 = "Slime Ball",
			it4 = "Surowych ryb", it5 = "Szmaragdy", it6 = "Z�ote marchewki",
			it7 = "Diamenty";

	public GuildManager() {
	}

	public GuildManager(String player) {
		this.player = player.toLowerCase();
		if (MCHard.st == MCHard.ServerType.MCPack) {
			this.setMCPackMode();
		}
	}

	public void setMCPackMode() {

		this.i1 = 120;
		this.i2 = 388;
		this.i3 = 349;
		this.i4 = 30;
		this.i5 = 384;
		this.i6 = 393;
		this.i7 = 19;

		this.it1 = "Portal Frame";
		this.it2 = "Szmaragdy";
		this.it3 = "Surowe ryby";
		this.it4 = "Pajeczyn";
		this.it5 = "Butelek Exp'a";
		this.it6 = "Pieczonych ziemniaków";
		this.it7 = "Gąbek";

	}

	public Guild getGuild() {
		Guild guild = null;
		for (Guild g : this.MCH.guildlist) {
			for (String p : g.getPlayers()) {
				if (p.equalsIgnoreCase(this.player)) {
					guild = g;
				}
			}

		}
		return guild;
	}

	public Guild getGuild(String name) {
		return this.MCH.guilds.get(name.toUpperCase());
	}

	public boolean inGuild() {
		boolean in = false;
		for (Guild g : this.MCH.guildlist) {
			for (String p : g.getPlayers()) {
				if (p.equalsIgnoreCase(this.player)) {
					in = true;
				}
			}
		}
		return in;
	}

	public boolean inMyGuild(String player2) {
		boolean in = false;
		Guild g0 = null;
		Guild g1 = null;
		for (Guild g : this.MCH.guildlist) {
			for (String p : g.getPlayers()) {
				if (p.equalsIgnoreCase(this.player)) {
					g0 = g;
				}
			}
		}
		for (Guild g : this.MCH.guildlist) {
			for (String p : g.getPlayers()) {
				if (p.equalsIgnoreCase(player2)) {
					g1 = g;
				}
			}
		}
		if (g0.equals(g1)) {
			in = true;
		}
		return in;
	}

	public List<Guild> getGuildList() {
		return this.MCH.guildlist;
	}

	public boolean removeGuild(Guild guild) {
		try {
			ArrayList<String> d = new ArrayList<String>();
			for (String p : guild.getPlayers()) {
				d.add(p);
			}
			for (String p : d) {
				guild.remove(p);
			}
			d.clear();
			if (guild.getAllyList() == null) {
			} else {
				ArrayList<String> a = new ArrayList<String>();
				for (String g : guild.getAllyList()) {

					a.add(g);
				}
				for (String gg : a) {
					guild.removeAlly(gg);
				}
				a.clear();
			}
			System.out.println("Usuwam gildie z hashmap i list...");
			this.MCH.guilds.remove(guild.getName());
			System.out.println(guild);
			this.MCH.guildlist.remove(guild);
			new TMySQL("DELETE FROM `gildie` WHERE `logo` = '"
					+ guild.getName() + "'").send();
			System.out.println("Gildia zostala skasowana!");
		} catch (Exception e) {
			e.printStackTrace();
			Bukkit.broadcastMessage(ChatColor.RED + "Blad gildia "
					+ guild.getName() + " nie zostala usunięta!");
		}
		return true;
	}

	public boolean addGuild(Guild guild) {
		this.MCH.guilds.put(guild.getName(), guild);
		this.MCH.guildlist.add(guild);
		new TMySQL(
				"INSERT INTO gildie (`lider`, `logo`, `nazwa`, `pol`) VALUES ('"
						+ guild.getLider() + "', '" + guild.getName() + "', '"
						+ guild.getFullName() + "', '"
						+ (int) guild.getLocation().getCenterLocation().getX()
						+ ":"
						+ (int) guild.getLocation().getCenterLocation().getY()
						+ ":"
						+ (int) guild.getLocation().getCenterLocation().getZ()
						+ ":')").send();
		return true;
	}

	public boolean isSpawn(Location ploc) {

		boolean cub = false;

		Location cloc = new Location(ploc.getWorld(), 0, 0, 0);
		for (int x = 0; x <= 138; x++)
			for (int z = 0; z <= 138; z++) {
				Location targetLoc0 = new Location(cloc.getWorld(), cloc.getX()
						+ x, ploc.getY(), cloc.getZ() + z);
				Location targetLoc1 = new Location(cloc.getWorld(), cloc.getX()
						- x, ploc.getY(), cloc.getZ() - z);
				Location targetLoc2 = new Location(cloc.getWorld(), cloc.getX()
						- x, ploc.getY(), cloc.getZ() + z);
				Location targetLoc3 = new Location(cloc.getWorld(), cloc.getX()
						+ x, ploc.getY(), cloc.getZ() - z);
				// System.out.print(gm.inGuild()+" "+gm.getGuild().getName() +
				// " "+g.getName());

				if (ploc.distanceSquared(targetLoc0) <= 8) {

					cub = true;

				} else if (ploc.distanceSquared(targetLoc1) <= 8) {

					cub = true;

				} else if (ploc.distanceSquared(targetLoc2) <= 8) {

					cub = true;

				} else if (ploc.distanceSquared(targetLoc3) <= 8) {

					cub = true;

				}

			}
		// MCHard.D.send("pvp: "+cub);
		return cub;
	}

	public boolean canPVP(Location ploc) {

		boolean cub = true;

		Location cloc = new Location(ploc.getWorld(), 0, 0, 0);
		for (int x = 0; x <= 98; x++)
			for (int z = 0; z <= 98; z++) {
				Location targetLoc0 = new Location(cloc.getWorld(), cloc.getX()
						+ x, ploc.getY(), cloc.getZ() + z);
				Location targetLoc1 = new Location(cloc.getWorld(), cloc.getX()
						- x, ploc.getY(), cloc.getZ() - z);
				Location targetLoc2 = new Location(cloc.getWorld(), cloc.getX()
						- x, ploc.getY(), cloc.getZ() + z);
				Location targetLoc3 = new Location(cloc.getWorld(), cloc.getX()
						+ x, ploc.getY(), cloc.getZ() - z);
				// System.out.print(gm.inGuild()+" "+gm.getGuild().getName() +
				// " "+g.getName());

				if (ploc.distanceSquared(targetLoc0) <= 8) {

					cub = false;

				} else if (ploc.distanceSquared(targetLoc1) <= 8) {

					cub = false;

				} else if (ploc.distanceSquared(targetLoc2) <= 8) {

					cub = false;

				} else if (ploc.distanceSquared(targetLoc3) <= 8) {

					cub = false;

				}

			}
		// MCHard.D.send("pvp: "+cub);
		return cub;
	}

	// public boolean canBuild(Player p, Location ploc){

	// boolean cub=true;
	// GuildManager gm = new GuildManager(p.getName());
	// for(Guild g:getGuildList()){
	// Location cloc = g.getLocation();
	// for (int x = 0; x <= 48; x++)
	// for (int z = 0; z <= 48; z++) {
	// Location targetLoc0 = new Location(cloc.getWorld(), cloc.getX() + x,
	// ploc.getY(), cloc.getZ() + z);
	// Location targetLoc1 = new Location(cloc.getWorld(), cloc.getX() - x,
	// ploc.getY(), cloc.getZ() - z);
	// Location targetLoc2 = new Location(cloc.getWorld(), cloc.getX() - x,
	// ploc.getY(), cloc.getZ() + z);
	// Location targetLoc3 = new Location(cloc.getWorld(), cloc.getX() + x,
	// ploc.getY(), cloc.getZ() - z);
	// //System.out.print(gm.inGuild()+" "+gm.getGuild().getName() +
	// " "+g.getName());

	// if (ploc.distanceSquared(targetLoc0) <= 8){
	// if(gm.inGuild()&&gm.getGuild()==g){
	// //
	// }else{
	// cub=false;
	// }
	// }else if (ploc.distanceSquared(targetLoc1) <= 8){
	// if(gm.inGuild()&&gm.getGuild()==g){

	// }else{
	// cub=false;
	// }
	// }else if (ploc.distanceSquared(targetLoc2) <= 8){
	// if(gm.inGuild()&&gm.getGuild()==g){

	// }else{
	// cub=false;
	// }
	// }else if (ploc.distanceSquared(targetLoc3) <= 8){
	// if(gm.inGuild()&&gm.getGuild()==g){

	// }else{
	// cub=false;
	// }
	// }

	// }}
	// MCHard.D.send(cub);
	// return cub;
	// }
	public boolean canCreate(Player p) {
		Location ploc = p.getLocation();
		boolean cub = true;
		for (Guild g : getGuildList()) {
			Location cloc = g.getLocation().getCenterLocation();
			for (int x = 0; x <= 128; x++)
				for (int z = 0; z <= 128; z++) {
					Location targetLoc0 = new Location(cloc.getWorld(),
							cloc.getX() + x, ploc.getY(), cloc.getZ() + z);
					Location targetLoc1 = new Location(cloc.getWorld(),
							cloc.getX() - x, ploc.getY(), cloc.getZ() - z);
					Location targetLoc2 = new Location(cloc.getWorld(),
							cloc.getX() - x, ploc.getY(), cloc.getZ() + z);
					Location targetLoc3 = new Location(cloc.getWorld(),
							cloc.getX() + x, ploc.getY(), cloc.getZ() - z);

					if (ploc.distanceSquared(targetLoc0) <= 8) {
						cub = false;
					} else if (ploc.distanceSquared(targetLoc1) <= 8) {
						cub = false;
					} else if (ploc.distanceSquared(targetLoc2) <= 8) {
						cub = false;
					} else if (ploc.distanceSquared(targetLoc3) <= 8) {
						cub = false;
					}
				}
		}
		return cub;
	}

	public boolean removeItems() {
		Player p = Bukkit.getPlayer(this.player);
		Inventory inv = p.getInventory();
		inv.removeItem(new ItemStack[] { new ItemStack(i1, ii1) });
		inv.removeItem(new ItemStack[] { new ItemStack(i2, ii2) });
		inv.removeItem(new ItemStack[] { new ItemStack(i3, ii3) });
		inv.removeItem(new ItemStack[] { new ItemStack(i4, ii4) });
		inv.removeItem(new ItemStack[] { new ItemStack(i5, ii5) });
		inv.removeItem(new ItemStack[] { new ItemStack(i6, ii6) });
		inv.removeItem(new ItemStack[] { new ItemStack(i7, ii7) });
		return true;
	}

	public boolean checkItems() {
		boolean c = false;
		Player p = Bukkit.getPlayer(this.player);

		boolean i1 = false, i2 = false, i3 = false, i4 = false, i5 = false, i6 = false, i7 = false;

		Inventory inv = p.getInventory();
		ItemStack[] items = inv.getContents();
		for (ItemStack i : items) {
			if (i != null) {
				int id = i.getTypeId();
				int am = i.getAmount();
				if (id == this.i1 && am >= ii1)
					i1 = true;
				if (id == this.i2 && am >= ii2)
					i2 = true;
				if (id == this.i3 && am >= ii3)
					i3 = true;
				if (id == this.i4 && am >= ii4)
					i4 = true;
				if (id == this.i5 && am >= ii5)
					i5 = true;
				if (id == this.i6 && am >= ii6)
					i6 = true;
				if (id == this.i7 && am >= ii7)
					i7 = true;
			}
		}
		if (i1 && i2 && i3 && i4 && i5 && i6 && i7) {
			c = true;
		}
		return c;
	}

	public void getItemsfromGuild() {
		Player p = Bukkit.getPlayer(this.player);
		int it1 = 0;
		int it2 = 0;
		int it3 = 0;
		int it4 = 0;
		int it5 = 0;
		int it6 = 0;
		int it7 = 0;
		Inventory inv = p.getInventory();
		ItemStack[] items = inv.getContents();
		for (ItemStack item : items) {
			if (item == null) {
			} else {
				int id = item.getTypeId();
				int ilosc = item.getAmount();
				if (id == this.i1) {
					it1 = it1 + ilosc;
				}
				if (id == this.i2) {
					it2 = it2 + ilosc;
				}
				if (id == this.i3) {
					it3 = it3 + ilosc;
				}
				if (id == this.i4) {
					it4 = it4 + ilosc;
				}
				if (id == this.i5) {
					it5 = it5 + ilosc;
				}
				if (id == this.i6) {
					it6 = it6 + ilosc;
				}
				if (id == this.i7) {
					it7 = it7 + ilosc;
				}
			}
		}

		p.sendMessage("");
		p.sendMessage(ChatColor.YELLOW
				+ "        Przedmioty wymagane dla zalozenia gildi");
		p.sendMessage("");
		if (it1 >= ii1) {
			p.sendMessage(ChatColor.AQUA + "   - " + ii1 + " " + this.it1 + " "
					+ ChatColor.GOLD + "(" + it1 + "/" + ii1 + ")");
		} else {
			p.sendMessage(ChatColor.AQUA + "   - " + ii1 + " " + this.it1 + " "
					+ ChatColor.RED + "(" + it1 + "/" + ii1 + ")");
		}
		if (it2 >= ii2) {
			p.sendMessage(ChatColor.AQUA + "   - " + ii2 + " " + this.it2 + " "
					+ ChatColor.GOLD + "(" + it2 + "/" + ii2 + ")");
		} else {
			p.sendMessage(ChatColor.AQUA + "   - " + ii2 + " " + this.it2 + " "
					+ ChatColor.RED + "(" + it2 + "/" + ii2 + ")");
		}
		if (it3 >= ii3) {
			p.sendMessage(ChatColor.AQUA + "   - " + ii3 + " " + this.it3 + " "
					+ ChatColor.GOLD + "(" + it3 + "/" + ii3 + ")");
		} else {
			p.sendMessage(ChatColor.AQUA + "   - " + ii3 + " " + this.it3 + " "
					+ ChatColor.RED + "(" + it3 + "/" + ii3 + ")");
		}
		if (it4 >= ii4) {
			p.sendMessage(ChatColor.AQUA + "   - " + ii4 + " " + this.it4 + " "
					+ ChatColor.GOLD + "(" + it4 + "/" + ii4 + ")");
		} else {
			p.sendMessage(ChatColor.AQUA + "   - " + ii4 + " " + this.it4 + " "
					+ ChatColor.RED + "(" + it4 + "/" + ii4 + ")");
		}
		if (it5 >= ii5) {
			p.sendMessage(ChatColor.AQUA + "   - " + ii5 + " " + this.it5 + " "
					+ ChatColor.GOLD + "(" + it5 + "/" + ii5 + ")");
		} else {
			p.sendMessage(ChatColor.AQUA + "   - " + ii5 + " " + this.it5 + " "
					+ ChatColor.RED + "(" + it5 + "/" + ii5 + ")");
		}
		if (it6 >= ii6) {
			p.sendMessage(ChatColor.AQUA + "   - " + ii6 + " " + this.it6 + " "
					+ ChatColor.GOLD + "(" + it6 + "/" + ii6 + ")");
		} else {
			p.sendMessage(ChatColor.AQUA + "   - " + ii6 + " " + this.it6 + " "
					+ ChatColor.RED + "(" + it6 + "/" + ii6 + ")");
		}
		if (it7 >= ii7) {
			p.sendMessage(ChatColor.AQUA + "   - " + ii7 + " " + this.it7 + " "
					+ ChatColor.GOLD + "(" + it7 + "/" + ii7 + ")");
		} else {
			p.sendMessage(ChatColor.AQUA + "   - " + ii7 + " " + this.it7 + " "
					+ ChatColor.RED + "(" + it7 + "/" + ii7 + ")");
		}

		p.sendMessage("");

	}

}