package pl.digitalix96.mchard.Managers;

import org.bukkit.Location;

public class GuildLocation {

	public String name;
	public Location loc;
	public Location minloc;
	public Location maxloc;

	public GuildLocation(String name, Location loc, Location minloc,
			Location maxloc) {
		this.name = name;
		this.loc = loc;
		this.minloc = minloc;
		this.maxloc = maxloc;
	}

	public Location getCenterLocation() {
		return this.loc;
	}

	public Location getMinLocation() {
		return this.minloc;
	}

	public Location getMaxLocation() {
		return this.maxloc;
	}

}

//// Licencja 293 (Muras331)
