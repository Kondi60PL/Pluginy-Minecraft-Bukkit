-- phpMyAdmin SQL Dump
-- version 3.3.7deb6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Czas wygenerowania: 05 Sie 2013, 11:58
-- Wersja serwera: 5.1.49
-- Wersja PHP: 5.3.3-7+squeeze3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Baza danych: `c0k`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `czlonkowie`
--

CREATE TABLE IF NOT EXISTS `czlonkowie` (
  `nick` char(50) DEFAULT NULL,
  `gildia` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gildie`
--

CREATE TABLE IF NOT EXISTS `gildie` (
  `lider` char(50) DEFAULT NULL,
  `logo` text,
  `zastepca` text,
  `nazwa` text,
  `pol` text,
  `sojusze` text CHARACTER SET utf8 COLLATE utf8_polish_ci
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



-- --------------------------------------------------------

--
-- Struktura tabeli dla  `piecyki`
--

CREATE TABLE IF NOT EXISTS `piecyki` (
  `gildia` char(4) DEFAULT NULL,
  `loc` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sojusze`
--

CREATE TABLE IF NOT EXISTS `sojusze` (
  `g0` char(50) DEFAULT NULL,
  `g1` char(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
CREATE TABLE IF NOT EXISTS `statystyki` (
  `nick` text COLLATE utf8_polish_ci NOT NULL,
  `punkty` int(10) NOT NULL,
  `zabojstwa` int(10) NOT NULL,
  `smierci` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `sojusze`
--

